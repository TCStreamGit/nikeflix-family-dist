# NikeFlix changes to resource.images.skinbackgrounds.titanium

This add-on is redistributed by NikeFlix under its original licence (Apache-2.0).

- Upstream: https://mirrors.kodi.tv/addons/omega/addons.xml.gz 1.0.0
- Upstream ZIP: https://mirrors.kodi.tv/addons/omega/resource.images.skinbackgrounds.titanium/resource.images.skinbackgrounds.titanium-1.0.0.zip
- Upstream sha256: 9858908107c0fae22418d5cf84afd57f1845d62346dfd31080b10ca674844ae6
- NikeFlix version: 1.0.0

No source changes: this is the unmodified upstream release, repackaged with this notice.
