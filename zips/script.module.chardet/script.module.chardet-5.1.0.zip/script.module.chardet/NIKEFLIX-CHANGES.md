# NikeFlix changes to script.module.chardet

This add-on is redistributed by NikeFlix under its original licence (LGPL-2.1-or-later).

- Upstream: https://github.com/chardet/chardet 5.1.0
- Upstream ZIP: https://mirrors.kodi.tv/addons/omega/script.module.chardet/script.module.chardet-5.1.0.zip
- Upstream sha256: d5010fc55a9523d86a306ae9e6a8dea0e3248fe079b9ed37280fe86110cd766a
- NikeFlix version: 5.1.0

No source changes: this is the unmodified upstream release, repackaged with this notice.
