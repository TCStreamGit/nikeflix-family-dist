# NikeFlix changes to script.bingie.helper

This add-on is redistributed by NikeFlix under its original licence (GPL-3.0-only).

- Upstream: https://github.com/matke-84/script.bingie.helper 1.1.2
- Upstream ZIP: https://raw.githubusercontent.com/AchillesPunks/repository.titan.bingie.mod/master/omega/script.bingie.helper/script.bingie.helper-1.1.2.zip
- Upstream sha256: 653b7391f5012a0a35867ec53e55045842efa02c4dca698ce8da0f5b39549358
- NikeFlix version: 1.1.2

No source changes: this is the unmodified upstream release, repackaged with this notice.
