# NikeFlix changes to script.module.dateutil

This add-on is redistributed by NikeFlix under its original licence (Apache-2.0 AND BSD-3-Clause).

- Upstream: https://github.com/dateutil/dateutil 2.8.2
- Upstream ZIP: https://mirrors.kodi.tv/addons/omega/script.module.dateutil/script.module.dateutil-2.8.2.zip
- Upstream sha256: 4f264a82986bcdd6880a73a894b263a7750e3e4f2b27a0f511bf82347ac5b2db
- NikeFlix version: 2.8.2

No source changes: this is the unmodified upstream release, repackaged with this notice.
