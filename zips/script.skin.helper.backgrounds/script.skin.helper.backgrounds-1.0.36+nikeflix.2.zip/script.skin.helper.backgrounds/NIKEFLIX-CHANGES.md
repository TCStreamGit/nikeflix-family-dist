# NikeFlix changes to script.skin.helper.backgrounds

This add-on is redistributed by NikeFlix under its original licence (GPL-2.0-only).

- Upstream: https://github.com/kodi-community-addons/script.skin.helper.backgrounds 1.0.36
- Upstream ZIP: https://raw.githubusercontent.com/AchillesPunks/repository.titan.bingie.mod/master/omega/script.skin.helper.backgrounds/script.skin.helper.backgrounds-1.0.36.zip
- Upstream sha256: 87a1bdd9f08b5f8a90636f2496ca69fa19b40e059e12e4a1230c8bc1ac03dc07
- NikeFlix version: 1.0.36+nikeflix.2

## Patches

- `0001-lazy-pil-import.patch`: wallimages.py imports PIL lazily (first wall build) instead of at service start, so the native _imaging extension is not loaded into Kodi unless wall backgrounds are used; a PIL import failure disables walls instead of killing the service. Reduces exposure for the T04 PIL hypothesis (H1); not a demonstrated crash fix.
- `0002-h3-switch-quiescence.patch`: H3 Option C (DEC-H3-C-STAGING, staged, not released): the BackgroundsUpdater loop skips its pass and acknowledges while a NikeFlix profile switch is pending, so Kodi does not have to kill it during LogOff; the added nikeflix_quiesce.py reads one Home window property only (no global getCondVisibility replacement; every pause ends on its own). Evidence docs/evidence/H3-QUIESCE-V5.md.
