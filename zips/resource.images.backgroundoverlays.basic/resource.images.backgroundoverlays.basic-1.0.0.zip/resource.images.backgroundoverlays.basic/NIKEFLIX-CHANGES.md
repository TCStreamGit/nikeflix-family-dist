# NikeFlix changes to resource.images.backgroundoverlays.basic

This add-on is redistributed by NikeFlix under its original licence (Apache-2.0).

- Upstream: https://mirrors.kodi.tv/addons/omega/addons.xml.gz 1.0.0
- Upstream ZIP: https://mirrors.kodi.tv/addons/omega/resource.images.backgroundoverlays.basic/resource.images.backgroundoverlays.basic-1.0.0.zip
- Upstream sha256: 46ea7f87f28b3a34e5a3c5e277f9716debd57718f8c4885b3f9cbd23124a3d5d
- NikeFlix version: 1.0.0

No source changes: this is the unmodified upstream release, repackaged with this notice.
