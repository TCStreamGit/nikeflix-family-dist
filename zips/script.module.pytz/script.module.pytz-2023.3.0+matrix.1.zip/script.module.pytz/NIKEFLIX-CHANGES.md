# NikeFlix changes to script.module.pytz

This add-on is redistributed by NikeFlix under its original licence (MIT).

- Upstream: https://github.com/stub42/pytz 2023.3.0+matrix.1
- Upstream ZIP: https://mirrors.kodi.tv/addons/omega/script.module.pytz/script.module.pytz-2023.3.0+matrix.1.zip
- Upstream sha256: ac770594355682d2b9c7c9d5a9ad468e14f7fd08ba05ea6ecfaea5333495babe
- NikeFlix version: 2023.3.0+matrix.1

No source changes: this is the unmodified upstream release, repackaged with this notice.
