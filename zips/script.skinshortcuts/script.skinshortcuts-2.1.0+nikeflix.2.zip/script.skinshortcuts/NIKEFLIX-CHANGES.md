# NikeFlix changes to script.skinshortcuts

This add-on is redistributed by NikeFlix under its original licence (GPL-2.0-only).

- Upstream: https://github.com/mikesilvo164/script.skinshortcuts 2.1.0
- Upstream ZIP: https://raw.githubusercontent.com/AchillesPunks/repository.titan.bingie.mod/master/omega/script.skinshortcuts/script.skinshortcuts-2.1.0.zip
- Upstream sha256: 865ee5ea5bf0accee27b82539caabce1c8a9fbb8f94b2900fe5ace4f82c80b23
- NikeFlix version: 2.1.0+nikeflix.2

## Patches

- `0001-playlists-iter-name-and-parse-warning.patch`: library.py playlists(): a malformed .xsp (ParseError, T04 log signature) is logged as one warning naming the file instead of a traceback (the malformed file is a skin defect, handed to the skin stream); getiterator() -> iter() (removed in Python 3.9: any Kodi build with Python 3.9+ would drop every playlist; Windows Kodi 21.3 is 3.8); scriptPlaylists() unbound name fixed.
- `0002-settings-write-only-on-change.patch`: H3-FAM-STARTUP-01 (staged, not released): shouldwerun() runs on every Home init and rewrote skinshortcuts-sharedmenu, SkinShortcuts-FullMenu and every ::SKINBOOL:: entry unchanged, each write arming Kodi's 500-ms skin-settings save; they are now written only when the value differs. A real rebuild is unchanged. Evidence docs/evidence/H3-FAMILY-STARTUP-WELCOME.md.
