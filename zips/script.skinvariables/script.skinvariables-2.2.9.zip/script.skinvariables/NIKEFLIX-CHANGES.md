# NikeFlix changes to script.skinvariables

This add-on is redistributed by NikeFlix under its original licence (GPL-3.0-or-later).

- Upstream: https://github.com/jurialmunkey/script.skinvariables 2.2.9
- Upstream ZIP: https://raw.githubusercontent.com/jurialmunkey/repository.jurialmunkey/master/omega/zips/script.skinvariables/script.skinvariables-2.2.9.zip
- Upstream sha256: 7bbac52948ff0934fd29ccbf0657d4d625da22514a9afe4818bc4070d08d50b2
- NikeFlix version: 2.2.9

No source changes: this is the unmodified upstream release, repackaged with this notice.
