# NikeFlix changes to script.module.autocompletion

This add-on is redistributed by NikeFlix under its original licence (GPL-2.0-or-later).

- Upstream: https://github.com/sualfred/script.module.autocompletion 2.1.1
- Upstream ZIP: https://mirrors.kodi.tv/addons/omega/script.module.autocompletion/script.module.autocompletion-2.1.1.zip
- Upstream sha256: e26bbc0550534f765a2a4cf82d9359142fd7b6cf97a5d6fe9ab575681899eb83
- NikeFlix version: 2.1.1

No source changes: this is the unmodified upstream release, repackaged with this notice.
