# NikeFlix changes to script.module.thetvdb

This add-on is redistributed by NikeFlix under its original licence (Apache-2.0).

- Upstream: https://github.com/kodi-community-addons/script.module.thetvdb 1.0.34
- Upstream ZIP: https://raw.githubusercontent.com/AchillesPunks/repository.titan.bingie.mod/master/omega/script.module.thetvdb/script.module.thetvdb-1.0.34.zip
- Upstream sha256: 3914dab00286f65e9e3e08a8b08278a5a2bc9851c7ab3a85270d9acd92ca0ddb
- NikeFlix version: 1.0.34

No source changes: this is the unmodified upstream release, repackaged with this notice.
