# NikeFlix changes to script.skin.helper.service

This add-on is redistributed by NikeFlix under its original licence (GPL-2.0-only).

- Upstream: https://github.com/kodi-community-addons/script.skin.helper.service 1.30.0
- Upstream ZIP: https://raw.githubusercontent.com/AchillesPunks/repository.titan.bingie.mod/master/omega/script.skin.helper.service/script.skin.helper.service-1.30.0.zip
- Upstream sha256: 25e4345be54a63ff75a7e2c909f437e1e29194be2132c59c679d7d2458d44933
- NikeFlix version: 1.30.0+nikeflix.3

## Patches

- `0001-plugin-lazy-metadata-stack.patch`: plugin_content.py creates SimpleCache and MetadataUtils on first use instead of on every plugin:// call, so light actions (the skin's alphabet scrollbar, called on every listing) no longer import the metadata stack into a fresh sub-interpreter. Both T54 lab crashes faulted on that interpreter during start-up; exposure reduction, not a demonstrated fix.
- `0002-h3-switch-quiescence.patch`: H3 Option C (DEC-H3-C-STAGING, staged, not released): the ListItemMonitor loop skips its pass and acknowledges while a NikeFlix profile switch is pending, so Kodi does not have to kill it during LogOff; the added nikeflix_quiesce.py reads one Home window property only (no global getCondVisibility replacement; every pause ends on its own). Evidence docs/evidence/H3-QUIESCE-V5.md.
- `0003-settings-write-only-on-change.patch`: H3-FAM-STARTUP-01 (staged, not released): correct_skin_settings() runs on every profile load and rewrote every matching .label and every defaultset_* marker even when unchanged (about 159 writes per load, each arming Kodi's 500-ms skin-settings save); both are now written only when the value differs. Same end state. Evidence docs/evidence/H3-FAMILY-STARTUP-WELCOME.md.
