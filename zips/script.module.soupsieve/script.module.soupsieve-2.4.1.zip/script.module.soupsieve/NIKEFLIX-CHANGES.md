# NikeFlix changes to script.module.soupsieve

This add-on is redistributed by NikeFlix under its original licence (MIT).

- Upstream: https://github.com/facelessuser/soupsieve 2.4.1
- Upstream ZIP: https://mirrors.kodi.tv/addons/omega/script.module.soupsieve/script.module.soupsieve-2.4.1.zip
- Upstream sha256: dd8c8f17c3c8e8a87b700d2c076f6771a81b08e3ba313bb5c64ddc1500788d8b
- NikeFlix version: 2.4.1

No source changes: this is the unmodified upstream release, repackaged with this notice.
