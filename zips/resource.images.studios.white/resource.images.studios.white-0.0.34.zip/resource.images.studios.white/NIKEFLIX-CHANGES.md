# NikeFlix changes to resource.images.studios.white

This add-on is redistributed by NikeFlix under its original licence (CC-BY-SA-3.0).

- Upstream: https://mirrors.kodi.tv/addons/omega/addons.xml.gz 0.0.34
- Upstream ZIP: https://mirrors.kodi.tv/addons/omega/resource.images.studios.white/resource.images.studios.white-0.0.34.zip
- Upstream sha256: cd6f96143e1efe423f85adcd2b0d9466ad4bcd5bcb0a4c5310b3916faf438e3e
- NikeFlix version: 0.0.34

No source changes: this is the unmodified upstream release, repackaged with this notice.
