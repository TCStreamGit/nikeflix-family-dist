# Skin NikeFlix fonts

Every font file in this folder is free to redistribute. The tests in `tests/test_skin_nikeflix.py` block any other font file.

| File | Family / weight | Licence | Licence file | Source | sha256 |
|---|---|---|---|---|---|
| `Inter-Light.ttf` | Inter Light (300) | SIL OFL 1.1 | `OFL-Inter.txt` | rsms/inter release v4.1, `Inter-4.1.zip` → `extras/ttf/` | `164414f0aacbe98a7e64addc43f7b3bfd2e32f7b90e101feeab227f14c371bda` |
| `Inter-Medium.ttf` | Inter Medium (500) | SIL OFL 1.1 | `OFL-Inter.txt` | same | `97ad806f526e41546d46365bb3a393145f75b7b1568913db74549ad8b8dba872` |
| `Inter-Bold.ttf` | Inter Bold (700) | SIL OFL 1.1 | `OFL-Inter.txt` | same | `288316099b1e0a47a4716d159098005eef7c0066921f34e3200393dbdb01947f` |
| `Anton-Regular.ttf` | Anton Regular | SIL OFL 1.1 | `OFL-Anton.txt` | google/fonts `ofl/anton/` (main) | `a4ba3a92350ebb031da0cb47630ac49eb265082ca1bc0450442f4a83ab947cab` |
| `Light-new.ttf` | Roboto Light | Apache-2.0 | `LICENSE-Apache-2.0-Roboto.txt` | inherited from Titan BINGIE MOD | `ee4352049603e5960550f55444ad720d8d4ce322c0dcba1afc77de78c430d0d5` |
| `Regular-new.ttf` | Roboto Regular | Apache-2.0 | `LICENSE-Apache-2.0-Roboto.txt` | inherited | `bde8a188e37aa936b167aecc5e5a3da40262f6e51fd54c584f2cf2b6b99d96ca` |
| `Bold-new.ttf` | Roboto Bold | Apache-2.0 | `LICENSE-Apache-2.0-Roboto.txt` | inherited | `594d74a49e307be7cc9e1ee5f1023684e6820cf11bcc968bee590391e1ad5a5a` |

- Release archive `Inter-4.1.zip`: sha256 `9883fdd4a49d4fb66bd8177ba6625ef9a64aa45899767dde3d36aa425756b11e`. Its `LICENSE.txt` is copied as `OFL-Inter.txt`.
- `OFL-Anton.txt` is `ofl/anton/OFL.txt` from google/fonts. Anton's `METADATA.pb` declares `license: "OFL"`.
- The font name tables were checked: both Inter and Anton name the SIL Open Font License 1.1 in name ID 13, and Roboto names the Apache License 2.0.
- The fonts are unmodified, so the OFL Reserved Font Name rules are not triggered. Neither Inter's nor Anton's licence declares a Reserved Font Name.

## Removed in T22 (not redistributable)

| Removed file | Reason (from `LICENSE-AUDIT.md` L2/L3) | Replacement |
|---|---|---|
| `Netflix-Sans-Light.ttf`, `Netflix-Sans-Medium.ttf`, `Netflix-sans-Bold.ttf` | Netflix, Inc. / Dalton Maag, all rights reserved | Inter Light / Medium / Bold |
| `Impact.ttf` | Monotype / Microsoft-supplied font | Anton Regular |

## Font.xml mapping

| Old `<filename>` | New `<filename>` | Fonts using it |
|---|---|---|
| `Netflix-sans-medium.ttf` | `Inter-Medium.ttf` | 123 (Default fontset body text) |
| `Netflix-sans-Bold.ttf`, `Netflix-sans-bold.ttf` | `Inter-Bold.ttf` | 117 |
| `Netflix-sans-Light.ttf` | `Inter-Light.ttf` | 1 (`BigLight50`) |
| `Impact.ttf` (size 30) | `Anton-Regular.ttf` (size 28) | 1 (`IBold30`, MPAA rating badges) |
| `Bold-New.ttf` | `Bold-new.ttf` | 116 (Roboto fontset; filename case corrected to match the file) |

The fontset IDs (`Default`, `Roboto`) and every font `<name>` are unchanged, so existing skin settings keep working.

## Metric check

Metrics were measured from the font tables (`head`, `hhea`, `OS/2`, `hmtx`, `cmap`) with a stdlib-only script. Widths are the summed advance widths in em units:

- **pangram**: "The quick brown fox jumps over the lazy dog 0123456789"
- **caps**: "STRANGER THINGS CONTINUE WATCHING"
- **ui**: "Continue Watching  My List  Movies  TV Shows  Settings"

| Font | ascender | descender | x-height | cap height | pangram | caps | ui |
|---|---|---|---|---|---|---|---|
| Netflix Sans Light | 1.015 | -0.262 | 0.510 | 0.696 | 26.458 | 20.962 | 25.439 |
| **Inter Light** | 0.969 | -0.241 | 0.546 | 0.728 | 27.134 (+2.6%) | 20.667 (-1.4%) | 26.327 (+3.5%) |
| Netflix Sans Medium | 1.015 | -0.262 | 0.517 | 0.696 | 27.099 | 21.188 | 26.157 |
| **Inter Medium** | 0.969 | -0.241 | 0.546 | 0.728 | 27.829 (+2.7%) | 20.931 (-1.2%) | 26.978 (+3.1%) |
| Roboto Regular (rejected) | 0.928 | -0.244 | 0.528 | 0.711 | 25.623 (-5.4%) | 19.363 (-8.6%) | 24.933 (-4.7%) |
| Netflix Sans Bold | 1.015 | -0.262 | 0.521 | 0.696 | 27.402 | 21.295 | 26.486 |
| **Inter Bold** | 0.969 | -0.241 | 0.546 | 0.728 | 28.333 (+3.4%) | 21.130 (-0.8%) | 27.430 (+3.6%) |
| Impact (size 30) | 1.009 | -0.211 | 0.648 | 0.791 | 23.026 | 15.682 | 22.235 |
| **Anton** (size 28) | 1.176 | -0.329 | 0.732 | 0.859 | 22.938 | 14.198 | 22.141 |

Conclusions:

- **Inter** keeps the same weights and stays within ±3.6% of Netflix Sans width on every sample, so it was chosen. Roboto is 5–9% narrower.
- Inter's line box (ascender − descender) is 1.210 em against Netflix Sans's 1.277 em, about 5% shorter. Text sits slightly higher in fixed-height labels and is less likely to clip vertically.
- Inter's cap height is 4.6% taller. In labels that were already close to their width limit, scrolling or truncation can start a few characters earlier.
- **Anton at size 28** gives a cap height of 24.1 px, against 23.7 px for Impact at size 30. The `IBold30` MPAA badge labels therefore keep the same visual height. Anton is about 15% narrower in capitals, which suits the auto-width badges.

Visual acceptance on a real screen is part of the T22 lab smoke test (`docs/evidence/T22-SKIN-SMOKE.md`) and later subjective acceptance.
