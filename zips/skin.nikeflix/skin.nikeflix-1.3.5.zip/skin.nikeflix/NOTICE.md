# Skin NikeFlix: notice

Skin NikeFlix (`skin.nikeflix`) is a **modified version** of **Titan BINGIE MOD 2.2.8** (`skin.titan.bingie.mod`).

- Upstream source: <https://github.com/AchillesPunks/skin.titan.bingie.mod>
- Upstream lineage:
  - Titan BINGIE MOD by AchillesPunks and Matke, with HugoL
  - based on Titan BINGIE by cartman.dos
  - based on Titan by marcelveldt

## Licence

Skin NikeFlix is distributed under the **GNU General Public License, version 2 only** (`GPL-2.0-only`), the same licence as the upstream skin. The full text is in [`LICENSE`](LICENSE). All upstream copyright notices are kept.

The skin carries **no warranty**; see sections 11 and 12 of the licence.

## Modifications

NikeFlix changed this work. As required by GPL-2.0 section 2(a), every change, with its date, is listed in [`NIKEFLIX-CHANGES.md`](NIKEFLIX-CHANGES.md).

## Bundled third-party material

| Material | Licence | Where |
|---|---|---|
| Inter (Light, Medium, Bold), The Inter Project Authors | SIL Open Font License 1.1 | `fonts/Inter-*.ttf`, `fonts/OFL-Inter.txt` |
| Anton, The Anton Project Authors | SIL Open Font License 1.1 | `fonts/Anton-Regular.ttf`, `fonts/OFL-Anton.txt` |
| Roboto (Light, Regular, Bold), Google 2014 | Apache License 2.0 | `fonts/*-new.ttf`, `fonts/LICENSE-Apache-2.0-Roboto.txt` |

Details and checksums are in [`fonts/FONTS.md`](fonts/FONTS.md).

## Corresponding source for built assets

`media/Textures.xbt` is a built texture bundle. Its source images are in [`media-src/textures/`](media-src/textures/), with a per-entry manifest and the stdlib build tool in [`media-src/`](media-src/README.md).

## Trademarks

"Netflix" and "Netflix Sans" are trademarks of Netflix, Inc. Skin NikeFlix is not affiliated with or endorsed by Netflix, Inc., and it does not include the Netflix Sans typeface.
