# Skin NikeFlix: credits

Skin NikeFlix stands on the work of the following people and projects. Their credits must stay in every copy and derivative.

## Skin lineage

| Project | Authors | Notes |
|---|---|---|
| **Titan** | marcelveldt | The original Titan skin and its helper add-ons |
| **Titan BINGIE** | cartman.dos | The BINGIE layout, hubs and views |
| **Titan BINGIE MOD** 2.2.8 | AchillesPunks and Matke (with HugoL) | The Kodi Omega version that Skin NikeFlix 1.0.0 is forked from. Upstream: <https://github.com/AchillesPunks/skin.titan.bingie.mod> |

From the upstream README: "Special Thanks to @marcelveldt and @cartman.dos for all of his work on the original code for Titan and Titan BINGIE skin & addons and everyone else who have helped or contributed in any way!"

## Companion add-ons used by the skin

| Add-on | Authors | Licence |
|---|---|---|
| `script.bingie.helper` | cartman.dos, Matke | GPL-3.0 |
| `screensaver.titan.bingie.mod` | drinfernoo, Matke | Apache-2.0 |
| `script.skinshortcuts` | BigNoid, marcelveldt, SiLVO | GPL-2.0 |
| `script.skin.helper.service` / `.backgrounds` | marcelveldt and others | GPL-2.0 |
| `script.skin.helper.widgets` | marcelveldt, Matke and others | GPL-2.0 |

Author names are taken from each add-on's `addon.xml` `provider-name`.

## Translations

- French (`fr_fr`) and Dutch (`nl_nl`, QAELIX) translations come from Titan BINGIE MOD.

## Fonts

- **Inter** by Rasmus Andersson and The Inter Project Authors (SIL OFL 1.1).
- **Anton** by Vernon Adams and The Anton Project Authors (SIL OFL 1.1).
- **Roboto** by Google (Apache License 2.0).

## NikeFlix

The NikeFlix branding, intro clips and logo artwork are NikeFlix's own. The NikeFlix changes are listed in [`NIKEFLIX-CHANGES.md`](NIKEFLIX-CHANGES.md).
