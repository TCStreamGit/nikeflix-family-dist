# Skin NikeFlix

Skin NikeFlix (`skin.nikeflix`) is a modified version of Titan BINGIE MOD 2.2.8, licensed GPL-2.0-only. See [NOTICE.md](NOTICE.md), [CREDITS.md](CREDITS.md) and [NIKEFLIX-CHANGES.md](NIKEFLIX-CHANGES.md). Do not report NikeFlix issues to the upstream Titan BINGIE MOD project.

The upstream README follows, unchanged.

---

# Skin Titan BINGIE MOD

Titan BINGIE MOD for Kodi Omega.

#IMPORTANT NOTE FOR USERS# 
Install the skin through the official titan bingie mod repository for updates and the supported addons required!
The content here is for developing purposes!
https://github.com/AchillesPunks/repository.titan.bingie.mod

Join the official thread for updates: https://forum.kodi.tv/showthread.php?tid=355993

Special Thanks to @marcelveldt and @cartman.dos for all of his work on the original code for Titan and Titan BINGIE skin & addons 
and everyone else who have helped or contributed in any way!
