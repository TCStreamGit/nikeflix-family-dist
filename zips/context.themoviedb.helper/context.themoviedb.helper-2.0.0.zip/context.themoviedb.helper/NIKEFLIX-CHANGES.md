# NikeFlix changes to context.themoviedb.helper

This add-on is redistributed by NikeFlix under its original licence (GPL-3.0-or-later).

- Upstream: https://github.com/jurialmunkey/plugin.video.themoviedb.helper 2.0.0
- Upstream ZIP: https://raw.githubusercontent.com/jurialmunkey/repository.jurialmunkey/master/omega/zips/context.themoviedb.helper/context.themoviedb.helper-2.0.0.zip
- Upstream sha256: e9a35e748618e4368dbcedbc6008da9613c5e62dd3c05bd002451175d6499895
- NikeFlix version: 2.0.0

No source changes: this is the unmodified upstream release, repackaged with this notice.
