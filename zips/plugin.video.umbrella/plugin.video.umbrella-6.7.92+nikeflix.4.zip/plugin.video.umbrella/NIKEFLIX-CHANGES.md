# NikeFlix changes to plugin.video.umbrella

This add-on is redistributed by NikeFlix under its original licence (GPL-3.0-only).

- Upstream: https://github.com/umbrellaplug/umbrellaplug.github.io (zips only; no public source repo found) 6.7.92
- Upstream ZIP: https://raw.githubusercontent.com/umbrellaplug/umbrellaplug.github.io/master/omega/zips/plugin.video.umbrella/plugin.video.umbrella-6.7.92.zip
- Upstream sha256: 8dc3b19e70d0e02deb32d06579441288dbe1911ecaec2628d298590e1333853f
- NikeFlix version: 6.7.92+nikeflix.4

## Patches

- `0001-h3-switch-quiescence.patch`: H3 Option C follow-up: the account-sync service loop (resources/lib/modules/tools.py services_syncs) skips its pass, makes no GUI condition call and acknowledges while a NikeFlix profile switch is pending; its 5-s and 30-s waits return early on a pending switch, so Kodi does not have to kill Umbrella during LogOff (about 1 in 6 switches before). Adds the shared nikeflix_quiesce.py unchanged. Evidence docs/evidence/H3-UMBRELLA-PAUSE.md.
- `0002-quiet-mode-opensubs-no-account.patch`: Quiet Mode step 2 (T34 site UMB-OPENSUBS-AUTH, Subtitles.get): with no OpenSubtitles account in Umbrella and service.nikeflix quiet.enabled on, playback start no longer toasts 'Unable to authorize opensubs' and logs 'NikeFlix Quiet Mode: hid ...' instead; Quiet Mode off, a missing service.nikeflix or an entered account that fails behave as upstream. Evidence docs/evidence/T34-QUIET-MODE-STEP2.md.
- `0003-trakt-hub-broker.patch`: NikeFlix Trakt Hub (T30/T31/T33, TRAKT-REGISTER disposition A: custom client = NikeFlix app + token hook): while service.nikeflix publishes the broker (Home property nikeflix.trakt.broker=true), re_auth asks the broker to refresh (nikeflix.trakt.refresh_requested) and waits for the new token instead of refreshing, wiping the tokens or toasting a re-auth nag; traktAuth and traktRevoke open NikeFlix's Trakt Account; traktClientSecret is empty for the NikeFlix public client (never Umbrella's secret with the NikeFlix id). Without the broker everything is upstream. Evidence docs/evidence/T33-TRAKT-HUB.md.
- `0004-throttle-wait-abort-aware.patch`: Trakt 429 handling: urllib3 no longer retries 429 or sleeps out a Retry-After (status_forcelist without 429, respect_retry_after_header=False); getTrakt's own throttle wait: the upstream plain control.sleep(Retry-After) is replaced by a wait of at most 30 s that ends at Kodi's stop or a pending NikeFlix profile switch (returns no data then). P05 4.0.1 lab 2026-11-17: with Trakt rate-limiting the lab, an Umbrella thread in that sleep held quit until the 90-s force; a faulthandler dump showed parallel items_list threads in urllib3 sleep_for_retry. Evidence docs/evidence/P05-401-LAB.md.
