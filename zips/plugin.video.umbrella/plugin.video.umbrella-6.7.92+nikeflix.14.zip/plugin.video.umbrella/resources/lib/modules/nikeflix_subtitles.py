# -*- coding: utf-8 -*-
"""NikeFlix 4.1.5 Netflix-style subtitles (added by a NikeFlix patch; the same file in Umbrella and a4kSubtitles).

Before an external SRT is handed to Kodi, service.nikeflix rewrites it the way Netflix sets subtitles (its
resources/lib/subreflow.py): at most two lines of 42 characters with the bottom line the longer one, two speakers one
line each, a cue too long for two lines split into two timed cues, and {\an8}-style positions dropped while Kodi keeps
subtitles at the bottom (subtitles.overridestyles). NikeFlix Settings > Subtitles & Audio > Two lines at most turns
the rewrite off (service.nikeflix subs.twolines). Without service.nikeflix, or on any problem, the file is handed to
Kodi as it was. Embedded subtitles never pass through here.
"""
import importlib.util
import json
import os

SERVICE = 'service.nikeflix'


def _reflow_module(addon):
    path = os.path.join(addon.getAddonInfo('path'), 'resources', 'lib', 'subreflow.py')
    spec = importlib.util.spec_from_file_location('nikeflix_subreflow', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _keep_at_bottom():
    import xbmc
    try:
        out = json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': 'Settings.GetSettingValue',
                                                          'params': {'setting': 'subtitles.overridestyles'}})))
        return int(out['result']['value']) in (1, 3)   # positions, or styles and positions
    except Exception:
        return False


def _log(message):
    import xbmc
    xbmc.log('[NikeFlix] %s' % message, xbmc.LOGINFO)


def reflow(path):
    """-> the path to hand to Kodi (the same file, rewritten in place when that was needed)."""
    try:
        import xbmcaddon
        addon = xbmcaddon.Addon(SERVICE)
    except Exception:
        return path
    try:
        two_lines = addon.getSetting('subs.twolines') != 'false'
        return _reflow_module(addon).reflow_file(path, two_lines=two_lines, bottom=_keep_at_bottom(), log=_log)
    except Exception as exc:
        _log('subtitles: %s left as it was (%s)' % (os.path.basename(str(path)), exc))
        return path
