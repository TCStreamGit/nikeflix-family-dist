# -*- coding: utf-8 -*-
"""NikeFlix 4.1.5 post-play (Netflix on a TV): Umbrella's Play Next as a full window instead of a dialog.

Kodi draws a playing video inside a window's video control only when the full-screen video window is not the active
one; a dialog over full-screen video cannot shrink it. As a window, the NikeFlix skin's auraplaynext2.xml shows the
episode in its top-left corner, and closing the window goes back to full-screen video. Everything else is
PlayNextXML's own code (the same buttons, Play Now, the countdown and Still Watching handling)."""
import xbmcgui

from resources.lib.windows import playnext
from resources.lib.windows.base import BaseDialog


class NikeFlixPostPlay(xbmcgui.WindowXML):
	def __init__(self, *args, **kwargs):
		self.closing_actions = [9, 10, 13, 92, 511]
		self.selection_actions = [7, 100]
		self.context_actions = [101, 117]
		self.info_actions = [11,]
		self.window_id = 3011
		self.meta = kwargs.get('meta')
		self.playing_file = self.getPlayingFile()
		self.duration = self.getTotalTime() - self.getTime()
		self.default_action = int(playnext.getSetting('playnext.default.action'))
		self.playNextBG = playnext.getSetting('playnext.background.color')
		self.source_color = playnext.getSetting('sources.highlight.color')
		self.closed = False
		self.nikeflix = True
		self.nikeflix_cancelled = False

	def run(self):
		# the skin keeps playing while full-screen video makes way for this window (its VideoFullScreen.xml stops
		# playback when that window closes otherwise)
		playnext.control.homeWindow.setProperty('nikeflix.postplay', 'true')
		try:
			self.doModal()
			self.clearProperties()
		finally:
			# service.nikeflix brings the episode back up full screen too (this plugin call can be ended by the next
			# episode's own Umbrella call before it gets there)
			playnext.control.homeWindow.setProperty('nikeflix.postplay.closed', str(int(playnext.time.time())))
			self._back_to_full_screen()
			playnext.control.homeWindow.clearProperty('nikeflix.postplay')

	def _back_to_full_screen(self):
		# closing this window goes back to full-screen video, unless the episode ended under it (Play Now, the
		# countdown): then Kodi falls back to the menu and the next episode plays behind it. Bring it up full screen
		# (Still Watching, patch 0007, also waits for full-screen video before it asks).
		xbmc = playnext.xbmc
		for _ in range(60): # up to 15 s for the next episode
			if xbmc.getCondVisibility('Window.IsActive(fullscreenvideo)'): return
			if xbmc.getCondVisibility('Player.HasVideo'):
				xbmc.executebuiltin('ActivateWindow(fullscreenvideo)')
				return
			if playnext.monitor.waitForAbort(0.25): return


for _name in ('onInit', 'doClose', 'onAction', 'onClick', 'getTotalTime', 'getTime', 'isPlaying',
		'getPlayingFile', 'calculate_percent', 'background_tasks', '_nikeflix_tick', 'set_properties'):
	setattr(NikeFlixPostPlay, _name, getattr(playnext.PlayNextXML, _name))
for _name in ('make_listitem', 'execute_code', 'get_position', 'getControlProgress', 'reset_window', 'get_control'):
	setattr(NikeFlixPostPlay, _name, getattr(BaseDialog, _name))
