# NikeFlix changes to script.module.simpleeval

This add-on is redistributed by NikeFlix under its original licence (MIT).

- Upstream: https://github.com/mikesilvo164/script.module.simpleeval 0.9.13
- Upstream ZIP: https://mirrors.kodi.tv/addons/omega/script.module.simpleeval/script.module.simpleeval-0.9.13.zip
- Upstream sha256: 191591b4da84aad32e01a96be0c989ba1a96ffe3be15b28cdd2152eb6927bced
- NikeFlix version: 0.9.13

No source changes: this is the unmodified upstream release, repackaged with this notice.
