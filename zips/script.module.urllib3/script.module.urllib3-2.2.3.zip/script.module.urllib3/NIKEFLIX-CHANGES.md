# NikeFlix changes to script.module.urllib3

This add-on is redistributed by NikeFlix under its original licence (MIT).

- Upstream: https://github.com/urllib3/urllib3 2.2.3
- Upstream ZIP: https://mirrors.kodi.tv/addons/omega/script.module.urllib3/script.module.urllib3-2.2.3.zip
- Upstream sha256: 740b2d63bb50eee9fb35f01c567ec8d3588c5bbd548e2b8d280932be30d82f53
- NikeFlix version: 2.2.3

No source changes: this is the unmodified upstream release, repackaged with this notice.
