# NikeFlix changes to script.module.cocoscrapers

This add-on is redistributed by NikeFlix under its original licence (GPL-3.0-only).

- Upstream: https://raw.githubusercontent.com/not-coco-joe/repository.cocoscrapers/master/zips/addons.xml 1.0.39
- Upstream ZIP: https://raw.githubusercontent.com/not-coco-joe/repository.cocoscrapers/master/zips/script.module.cocoscrapers/script.module.cocoscrapers-1.0.39.zip
- Upstream sha256: c6de1ad7ae612fe22a5b102504b9b6f7cebe8fe961de321bdae86b5dced5af59
- NikeFlix version: 1.0.39

No source changes: this is the unmodified upstream release, repackaged with this notice.
- Added `LICENSE.txt` (licence text from `managed/_licences/GPL-3.0.txt`).
