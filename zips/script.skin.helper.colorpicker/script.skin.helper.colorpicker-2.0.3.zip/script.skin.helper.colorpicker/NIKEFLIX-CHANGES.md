# NikeFlix changes to script.skin.helper.colorpicker

This add-on is redistributed by NikeFlix under its original licence (GPL-2.0-only).

- Upstream: https://github.com/kodi-community-addons/script.skin.helper.colorpicker 2.0.3
- Upstream ZIP: https://raw.githubusercontent.com/AchillesPunks/repository.titan.bingie.mod/master/omega/script.skin.helper.colorpicker/script.skin.helper.colorpicker-2.0.3.zip
- Upstream sha256: f89682e3ced270c1850f0a3a0d2062323ed49b350a3d0e1658d10445aad2d214
- NikeFlix version: 2.0.3

No source changes: this is the unmodified upstream release, repackaged with this notice.
