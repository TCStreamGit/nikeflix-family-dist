# NikeFlix changes to script.module.qrcode

This add-on is redistributed by NikeFlix under its original licence (BSD-3-Clause).

- Upstream: https://github.com/lincolnloop/python-qrcode 6.1.0+matrix.3
- Upstream ZIP: https://mirrors.kodi.tv/addons/omega/script.module.qrcode/script.module.qrcode-6.1.0+matrix.3.zip
- Upstream sha256: e5c01d0ff83bdb7687c3150dcda5a01896a2281c28ffe9813f6e4763ea44f132
- NikeFlix version: 6.1.0+matrix.3

No source changes: this is the unmodified upstream release, repackaged with this notice.
