# NikeFlix changes to script.module.inputstreamhelper

This add-on is redistributed by NikeFlix under its original licence (MIT).

- Upstream: https://github.com/emilsvennesson/script.module.inputstreamhelper 0.8.6
- Upstream ZIP: https://mirrors.kodi.tv/addons/omega/script.module.inputstreamhelper/script.module.inputstreamhelper-0.8.6.zip
- Upstream sha256: 326ff6182802c7fc3967df254823c84ba39eedacae03b1349eb4acafcb231801
- NikeFlix version: 0.8.6

No source changes: this is the unmodified upstream release, repackaged with this notice.
