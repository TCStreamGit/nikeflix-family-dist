# NikeFlix changes to resource.images.busyspinners.basic

This add-on is redistributed by NikeFlix under its original licence (GPL-3.0-only).

- Upstream: https://raw.githubusercontent.com/AchillesPunks/repository.titan.bingie.mod/master/omega/addons.xml 1.0.6
- Upstream ZIP: https://raw.githubusercontent.com/AchillesPunks/repository.titan.bingie.mod/master/omega/resource.images.busyspinners.basic/resource.images.busyspinners.basic-1.0.6.zip
- Upstream sha256: 0d158450ebe15e36caf229d57f269d6850dd9aa1fbf7609b25cd7ed0484c184a
- NikeFlix version: 1.0.6

No source changes: this is the unmodified upstream release, repackaged with this notice.
