# NikeFlix changes to script.module.typing_extensions

This add-on is redistributed by NikeFlix under its original licence (PSF-2.0).

- Upstream: https://github.com/python/typing_extensions 4.7.1
- Upstream ZIP: https://mirrors.kodi.tv/addons/omega/script.module.typing_extensions/script.module.typing_extensions-4.7.1.zip
- Upstream sha256: 669f1fd9d149ece899eb88462d95b3ab6bb54c19fce6d3b58c61152d1135d66e
- NikeFlix version: 4.7.1

No source changes: this is the unmodified upstream release, repackaged with this notice.
