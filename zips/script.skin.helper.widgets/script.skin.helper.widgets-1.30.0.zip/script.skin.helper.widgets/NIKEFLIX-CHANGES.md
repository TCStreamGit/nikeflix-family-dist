# NikeFlix changes to script.skin.helper.widgets

This add-on is redistributed by NikeFlix under its original licence (GPL-2.0-only).

- Upstream: https://github.com/matke-84/script.skin.helper.widgets 1.30.0
- Upstream ZIP: https://raw.githubusercontent.com/AchillesPunks/repository.titan.bingie.mod/master/omega/script.skin.helper.widgets/script.skin.helper.widgets-1.30.0.zip
- Upstream sha256: 4da8dd320ece708042bc2b41f36853c09e6eb6ea0f95956385867705f82b5376
- NikeFlix version: 1.30.0

No source changes: this is the unmodified upstream release, repackaged with this notice.
