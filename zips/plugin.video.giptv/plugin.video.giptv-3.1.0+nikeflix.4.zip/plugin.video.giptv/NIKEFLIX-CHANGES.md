# NikeFlix changes to plugin.video.giptv

This add-on is redistributed by NikeFlix under its original licence (GPL-2.0-or-later).

- Upstream: https://github.com/G00380316/GIPTV (zips; source submodule G00380316/plugin.video.giptv returns 404) 3.1.0
- Upstream ZIP: https://raw.githubusercontent.com/G00380316/GIPTV/main/repo/zips/plugin.video.giptv/plugin.video.giptv-3.1.0.zip
- Upstream sha256: b1ba685381705794b81e28112800dea2aeccfa28081a92f915eac6da69899450
- NikeFlix version: 3.1.0+nikeflix.4

## Patches

- `0001-drop-service-upnext-dependency.patch`: Remove the hard <import> of service.upnext (class R, plan B6). GIPTV checks System.HasAddon(service.upnext) at runtime and keeps autoplay without it; a hard import would make Kodi fetch upnext from another origin.
- `0002-quiet-mode-no-modal-changelog.patch`: Quiet Mode: no modal changelog on the first start of each version. The window ran inside the GIPTV service, which (and with it the IPTV Simple bridge) stayed blocked until someone closed it (DESIGN-PVR S3). The once-per-version marker is still written.
- `0003-quiet-mode-no-iptv-account.patch`: Quiet Mode step 3 (T34 entry GIPTV-NO-ACCOUNT, get_api_credentials): on a profile with no IPTV account at all and service.nikeflix quiet.enabled on, the Live/Sports widgets no longer toast 'Please configure your IPTV credentials in the add-on settings.' on every Home load and log 'NikeFlix Quiet Mode: hid ...' instead; a half-entered account, Quiet Mode off or no service.nikeflix behave as upstream. Evidence docs/evidence/T34-QUIET-MODE-STEP3.md.
- `0004-version-check-reads-nikeflix-suffix.patch`: GIPTV's one-time update tasks read its own version 3.1.0+nikeflix.N as 0.0.0 (int() failed on the build suffix), so every NikeFlix GIPTV version ran the <= 2.6.1 legacy reset on its first start in each profile and wiped Kodi's whole thumbnail cache, including the 0-f folders Kodi writes into. Kodi then could not save any artwork: posters, fanart and logos showed placeholders until Kodi restarted. The version is now read up to the build suffix. Lab 2026-11-19 (NikeFlix 4.1 parity tour): before, Thumbnails had no 0-f folders and every image failed with 'Direct texture file loading failed'. Evidence docs/evidence/NF41-ARTWORK-LAB.md.
