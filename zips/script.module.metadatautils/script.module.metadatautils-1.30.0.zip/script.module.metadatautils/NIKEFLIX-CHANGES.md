# NikeFlix changes to script.module.metadatautils

This add-on is redistributed by NikeFlix under its original licence (Apache-2.0).

- Upstream: https://github.com/kodi-community-addons/script.module.metadatautils 1.30.0
- Upstream ZIP: https://raw.githubusercontent.com/AchillesPunks/repository.titan.bingie.mod/master/omega/script.module.metadatautils/script.module.metadatautils-1.30.0.zip
- Upstream sha256: fcb85f43e624c14b84d27f7b83f897245887a1ffcd4b63d9fee81b3eb77858f2
- NikeFlix version: 1.30.0

No source changes: this is the unmodified upstream release, repackaged with this notice.
