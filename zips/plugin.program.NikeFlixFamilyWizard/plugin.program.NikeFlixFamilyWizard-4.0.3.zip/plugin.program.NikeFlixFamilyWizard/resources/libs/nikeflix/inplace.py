# SPDX-License-Identifier: GPL-2.0-or-later
# Copyright (C) 2026 NikeFlix
"""In-place build update (NikeFlix 4.1.4): a newer build reaches the device without a wipe.

A clean install removes every profile. Here only the build's add-ons change; userdata (every profile, its settings,
sign-ins, history and databases) is never touched:

1. the build is downloaded and checked exactly as for an install (installer.prepare: feed entry, sha256, size,
   archive layout, the Addons33.db seed);
2. each add-on of the build that is missing or has another version than the installed one is extracted to a work
   folder and swapped in with two renames (the old folder comes back if a swap fails); the wizard itself is skipped
   (it updates itself from the repository);
3. the build's add-on seed is applied to the master database and the profile databases, so a new add-on is
   registered and enabled with NikeFlix's origin and rules (a bare extraction would leave it disabled, T24);
4. the caller asks Kodi to rescan local add-ons; running add-ons use the new files from the next start.

`env` is kodi_glue.InPlaceEnv in Kodi and a fake in tests.
"""
import os
import shutil
import uuid
import xml.etree.ElementTree as ET
import zipfile

from resources.libs.nikeflix import installer
from resources.libs.nikeflix import integrity
from resources.libs.nikeflix import seed


def installed_version(addons_dir, addon_id):
    try:
        return ET.parse(os.path.join(addons_dir, addon_id, "addon.xml")).getroot().get("version") or ""
    except (OSError, ET.ParseError):
        return ""


def build_versions(zpath, members):
    out = {}
    with zipfile.ZipFile(zpath) as zf:
        for info, parts in members:
            if len(parts) == 3 and parts[0] == "addons" and parts[2] == "addon.xml":
                try:
                    out[parts[1]] = ET.fromstring(zf.read(info)).get("version") or ""
                except ET.ParseError:
                    pass
    return out


def changed_addons(build, addons_dir, wizard_id):
    """Ids whose build version differs from the installed one (or that are not installed), the wizard excluded."""
    return sorted(a for a, v in build.items() if a != wizard_id and installed_version(addons_dir, a) != v)


def swap_in(zpath, members, addon_id, addons_dir):
    work = os.path.join(addons_dir, ".nikeflix-inplace-" + uuid.uuid4().hex[:8])
    try:
        own = [(i, p) for i, p in members if len(p) >= 2 and p[0] == "addons" and p[1] == addon_id]
        integrity.extract_members(zpath, own, work)
        new = os.path.join(work, "addons", addon_id)
        target = os.path.join(addons_dir, addon_id)
        old = os.path.join(work, "old")
        os.makedirs(old)
        moved = False
        if os.path.exists(target):
            os.rename(target, os.path.join(old, addon_id))
            moved = True
        try:
            os.rename(new, target)
        except OSError:
            if moved:
                os.rename(os.path.join(old, addon_id), target)
            raise
    finally:
        shutil.rmtree(work, ignore_errors=True)


def update(env, entry):
    """Returns a report (ids and counts, no paths of user data). Raises installer.InstallAborted before any change
    when the download or the archive is rejected."""
    zpath, members, seed_path = installer.prepare(env, entry)
    report = {"build": entry.get("name"), "version": entry.get("version"), "updated": [], "failed": []}
    try:
        build = build_versions(zpath, members)
        for aid in changed_addons(build, env.addons_dir, env.wizard_id):
            try:
                swap_in(zpath, members, aid, env.addons_dir)
                report["updated"].append(aid)
            except (OSError, integrity.ArchiveError) as exc:
                report["failed"].append("%s: %s" % (aid, type(exc).__name__))
        if report["updated"]:
            report["seed"] = seed.apply_seed(env.live_addons_db, seed_path)
            unseeded = sorted(installer.addon_ids(members) - seed.seeded_ids(seed_path) - {env.wizard_id})
            report["profile_seeds"], report["profile_seed_missing"] = installer._profile_seeds(env, members, unseeded)
    finally:
        for p in (zpath, seed_path):
            if os.path.exists(p):
                os.remove(p)
        installer._drop_seed_copies(env)
    return report
