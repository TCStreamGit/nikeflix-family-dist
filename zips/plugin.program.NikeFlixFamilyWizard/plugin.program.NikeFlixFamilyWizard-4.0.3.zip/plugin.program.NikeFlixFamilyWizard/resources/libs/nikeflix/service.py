# SPDX-License-Identifier: GPL-2.0-or-later
# Copyright (C) 2026 NikeFlix (derived work of OpenWizard, Copyright (C) 2019 drinfernoo; see NOTICE.txt)
"""Wizard startup service (T23; T05 finding: no wizard modals on any profile, T02: no costly startup probes).

Contract:

* **Every profile (NikeFlix 4.1.6; before: master only):** cheap checks only and **no dialog of any kind**. The
  wizard's state is the device's and stays in the master profile's settings (kodi_glue.MasterSettings outside it), so
  the check is still at most once per 24 h per device whichever profile is in use. Tanner's Apple TV (2026-11-22)
  starts straight in a non-master profile: the build check and the in-place update never ran there, so add-ons Kodi
  never updates by itself (TMDb Helper and the other update-rule-1 add-ons, docs/design/UPDATE-ORIGIN.md 2.2) stayed
  on the old build.
* **Checks:** At most once per 24 h (setting
  ``update_check``), the feed is fetched in a background thread with a short timeout; the result is stored in
  the wizard settings and Home-window properties. A non-modal toast is shown only when the user enabled
  ``notify_updates`` (default off). The loop waits in ``waitForAbort`` steps of at most 1 s, so a profile
  switch or shutdown is never delayed.

``env`` (``kodi_glue.ServiceEnv`` in Kodi, a fake in tests) provides ``is_master()``, ``setting(id)``,
``set_setting(id, value)``, ``wait_for_abort(seconds)``, ``fetch_text(url, timeout)``, ``set_property(k, v)``,
``toast(msg)``, ``log(msg)``, ``now()`` (epoch seconds), ``build_name``, ``build_version``,
``wizard_version`` and ``buildfile``.
"""
import threading

from resources.libs.nikeflix import feed

CHECK_INTERVAL = 24 * 3600
FETCH_TIMEOUT = 5
MAX_WAIT = 30
RETRY_S = 3600      # an in-place update that failed or was interrupted is due again an hour later (next start), not a day
PROP_BUILD = "nikeflixfamilywizard.build_update"
PROP_WIZARD = "nikeflixfamilywizard.wizard_update"


def due(last_epoch, now, interval=CHECK_INTERVAL):
    try:
        last = float(last_epoch or 0)
    except (TypeError, ValueError):
        last = 0.0
    return now - last >= interval or now < last


def evaluate(text, build_name, build_version, wizard_version):
    """Pure: ``{"build": newer build version or "", "wizard": newer wizard version or ""}``."""
    parsed = feed.parse(text)
    b = feed.update_available(parsed, build_name, build_version)
    w = feed.wizard_update_available(parsed, wizard_version)
    return {"build": b["version"] if b else "", "wizard": w["version"] if w else ""}


def in_place(env, text, version):
    """NikeFlix 4.1.4: apply the newer build in place (inplace.py), keeping every profile. Runs in the background
    service of the master profile; any failure leaves the device as it was and is retried at the next due check."""
    entry = feed.update_available(feed.parse(text), env.build_name, env.build_version)
    if not entry:
        return "checked"
    runner = getattr(env, "apply_in_place", None)
    if runner is None:
        return "checked"
    env.log("[NikeFlix Wizard] updating NikeFlix to {0} in place (profiles kept)".format(version))
    try:
        report = runner(entry)
    except Exception as exc:   # rejected download or archive: nothing changed
        env.log("[NikeFlix Wizard] in-place update not applied: {0}".format(str(exc)[:200]))
        return "inplace-failed"
    if report.get("failed"):
        env.log("[NikeFlix Wizard] in-place update incomplete: {0}".format(", ".join(report["failed"])[:300]))
        return "inplace-partial"
    env.set_setting("buildversion", entry["version"])
    env.set_setting("latestversion", entry["version"])
    env.set_property(PROP_BUILD, "")
    env.log("[NikeFlix Wizard] NikeFlix {0} installed in place: {1} add-on(s)".format(entry["version"], len(report["updated"])))
    if env.setting("notify_updates") == "true":
        env.toast("NikeFlix updated to {0}. It finishes the next time NikeFlix starts.".format(entry["version"]))
    return "inplace-done"


def run(env):
    if not env.is_master():
        env.log("[NikeFlix Wizard] non-master profile: the master profile's wizard state is used")
    if env.setting("update_check") == "false":
        return "update-check-off"
    now = env.now()
    if not due(env.setting("lastupdatecheck"), now):
        return "not-due"

    box = {}

    def worker():
        try:
            box["text"] = env.fetch_text(env.buildfile, FETCH_TIMEOUT)
        except Exception as exc:  # network errors are expected offline; never surface them as UI
            box["error"] = str(exc)[:200]

    t = threading.Thread(target=worker, name="nikeflixfamilywizard-feed")
    t.daemon = True
    t.start()
    waited = 0
    while t.is_alive():
        if env.wait_for_abort(1):
            return "aborted"
        waited += 1
        if waited >= MAX_WAIT:
            env.log("[NikeFlix Wizard] feed check timed out")
            return "timeout"
    if "text" not in box:
        env.log("[NikeFlix Wizard] feed check failed: {0}".format(box.get("error", "")))
        return "fetch-failed"
    try:
        result = evaluate(box["text"], env.build_name, env.build_version, env.wizard_version)
    except feed.FeedError as exc:
        env.log("[NikeFlix Wizard] feed unreadable: {0}".format(exc))
        return "feed-invalid"
    env.set_setting("lastupdatecheck", str(int(now)))
    if result["build"]:
        env.set_setting("latestversion", result["build"])
    env.set_property(PROP_BUILD, result["build"])
    env.set_property(PROP_WIZARD, result["wizard"])
    if (result["build"] or result["wizard"]) and env.setting("notify_updates") == "true":
        what = "NikeFlix {0}".format(result["build"]) if result["build"] else "Wizard {0}".format(result["wizard"])
        env.toast("Update available: {0} (open the NikeFlix Wizard)".format(what))
    if result["build"] and env.setting("auto_update") != "false" and env.build_name:
        outcome = in_place(env, box["text"], result["build"])
        if outcome in ("inplace-failed", "inplace-partial"):
            env.set_setting("lastupdatecheck", str(int(now - CHECK_INTERVAL + RETRY_S)))
        return outcome
    return "checked"
