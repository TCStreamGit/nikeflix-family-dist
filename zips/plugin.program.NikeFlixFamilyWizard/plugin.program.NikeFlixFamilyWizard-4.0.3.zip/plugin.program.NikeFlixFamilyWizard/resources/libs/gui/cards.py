# SPDX-License-Identifier: GPL-2.0-or-later
"""NikeFlix Wizard card screens (P05-N002, Tanner 2026-11-17: "looks outdated; make it modern and smoother").

One home card with the build artwork and ONE primary action (Install / Update / Reinstall), one install card that
asks everything up front (backup, Fen 4), a phased progress screen instead of a chain of pop-ups, and a Tools card
that keeps backup, restore and maintenance. The install itself is unchanged: resources.libs.nikeflix.installer
runs exactly as before; CardInstallEnv only answers its questions from the install card and draws its progress.

Christmas Edition (P05 decision 9): from December 1 through December 26 the cards use the Christmas icon and
fanart (resources/media/christmas), from December 27 the usual ones, by date on the device.
"""
import datetime
import os

import xbmc
import xbmcgui

from resources.libs.common.config import CONFIG

SKIN, RES = "Default", "1080i"
ACTION_CLOSE = (9, 10, 13, 92, 110)       # parent dir, previous menu, stop, nav back, backspace

# control ids shared by the card XML files
PRIMARY, TOOLS, SETTINGS, CLOSE = 200, 201, 202, 203
OPT_BACKUP, OPT_FEN, INSTALL, CANCEL = 300, 301, 310, 311
PROGRESS_BAR = 400
TOOL_BASE = 500

PHASES = ("Download", "Verify", "Back up", "Remove old setup", "Install", "Finish")


def is_christmas(today=None):
    d = today or datetime.date.today()
    return d.month == 12 and 1 <= d.day <= 26


def art(name, today=None):
    """icon.png / fanart.jpg of the wizard: the Christmas copy in season, the usual one otherwise."""
    if is_christmas(today):
        p = os.path.join(CONFIG.ADDON_PATH, "resources", "media", "christmas", name)
        if os.path.isfile(p):
            return p
    return os.path.join(CONFIG.ADDON_PATH, name)


class Card(xbmcgui.WindowXMLDialog):
    """A card: window properties in, the clicked control id out (None when closed with Back)."""

    def __init__(self, *args, **kwargs):
        self.props = kwargs.pop("props", {})
        self.focus = kwargs.pop("focus", PRIMARY)
        self.toggles = dict(kwargs.pop("toggles", {}))
        self.result = None
        super(Card, self).__init__(*args)

    def onInit(self):
        self.setProperty("nfw.fanart", art("fanart.jpg"))
        self.setProperty("nfw.icon", art("icon.png"))
        self.setProperty("nfw.season", "christmas" if is_christmas() else "usual")
        for k, v in self.props.items():
            self.setProperty(k, v)
        for cid, on in self.toggles.items():
            try:
                self.getControl(cid).setSelected(bool(on))
            except (RuntimeError, TypeError):
                pass
        try:
            self.setFocusId(self.focus)
        except RuntimeError:
            pass

    def onClick(self, control_id):
        if control_id in self.toggles:
            self.toggles[control_id] = self.getControl(control_id).isSelected()
            return
        self.result = control_id
        self.close()

    def onAction(self, action):
        if action.getId() in ACTION_CLOSE:
            self.result = None
            self.close()


def show(xml, focus=PRIMARY, toggles=None, **props):
    w = Card(xml, CONFIG.ADDON_PATH, SKIN, RES, props=props, focus=focus, toggles=toggles or {})
    w.doModal()
    result, state = w.result, dict(w.toggles)
    del w
    return result, state


class _ProgressWindow(xbmcgui.WindowXMLDialog):
    """The progress screen ignores Back/Esc: a half-done wipe or install must never be left running behind Kodi."""

    def onAction(self, action):
        pass


class Progress(object):
    """Phased progress screen; the same calls as xbmcgui.DialogProgress (create/update/iscanceled/close)."""

    def __init__(self):
        self.win = None
        self.phase = 0

    def create(self, heading, line=""):
        self.win = _ProgressWindow("NikeFlixWizardProgress.xml", CONFIG.ADDON_PATH, SKIN, RES)
        self.win.setProperty("nfw.fanart", art("fanart.jpg"))
        self.win.setProperty("nfw.icon", art("icon.png"))
        self.win.setProperty("nfw.title", heading)
        self.win.show()
        self.set_phase(0, line)

    def set_phase(self, index, detail=None):
        self.phase = max(self.phase, index)
        if self.win is None:
            return
        for i, _ in enumerate(PHASES):
            state = "done" if i < self.phase else ("active" if i == self.phase else "todo")
            self.win.setProperty("nfw.phase.%d" % i, PHASES[i])
            self.win.setProperty("nfw.phase.%d.state" % i, state)
        if detail is not None:
            self.win.setProperty("nfw.detail", detail)

    def update(self, pct, text=""):
        if text:
            low = text.lower()
            if low.startswith("downloading"):
                self.set_phase(0)
            elif low.startswith("backing up"):
                self.set_phase(2)
            elif low.startswith("removing"):
                self.set_phase(3)
            elif low.startswith("installing"):
                self.set_phase(4)
            self.win and self.win.setProperty("nfw.detail", text)
        if self.win is not None:
            try:
                self.win.getControl(PROGRESS_BAR).setPercent(float(max(0, min(100, pct))))
            except RuntimeError:
                pass
            self.win.setProperty("nfw.pct", "%d%%" % int(pct))

    def iscanceled(self):
        return False      # a half-done wipe or install must never be left behind

    def close(self):
        if self.win is not None:
            self.win.close()
            del self.win
            self.win = None


def _install_env_class():
    from resources.libs.nikeflix import kodi_glue

    class CardInstallEnv(kodi_glue.InstallEnv):
        """Answers the installer from the install card (asked once, up front) and draws the phased progress."""

        def __init__(self, config, choices, progress):
            super(CardInstallEnv, self).__init__(config, xbmcgui.Dialog(), progress)
            self.choices = choices

        def confirm_install(self, entry, compat):
            return True     # the install card was the confirmation

        def ask_backup(self, default_root):
            self.dp.set_phase(1, "Download checked against its published SHA-256")
            if not self.choices["backup"]:
                self.dp.set_phase(3, "No backup (your choice)")
                return "skip", None
            root = self.config.get_setting("backup_path") or default_root
            root = kodi_glue.translate(root) if root.startswith("special://") else root
            self.dp.set_phase(2, "Backing up to {0}".format(root))
            return "backup", root

        def want_fen(self):
            self.dp.set_phase(5, "Setting up the five profiles")
            return self.choices["fen"]

    return CardInstallEnv


def home():
    """Wizard home card. Loops until closed: install/update, Tools, Settings."""
    from resources.libs import check
    from resources.libs.nikeflix import feed

    force = False
    while True:
        xbmc.executebuiltin("ActivateWindow(busydialognocancel)")
        try:
            parsed = check.load_feed(force=force)
        finally:
            xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
        force = False
        builds = (parsed or {}).get("builds") or []
        entry = next((b for b in builds if b["name"] == CONFIG.BUILDNAME), builds[0] if builds else None)
        wiz = check.wizard_entry_if_newer() if CONFIG.AUTOUPDATE == "Yes" else None
        props = {"nfw.title": "NikeFlix", "nfw.wizard": "Wizard {0}".format(CONFIG.ADDON_VERSION)}
        action = None
        if wiz:
            props.update({"nfw.status": "A newer NikeFlix Wizard ({0}) is ready.".format(wiz["version"]),
                          "nfw.detail": "Update the wizard first; then install or update NikeFlix from it.",
                          "nfw.primary": "Update the wizard"})
            action = "wizardupdate"
        elif entry is None:
            props.update({"nfw.status": "The NikeFlix build feed is unavailable right now." if parsed is None
                          else "No NikeFlix build is published yet.",
                          "nfw.detail": "Check the internet connection, then try again.",
                          "nfw.primary": "Try again"})
            action = "retry"
        else:
            props["nfw.title"] = "{0} {1}".format(entry["name"], entry["version"])
            props["nfw.description"] = entry.get("description", "")
            if not CONFIG.BUILDNAME:
                props.update({"nfw.status": "NikeFlix is not installed on this device yet.",
                              "nfw.primary": "Install NikeFlix {0}".format(entry["version"])})
            elif feed.update_available(parsed, CONFIG.BUILDNAME, CONFIG.BUILDVERSION):
                props.update({"nfw.status": "NikeFlix {0} is installed. Version {1} is ready.".format(
                    CONFIG.BUILDVERSION, entry["version"]),
                    "nfw.primary": "Update to {0}".format(entry["version"])})
            else:
                props.update({"nfw.status": "NikeFlix {0} is installed and up to date.".format(CONFIG.BUILDVERSION),
                              "nfw.primary": "Reinstall NikeFlix {0}".format(entry["version"])})
            action = "install"
        clicked, _ = show("NikeFlixWizardHome.xml", **props)
        if clicked is None or clicked == CLOSE:
            return
        if clicked == TOOLS:
            if tools():
                return   # a tool list opened in Kodi; the home card does not cover it
        elif clicked == SETTINGS:
            CONFIG.open_settings(CONFIG.ADDON_ID)
        elif clicked == PRIMARY:
            if action == "wizardupdate":
                xbmc.executebuiltin("RunPlugin(plugin://{0}/?mode=wizardupdate)".format(CONFIG.ADDON_ID))
                return
            if action == "retry":
                force = True
            if action == "install":
                if install(entry) is not None:
                    return   # Kodi is closing


def install(entry):
    """Install card -> phased progress -> finish card. Returns None when cancelled."""
    from resources.libs import install as legacy_install
    from resources.libs.common import logging
    from resources.libs.common import tools as ctools
    from resources.libs.nikeflix import feed
    from resources.libs.nikeflix import installer
    from resources.libs.nikeflix import kodi_glue
    from resources.libs.nikeflix import wipe

    if not kodi_glue.is_master():
        show("NikeFlixWizardMessage.xml", focus=PRIMARY, **{
            "nfw.title": "Master profile only", "nfw.status": "NikeFlix can only be installed from the master profile.",
            "nfw.primary": "OK"})
        return None
    compat = feed.kodi_compat(entry["kodi"], kodi_glue.translate_version())
    if compat == "block":
        show("NikeFlixWizardMessage.xml", **{"nfw.title": "Not for this Kodi",
             "nfw.status": "This build is for Kodi {0}; this device runs Kodi {1}.".format(entry["kodi"], kodi_glue.translate_version()),
             "nfw.primary": "OK"})
        return None
    root = CONFIG.get_setting("backup_path") or wipe.default_backup_root(CONFIG.HOME)
    fen_mode = CONFIG.get_setting("fen_install") or "0"
    props = {"nfw.title": "Install {0} {1}".format(entry["name"], entry["version"]),
             "nfw.status": "A clean install replaces every profile, setting and add-on on this device. Accounts "
                           "(Trakt, debrid, Live TV) are set up again in each profile afterwards.",
             "nfw.detail": "Backup folder: {0}".format(root),
             "nfw.warning": "" if compat == "ok" else "Built for Kodi {0}; this device runs Kodi {1}.".format(
                 entry["kodi"], kodi_glue.translate_version()),
             "nfw.primary": "Install"}
    clicked, state = show("NikeFlixWizardInstall.xml", focus=INSTALL, toggles={
        OPT_BACKUP: CONFIG.get_setting("backup_before_install") != "false",
        OPT_FEN: fen_mode != "2"}, **props)
    if clicked != INSTALL:
        return None
    choices = {"backup": bool(state.get(OPT_BACKUP)), "fen": bool(state.get(OPT_FEN))}
    if not choices["backup"]:
        sure, _ = show("NikeFlixWizardMessage.xml", **{
            "nfw.title": "Install without a backup?",
            "nfw.status": "Everything on this device is removed and nothing is saved first.",
            "nfw.detail": "Press Back to go back and keep the backup.", "nfw.primary": "Install without backup"})
        if sure != PRIMARY:
            return None
    logging.log("[Build Install] card choices: backup={0} fen={1}".format(choices["backup"], choices["fen"]),
                level=xbmc.LOGINFO)

    progress = Progress()
    progress.create("Installing {0} {1}".format(entry["name"], entry["version"]), "Downloading")
    env = _install_env_class()(CONFIG, choices, progress)
    try:
        report = installer.install_build(env, entry, keep=legacy_install.keep_options())
    except Exception as e:  # InstallAborted, and any download/disk error: never leave the progress screen up
        progress.close()
        logging.log("[Build Install] stopped: {0}: {1}".format(type(e).__name__, e), level=xbmc.LOGINFO)
        show("NikeFlixWizardMessage.xml", **{"nfw.title": "Install stopped", "nfw.status": str(e)[:300],
                                             "nfw.detail": "Nothing on this device was changed unless it says so above."
                                             if isinstance(e, installer.InstallAborted) else
                                             "The install was interrupted. Run Install again before using Kodi.",
                                             "nfw.primary": "OK"})
        return None
    progress.set_phase(len(PHASES), "")
    progress.close()

    if "done" not in report["steps"]:
        show("NikeFlixWizardMessage.xml", **{"nfw.title": "The install did not finish",
             "nfw.status": "See the wizard log. Kodi will now close.", "nfw.primary": "Close Kodi"})
        ctools.kill_kodi(over=True)
        return False

    CONFIG.set_setting("buildname", entry["name"])
    CONFIG.set_setting("buildversion", entry["version"])
    CONFIG.set_setting("latestversion", entry["version"])
    CONFIG.set_setting("installed", "true")
    CONFIG.set_setting("extract", "100")
    CONFIG.set_setting("errors", str(len(report["extract"]["errors"])))
    logging.log("[Build Install] {0} {1}: steps={2} seed_drift={3} fen={4} extract_errors={5}".format(
        entry["name"], entry["version"], ",".join(report["steps"]), len(report["seed_drift"]),
        report["fen"], len(report["extract"]["errors"])), level=xbmc.LOGINFO)
    notes = []
    if report["seed_drift"] or report["extract"]["errors"]:
        notes.append("Warnings: {0} seed, {1} file(s) not written (see the wizard log).".format(
            len(report["seed_drift"]), len(report["extract"]["errors"])))
    if report["fen"] == "unavailable":
        notes.append("Fen 4 backup player unavailable (download or check failed); install it later from Tools.")
    show("NikeFlixWizardMessage.xml", **{"nfw.title": "{0} {1} is installed".format(entry["name"], entry["version"]),
         "nfw.status": "Kodi closes now. Start it again and pick your profile.",
         "nfw.detail": " ".join(notes), "nfw.primary": "Close Kodi"})
    ctools.kill_kodi(over=True)
    return True


TOOLS_ITEMS = (
    ("Backup and restore", "Save this device's setup, or put a saved one back.", "mode=maint&name=backup"),
    ("Clean up", "Clear cache, packages and thumbnails to free space.", "mode=maint&name=clean"),
    ("Install or repair Fen 4", "The backup player, from its author, hash-checked.", "mode=installfen"),
    ("Logs and errors", "View errors in the Kodi log or upload it.", "mode=maint&name=logging"),
    ("All maintenance tools", "The full list of maintenance options.", "mode=maint"),
)


def tools():
    """Tools card: backup, restore and maintenance, in the same style; each opens the existing tool."""
    props = {"nfw.title": "Tools", "nfw.status": "Backup, restore and maintenance for this device."}
    for i, (label, desc, _) in enumerate(TOOLS_ITEMS):
        props["nfw.tool.%d" % i] = label
        props["nfw.tool.%d.desc" % i] = desc
    clicked, _ = show("NikeFlixWizardTools.xml", focus=TOOL_BASE, **props)
    if clicked is None or not (TOOL_BASE <= clicked < TOOL_BASE + len(TOOLS_ITEMS)):
        return False
    query = TOOLS_ITEMS[clicked - TOOL_BASE][2]
    if query.startswith("mode=maint"):
        xbmc.executebuiltin("ActivateWindow(Programs,plugin://{0}/?{1},return)".format(CONFIG.ADDON_ID, query))
        return True
    xbmc.executebuiltin("RunPlugin(plugin://{0}/?{1})".format(CONFIG.ADDON_ID, query))
    return False
