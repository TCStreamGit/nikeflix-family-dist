# SPDX-License-Identifier: GPL-2.0-or-later
# Copyright (C) 2026 NikeFlix (derived work of OpenWizard, Copyright (C) 2019 drinfernoo; see NOTICE.txt)
"""NikeFlix Family distribution endpoints (T23, plan §H).

``nikeflix-family-dist`` is the future public Family dist repository (T72). The host below is the placeholder agreed for
T23; nothing is published by this change. Clients read these URLs anonymously: no token is ever embedded
(plan §B8).
"""
EDITION = "family"
WIZARD_ID = "plugin.program.NikeFlixFamilyWizard"
REPOSITORY_ID = "repository.NikeFlixFamily"

DIST_BASE = "https://raw.githubusercontent.com/TCStreamGit/nikeflix-family-dist/main/"
RELEASES_BASE = "https://github.com/TCStreamGit/nikeflix-family-dist/releases/download/"

BUILDFILE = DIST_BASE + "builds.txt"
NOTIFYFILE = DIST_BASE + "notify.txt"

# Exact build and wizard URLs in the feed must start with one of these (raw files or GitHub Release assets).
ALLOWED_URL_PREFIXES = (DIST_BASE, RELEASES_BASE)

KODI_TARGET = "21.3"
