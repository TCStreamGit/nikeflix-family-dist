# SPDX-License-Identifier: GPL-2.0-or-later
# Copyright (C) 2026 NikeFlix
"""In-place build update (NikeFlix 4.1.4): a newer build reaches the device without a wipe.

A clean install removes every profile. Here only the build's add-ons change; userdata (every profile, its settings,
sign-ins, history and databases) is never touched:

1. the build is downloaded and checked exactly as for an install (installer.prepare: feed entry, sha256, size,
   archive layout, the Addons33.db seed);
2. each add-on of the build that is missing or has another version than the installed one is extracted to a work
   folder and swapped in with two renames (the old folder comes back if a swap fails); the wizard itself is skipped
   (it updates itself from the repository). NikeFlix 4.1.7: a folder the system refuses to rename (the skin in use
   on Windows: PermissionError) is updated file by file instead, addon.xml last, so a merge that stops half-way
   still reads as the old version and is retried at the next check;
3. the build's add-on seed is merged into the master database (NikeFlix 4.1.7: only the build's own add-ons' rows;
   Fen 4 and every other add-on keep theirs) and checked against the profile databases, so a new add-on is
   registered and enabled with NikeFlix's origin and rules (a bare extraction would leave it disabled, T24);
4. the caller asks Kodi to rescan local add-ons; running add-ons use the new files from the next start.

`env` is kodi_glue.InPlaceEnv in Kodi and a fake in tests.
"""
import filecmp
import os
import shutil
import uuid
import xml.etree.ElementTree as ET
import zipfile

from resources.libs.nikeflix import installer
from resources.libs.nikeflix import integrity
from resources.libs.nikeflix import seed


def installed_version(addons_dir, addon_id):
    try:
        return ET.parse(os.path.join(addons_dir, addon_id, "addon.xml")).getroot().get("version") or ""
    except (OSError, ET.ParseError):
        return ""


def build_versions(zpath, members):
    out = {}
    with zipfile.ZipFile(zpath) as zf:
        for info, parts in members:
            if len(parts) == 3 and parts[0] == "addons" and parts[2] == "addon.xml":
                try:
                    out[parts[1]] = ET.fromstring(zf.read(info)).get("version") or ""
                except ET.ParseError:
                    pass
    return out


def _nikeflix_level(version):
    """The NikeFlix patch level of a managed add-on version (``6.7.92+nikeflix.14`` -> 14; none -> 0)."""
    meta = version.split("+", 1)[1] if "+" in version else ""
    if meta.startswith("nikeflix."):
        try:
            return int(meta.split(".", 1)[1])
        except ValueError:
            return 0
    return 0


def is_older(candidate, installed):
    """NikeFlix 4.1.7: True when the build's add-on is older than the installed one (Kodi's order, then the NikeFlix
    patch level, which Kodi's comparison ignores). An unreadable version is never 'older'."""
    from resources.libs.nikeflix import versions
    try:
        c = versions.compare(candidate, installed)
    except ValueError:
        return False
    if c:
        return c < 0
    return _nikeflix_level(candidate) < _nikeflix_level(installed)


def changed_addons(build, addons_dir, wizard_id):
    """Ids whose build version differs from the installed one (or that are not installed), the wizard excluded.
    NikeFlix 4.1.7: never an older one over a newer one (a device whose build is not recorded, set up from a newer
    archive than the feed's, or an add-on Kodi already updated)."""
    out = []
    for a, v in build.items():
        if a == wizard_id:
            continue
        have = installed_version(addons_dir, a)
        if have != v and not (have and is_older(v, have)):
            out.append(a)
    return sorted(out)


NEW_SUFFIX, OLD_SUFFIX = ".nikeflix-new", ".nikeflix-old"


def _sweep(target):
    """Leftovers of an earlier merge: staged copies and files moved aside (deletable once nothing holds them)."""
    for root, _dirs, files in os.walk(target):
        for name in files:
            if name.endswith(NEW_SUFFIX) or name.endswith(OLD_SUFFIX):
                try:
                    os.remove(os.path.join(root, name))
                except OSError:
                    pass


def _swap_file(tmp, dst):
    try:
        os.replace(tmp, dst)
        return
    except OSError:
        if not os.path.exists(dst):
            raise
    aside = dst + OLD_SUFFIX
    if os.path.exists(aside):
        os.remove(aside)
    os.rename(dst, aside)          # an open file can usually be renamed; the program keeps reading its copy
    try:
        os.replace(tmp, dst)
    except OSError:
        os.rename(aside, dst)
        raise


def merge_in(new, target):
    """Update `target` from `new` file by file (the folder stays where it is). Every file is first staged next to its
    target (`.nikeflix-new`); if one cannot be staged, the staged copies are removed and nothing has changed. Then the
    files are swapped in, files the build no longer has are removed where possible, and addon.xml (the version Kodi and
    this updater read) goes last, so a merge that stops half-way still reads as the old version and is retried."""
    _sweep(target)
    staged, wanted, manifest = [], set(), None
    try:
        for root, _dirs, files in os.walk(new):
            rel = os.path.relpath(root, new)
            dst_dir = target if rel == "." else os.path.join(target, rel)
            os.makedirs(dst_dir, exist_ok=True)
            for name in files:
                wanted.add(os.path.normcase(os.path.normpath(os.path.join(rel, name))))
                dst = os.path.join(dst_dir, name)
                if os.path.isfile(dst) and filecmp.cmp(os.path.join(root, name), dst, shallow=False):
                    continue   # unchanged: never touched (the skin's Textures.xbt stays open in Kodi on Windows)
                shutil.copyfile(os.path.join(root, name), dst + NEW_SUFFIX)
                if rel == "." and name == "addon.xml":
                    manifest = dst
                else:
                    staged.append(dst)
    except OSError:
        for dst in staged + ([manifest] if manifest else []):
            try:
                os.remove(dst + NEW_SUFFIX)
            except OSError:
                pass
        raise
    failed = 0
    for dst in staged:
        try:
            _swap_file(dst + NEW_SUFFIX, dst)
        except OSError:
            failed += 1
    if failed:
        _sweep(target)
        raise OSError("%d file(s) could not be replaced" % failed)
    for root, _dirs, files in os.walk(target):
        for name in files:
            rel_file = os.path.normcase(os.path.normpath(os.path.relpath(os.path.join(root, name), target)))
            if rel_file not in wanted and not name.endswith(NEW_SUFFIX):
                try:
                    os.remove(os.path.join(root, name))
                except OSError:
                    pass
    if manifest:
        _swap_file(manifest + NEW_SUFFIX, manifest)


def swap_in(zpath, members, addon_id, addons_dir):
    work = os.path.join(addons_dir, ".nikeflix-inplace-" + uuid.uuid4().hex[:8])
    try:
        own = [(i, p) for i, p in members if len(p) >= 2 and p[0] == "addons" and p[1] == addon_id]
        integrity.extract_members(zpath, own, work)
        new = os.path.join(work, "addons", addon_id)
        target = os.path.join(addons_dir, addon_id)
        old = os.path.join(work, "old")
        os.makedirs(old)
        moved = False
        if os.path.exists(target):
            try:
                os.rename(target, os.path.join(old, addon_id))
            except PermissionError:
                merge_in(new, target)   # in use (the active skin on Windows): file by file
                return "merged"
            moved = True
        try:
            os.rename(new, target)
        except OSError:
            if moved:
                os.rename(os.path.join(old, addon_id), target)
            raise
        return "swapped"
    finally:
        shutil.rmtree(work, ignore_errors=True)


def repair_fen(env):
    """NikeFlix 4.1.7: Fen 4 installed by the wizard (its receipt exists) whose row an earlier in-place update removed
    is registered again as the wizard installs it (enabled, origin '', update rule 1). A Fen the household disabled
    itself (disabledReason set) is left alone. Returns True when the row was repaired."""
    from resources.libs.nikeflix import fen
    if not os.path.isfile(fen.receipt_path(env.userdata)) or not os.path.isdir(os.path.join(env.addons_dir, fen.FEN_ID)):
        return False
    if not os.path.isfile(env.live_addons_db):
        return False
    row = seed.addon_row(env.live_addons_db, fen.FEN_ID)
    if row is not None and (int(row[0]) == 1 or int(row[2] or 0) != 0):
        return False
    seed.register_addon(env.live_addons_db, fen.FEN_ID, origin="", enabled=True, rule=fen.RULE_USER_DISABLED_AUTO_UPDATE)
    return True


def update(env, entry):
    """Returns a report (ids and counts, no paths of user data). Raises installer.InstallAborted before any change
    when the download or the archive is rejected."""
    zpath, members, seed_path = installer.prepare(env, entry)
    report = {"build": entry.get("name"), "version": entry.get("version"), "updated": [], "failed": []}
    try:
        build = build_versions(zpath, members)
        for aid in changed_addons(build, env.addons_dir, env.wizard_id):
            try:
                swap_in(zpath, members, aid, env.addons_dir)
                report["updated"].append(aid)
            except (OSError, integrity.ArchiveError) as exc:
                report["failed"].append("%s: %s" % (aid, type(exc).__name__))
        if report["updated"]:
            report["seed"] = seed.merge_seed(env.live_addons_db, seed_path)   # 4.1.7: the build's rows only
            unseeded = sorted(installer.addon_ids(members) - seed.seeded_ids(seed_path) - {env.wizard_id})
            report["profile_seeds"], report["profile_seed_missing"] = installer._profile_seeds(env, members, unseeded)
        try:
            report["fen_repaired"] = repair_fen(env)
        except Exception as exc:   # never fails the update itself
            report["fen_repaired"] = "error: %s" % type(exc).__name__
    finally:
        for p in (zpath, seed_path):
            if os.path.exists(p):
                os.remove(p)
        installer._drop_seed_copies(env)
    return report
