# SPDX-License-Identifier: GPL-2.0-or-later
# Copyright (C) 2026 NikeFlix (derived work of OpenWizard, Copyright (C) 2019 drinfernoo; see NOTICE.txt)
"""Pre-wipe validation of every profile's ``Addons33.db`` seed in a NikeFlix build archive (T23/T61, T24 policy).

NikeFlix profiles have their own databases, so the build ships one generated seed per profile (platform
``tools/nfbuild/addons_db_seed.py``). Before the installer backs up or wipes anything, ``validate_build`` checks:

* the archive's ``userdata/profiles.xml`` names the profiles; every profile (master included) has **exactly one**
  seed, and no profile folder in the archive is missing from ``profiles.xml``;
* each seed is a Kodi 21 v33 DB with only ``installed``/``update_rules`` rows (no carried-over metadata);
* the edition: no row for the other edition's repository or wizard; the required NikeFlix components are enabled
  with this edition's repository origin;
* origins: an enabled row has this edition's repository origin, except the documented per-profile policy rows
  (``PROFILE_POLICY_IDS``, official origin); disabled rows are the register's DIS rows or a policy row turned off;
* update rules are only ``USER_DISABLED_AUTO_UPDATE`` (1);
* every profile seed equals the master seed except the policy rows (no mismatched or stale seed);
* every add-on folder the archive ships is seeded, unless it is an approved exception (``APPROVED_UNSEEDED``).

Any problem raises ``SeedPolicyError`` and the installer aborts with nothing changed.
"""
import os
import re
import sqlite3
import xml.etree.ElementTree as ET
import zipfile

from resources.libs.nikeflix import distconfig
from resources.libs.nikeflix import seed

OFFICIAL_ORIGIN = "repository.xbmc.org"
ORIGIN_SYSTEM = "b6a50484-93a0-4afb-a01c-8d17e059feda"  # Kodi ORIGIN_SYSTEM
RULE_USER_DISABLED_AUTO_UPDATE = 1
DISABLED_BY_USER = 1
# Mirrors platform addons_db_seed.PROFILE_POLICY: rows that legitimately differ between profiles.
PROFILE_POLICY_IDS = ("pvr.iptvsimple",)
REQUIRED_ENABLED = ("skin.nikeflix", "service.nikeflix", "plugin.video.themoviedb.helper", "script.skinshortcuts",
                    distconfig.WIZARD_ID, distconfig.REPOSITORY_ID)
OTHER_EDITION_IDS = ("repository.NikeFlixFamily", "plugin.program.NikeFlixFamilyWizard") \
    if distconfig.EDITION == "regular" else ("repository.NikeFlix", "plugin.program.nikeflixwizard")
# Add-ons a build may ship WITHOUT a seed row, with the row the installer then writes. Empty: every shipped add-on
# must be seeded. (Fen 4 is not shipped in the archive; fen.py installs it separately as CX-LIC: origin '', rule 1.)
APPROVED_UNSEEDED = {}
METADATA_TABLES = ("addons", "repo", "addonlinkrepo", "package")
SEED_NAME = seed.DB_NAME


class SeedPolicyError(Exception):
    pass


def _ro(path):
    return sqlite3.connect("file:{0}?mode=ro".format(path.replace("\\", "/")), uri=True)


def check_policy(path, label):
    """Problems (strings) for one extracted seed."""
    try:
        seed.check_seed_file(path)
    except seed.SeedError as exc:
        return ["{0}: {1}".format(label, exc)]
    problems = []
    con = _ro(path)
    try:
        for t in METADATA_TABLES:
            if con.execute("SELECT COUNT(*) FROM {0}".format(t)).fetchone()[0]:
                problems.append("{0}: table {1} is not empty (seeds carry no metadata)".format(label, t))
        rows = {r[0]: (int(r[1]), r[2], int(r[3])) for r in con.execute(
            "SELECT addonID, enabled, origin, disabledReason FROM installed")}
        rules = con.execute("SELECT addonID, updateRule FROM update_rules").fetchall()
    finally:
        con.close()
    for aid in OTHER_EDITION_IDS:
        if aid in rows:
            problems.append("{0}: row for the other edition ({1})".format(label, aid))
    for aid in REQUIRED_ENABLED:
        r = rows.get(aid)
        if not r or r[0] != 1 or r[1] != distconfig.REPOSITORY_ID:
            problems.append("{0}: {1} must be enabled with origin {2}".format(label, aid, distconfig.REPOSITORY_ID))
    for aid, (enabled, origin, reason) in sorted(rows.items()):
        if aid in PROFILE_POLICY_IDS:
            if origin != OFFICIAL_ORIGIN or (not enabled and reason != DISABLED_BY_USER):
                problems.append("{0}: policy row {1} has origin {2!r}/reason {3}".format(label, aid, origin, reason))
        elif enabled:
            if origin != distconfig.REPOSITORY_ID:
                problems.append("{0}: {1} enabled with origin {2!r}".format(label, aid, origin))
        elif reason != DISABLED_BY_USER or origin not in ("", ORIGIN_SYSTEM):
            problems.append("{0}: {1} disabled with origin {2!r}/reason {3}".format(label, aid, origin, reason))
    for aid, rule in rules:
        if int(rule) != RULE_USER_DISABLED_AUTO_UPDATE:
            problems.append("{0}: {1} has update rule {2}".format(label, aid, rule))
    return problems


def comparable(path):
    con = _ro(path)
    try:
        inst = sorted(r for r in con.execute("SELECT addonID, enabled, origin, disabledReason FROM installed")
                      if r[0] not in PROFILE_POLICY_IDS)
        rules = sorted(con.execute("SELECT addonID, updateRule FROM update_rules").fetchall())
        return inst, rules
    finally:
        con.close()


def seeded_ids(path):
    con = _ro(path)
    try:
        return {r[0] for r in con.execute("SELECT addonID FROM installed")}
    finally:
        con.close()


def profile_dirs(zpath):
    """Non-master profile folders named by the archive's profiles.xml (``profiles/<dir>/`` -> ``<dir>``)."""
    with zipfile.ZipFile(zpath) as zf:
        names = [n for n in zf.namelist() if n.replace("\\", "/") == "userdata/profiles.xml"]
        if len(names) != 1:
            raise SeedPolicyError("archive must contain exactly one userdata/profiles.xml")
        root = ET.fromstring(zf.read(names[0]))
    dirs = []
    for p in root.findall("profile"):
        d = (p.findtext("directory") or "").strip().replace("\\", "/")
        if d.startswith("special://masterprofile"):
            continue
        m = re.match(r"^profiles/([^/]+)/?$", d)
        if not m:
            raise SeedPolicyError("profile directory {0!r} is not under profiles/".format(d))
        dirs.append(m.group(1))
    if len(dirs) != len(set(dirs)):
        raise SeedPolicyError("profiles.xml names a profile folder twice")
    return dirs


def validate_build(zpath, members, workdir, wizard_id):
    """Extract and check every profile seed into ``workdir``. Returns ``{"master": path, "<dir>": path}``."""
    dirs = profile_dirs(zpath)
    counts, folders = {}, set()
    for _, parts in members:
        parts = tuple(parts)
        if len(parts) >= 4 and parts[:2] == ("userdata", "profiles"):
            folders.add(parts[2])
        if parts == ("userdata", "Database", SEED_NAME):
            counts["master"] = counts.get("master", 0) + 1
        elif len(parts) == 5 and parts[:2] == ("userdata", "profiles") and parts[3:] == ("Database", SEED_NAME):
            counts[parts[2]] = counts.get(parts[2], 0) + 1
    problems = []
    for extra in sorted(folders - set(dirs)):
        problems.append("profile folder {0} is not in profiles.xml".format(extra))
    for key in ["master"] + dirs:
        n = counts.get(key, 0)
        if n != 1:
            problems.append("{0}: {1} Addons33.db seed(s), need exactly 1".format(key, n))
    for key in sorted(set(counts) - {"master"} - set(dirs)):
        problems.append("seed for unknown profile folder {0}".format(key))
    if problems:
        raise SeedPolicyError("; ".join(problems))
    paths = {}
    with zipfile.ZipFile(zpath) as zf:
        for key in ["master"] + dirs:
            member = "userdata/Database/" + SEED_NAME if key == "master" else \
                "userdata/profiles/{0}/Database/{1}".format(key, SEED_NAME)
            out = os.path.join(workdir, "seeds", key if key == "master" else "p_" + re.sub(r"[^\w.-]", "_", key), SEED_NAME)
            os.makedirs(os.path.dirname(out), exist_ok=True)
            with open(out, "wb") as fh:
                fh.write(zf.read(member))
            paths[key] = out
    for key, path in paths.items():
        problems += check_policy(path, key)
    if not problems:
        ref = comparable(paths["master"])
        for key in dirs:
            if comparable(paths[key]) != ref:
                problems.append("{0}: seed differs from the master seed beyond the profile policy".format(key))
    shipped = set()
    for _, parts in members:
        if len(parts) == 3 and parts[0] == "addons" and parts[2] == "addon.xml":
            shipped.add(parts[1])
    if not problems:
        unseeded = sorted(shipped - seeded_ids(paths["master"]) - {wizard_id})
        unapproved = [a for a in unseeded if a not in APPROVED_UNSEEDED]
        if unapproved:
            problems.append("add-ons shipped without a seed row (not approved): {0}".format(", ".join(unapproved)))
    if problems:
        raise SeedPolicyError("; ".join(problems))
    return paths
