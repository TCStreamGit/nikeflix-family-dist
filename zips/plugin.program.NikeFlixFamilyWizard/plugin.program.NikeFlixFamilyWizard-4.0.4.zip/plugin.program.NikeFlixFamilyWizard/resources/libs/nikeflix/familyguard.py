# SPDX-License-Identifier: GPL-2.0-or-later
# Copyright (C) 2026 NikeFlix (derived work of OpenWizard, Copyright (C) 2019 drinfernoo; see NOTICE.txt)
"""Family edition: the wizard never erases a device's existing Family profiles (T70/T75, plan B4a).

The Regular wizard's clean install wipes every profile, setting and database. A Family device holds each person's
own sign-ins (Trakt, debrid, YouTube), watched history and databases, which must survive the move to the new build.
That move is the NikeFlix migration (``tools/nfmigrate`` in the platform repository: plan, apply into a new folder,
per-profile isolation proof), run as the gated device task T75. So on the Family edition:

* a FRESH device installs exactly like Regular. Fresh is defined positively: only the master profile, no profile
  folders, no ``passwords.xml``, no add-on data except Kodi's own defaults and this wizard's, and no watched or
  resume rows in the video database;
* anything else is a lived-in device: every destructive wizard path (build install, Fresh Start, restore, Remove all
  add-on data, Purge databases) is refused before it changes anything, with a plain message;
* a build install that THIS wizard started on a fresh device (``family-install-started.json`` in its own data,
  removed when the install finishes) may be retried, so an interrupted install never strands the device.

``existing_state`` reports only counts and add-on ids, never profile names, paths or values.
"""
import json
import os
import sqlite3
import xml.etree.ElementTree as ET

from resources.libs.nikeflix import distconfig

# addon_data folders a fresh Kodi 21 (or this wizard) creates on its own
FRESH_ADDON_DATA_PREFIXES = ("peripheral.", "skin.estuary", "service.xbmc.versioncheck", "inputstream.",
                             "screensaver.xbmc.", "visualization.", "resource.", "script.module.",
                             "plugin.program.NikeFlixFamilyWizard")
INSTALL_MARKER = "family-install-started.json"

MESSAGE = ("This device already has NikeFlix Family profiles with sign-ins and watch history. The wizard will not "
           "erase or overwrite them. This device moves to the new NikeFlix Family build with the NikeFlix migration, "
           "which keeps each person's sign-ins and history. Nothing was changed.")


def _profile_entries(userdata):
    path = os.path.join(userdata, "profiles.xml")
    if not os.path.isfile(path):
        return 0
    try:
        return len(ET.parse(path).getroot().findall("profile"))
    except (ET.ParseError, OSError):
        return -1   # unreadable: treat as lived-in (never wipe what cannot be understood)


def _has_files(path):
    for _dp, _dn, files in os.walk(path):
        if files:
            return True
    return False


def _video_db_rows(userdata):
    """Watched/resume rows in the master video databases (read-only); -1 when a database cannot be read."""
    dbdir = os.path.join(userdata, "Database")
    total = 0
    if not os.path.isdir(dbdir):
        return 0
    for fn in sorted(os.listdir(dbdir)):
        if not (fn.startswith("MyVideos") and fn.endswith(".db")):
            continue
        uri = "file:" + os.path.join(dbdir, fn).replace("\\", "/") + "?mode=ro"
        try:
            con = sqlite3.connect(uri, uri=True)
            try:
                total += con.execute("SELECT COUNT(*) FROM files WHERE playCount > 0").fetchone()[0]
                total += con.execute("SELECT COUNT(*) FROM bookmark").fetchone()[0]
            finally:
                con.close()
        except sqlite3.Error:
            if os.path.getsize(os.path.join(dbdir, fn)) > 0:
                return -1
    return total


def install_marker_path(home):
    return os.path.join(home, "userdata", "addon_data", distconfig.WIZARD_ID, INSTALL_MARKER)


def existing_state(home):
    """Reasons (counts and add-on ids only) why `home` is not a fresh device; [] for a fresh device."""
    userdata = os.path.join(home, "userdata")
    reasons = []
    entries = _profile_entries(userdata)
    if entries < 0:
        reasons.append("profiles.xml unreadable")
    elif entries > 1:
        reasons.append("profiles: %d" % entries)
    pdir = os.path.join(userdata, "profiles")
    if os.path.isdir(pdir):
        lived = [d for d in os.listdir(pdir) if os.path.isdir(os.path.join(pdir, d)) and _has_files(os.path.join(pdir, d))]
        if lived:
            reasons.append("profile folders: %d" % len(lived))
    if os.path.isfile(os.path.join(userdata, "passwords.xml")):
        reasons.append("saved passwords")
    adir = os.path.join(userdata, "addon_data")
    other = []
    if os.path.isdir(adir):
        for aid in sorted(os.listdir(adir)):
            if aid.startswith(FRESH_ADDON_DATA_PREFIXES) or not _has_files(os.path.join(adir, aid)):
                continue
            other.append(aid)
    if other:
        reasons.append("add-on data: " + ", ".join(other))
    rows = _video_db_rows(userdata)
    if rows < 0:
        reasons.append("video database unreadable")
    elif rows:
        reasons.append("watched or resume rows: %d" % rows)
    return reasons


def refuse_reasons(home, edition=None, allow_own_install=False):
    """Non-empty only on the Family edition, for a device that is not fresh. `allow_own_install`: a build install
    this wizard started on a fresh device (its marker exists) may run again."""
    if (edition or distconfig.EDITION) != "family":
        return []
    if allow_own_install and os.path.isfile(install_marker_path(home)):
        return []
    return existing_state(home)


def mark_install_started(home, version):
    path = install_marker_path(home)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        json.dump({"version": version}, fh)


def clear_install_marker(home):
    try:
        os.remove(install_marker_path(home))
    except OSError:
        pass
