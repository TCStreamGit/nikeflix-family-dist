# SPDX-License-Identifier: GPL-2.0-or-later
# Copyright (C) 2026 NikeFlix (derived work of OpenWizard, Copyright (C) 2019 drinfernoo; see NOTICE.txt)
"""Wizard news notifications (T23; plan A6 item 7: the legacy check was inverted and its URL a placeholder).

Feed format (``notify.txt`` in the dist repo): ``<integer id>|||<message>``. The news window is shown only
when the user opens the wizard in the master profile (never at startup), only when notifications are enabled,
and only for an id newer than the last one dismissed.
"""


def parse(text):
    """Return ``(id:int, message:str)`` or ``(None, None)`` when the text is not a valid notification."""
    if not isinstance(text, str) or "|||" not in text:
        return None, None
    head, msg = text.replace("\r", "").split("|||", 1)
    head = head.strip()
    if not head.isdigit():
        return None, None
    msg = msg.strip("\n").replace("\t", "    ").replace("\n", "[CR]")
    if not msg.strip():
        return None, None
    return int(head), msg


def should_show(note_id, last_id, dismissed, enabled=True):
    """True when an enabled notification is newer than ``last_id``, or equal but not yet dismissed."""
    if not enabled or note_id is None:
        return False
    try:
        last = int(last_id or 0)
    except (TypeError, ValueError):
        last = 0
    if note_id > last:
        return True
    return note_id == last and str(dismissed).lower() != "true"
