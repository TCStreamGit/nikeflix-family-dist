# SPDX-License-Identifier: GPL-2.0-or-later
# Copyright (C) 2026 NikeFlix (derived work of OpenWizard, Copyright (C) 2019 drinfernoo; see NOTICE.txt)
"""Kodi adapters for the pure NikeFlix wizard core (T23). Kodi modules are imported lazily."""
import json
import os
import sqlite3
import time

from resources.libs.nikeflix import distconfig
from resources.libs.nikeflix import fen

USER_AGENT = "NikeFlixWizard/4 (Kodi)"


def translate(path):
    import xbmcvfs
    return xbmcvfs.translatePath(path)


def same_path(a, b):
    def norm(p):
        return os.path.normcase(os.path.normpath(os.path.abspath(p or "")))
    return bool(a) and bool(b) and norm(a) == norm(b)


def is_master():
    """True when the active profile is the master profile (special://profile == special://masterprofile)."""
    return same_path(translate("special://profile/"), translate("special://masterprofile/"))


def http_download(url, dest, progress=None, timeout=30, max_bytes=8 * 1024 ** 3):
    """HTTPS download with progress (stdlib only, so it works while add-on modules are being replaced)."""
    import urllib.request

    if not url.startswith("https://"):
        raise IOError("HTTPS only")
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(req, timeout=timeout) as resp, open(dest, "wb") as out:
        total = int(resp.headers.get("Content-Length") or 0)
        done = 0
        while True:
            chunk = resp.read(1024 * 1024)
            if not chunk:
                break
            done += len(chunk)
            if done > max_bytes:
                raise IOError("download exceeds size cap")
            out.write(chunk)
            if progress is not None:   # 4.1.6: also without Content-Length, so an abort is always seen
                pct = int(100 * done / total) if total else 0
                if progress(pct, "Downloading {0} / {1} MB".format(done // 1048576, total // 1048576)) is False:
                    raise IOError("cancelled")


def fetch_text(url, timeout=5):
    import urllib.request

    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.read(1024 * 1024).decode("utf-8", "replace")


def purge_locked(path, exc=None):
    """A database Kodi holds open cannot be deleted on Windows: empty its tables instead."""
    if not path.lower().endswith(".db"):
        return False
    try:
        con = sqlite3.connect(path, timeout=10.0)
        try:
            tables = [r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table' "
                                                "AND name NOT LIKE 'sqlite_%' AND name != 'version'")]
            for t in tables:
                con.execute('DELETE FROM "{0}"'.format(t.replace('"', '""')))
            con.commit()
        finally:
            con.close()
        return True
    except sqlite3.Error:
        return False


class MasterSettings(object):
    """NikeFlix 4.1.6: the wizard's settings of the MASTER profile, read and written as a file from any profile.

    Wizard state (the installed build, the last check) belongs to the device, and Kodi keeps it in the master
    profile's add-on settings. In another profile Kodi's own xbmcaddon would read that profile's (empty) copy, so the
    startup service reads and writes the master's settings.xml directly through xbmcvfs (on Apple TV that reaches
    Kodi's stored copy too). Only plain values are handled; a setting at its default (`default="true"`, no value)
    reads as ""."""

    def __init__(self, wizard_id):
        self.path = "special://masterprofile/addon_data/{0}/settings.xml".format(wizard_id)

    def _read(self):
        import xbmcvfs
        if not xbmcvfs.exists(self.path):
            return ""
        f = xbmcvfs.File(self.path)
        try:
            return f.read() or ""
        finally:
            f.close()

    def get(self, key):
        import re
        m = re.search(r'<setting id="{0}"([^>]*?)(/>|>([^<]*)</setting>)'.format(re.escape(key)), self._read())
        if not m:
            return ""
        val = m.group(3) if m.group(3) is not None else ""
        if not val:
            v1 = re.search(r'value="([^"]*)"', m.group(1))
            val = v1.group(1) if v1 else ""
        return val.replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", '"').replace("&amp;", "&")

    def set(self, key, value):
        import re
        import xbmcvfs
        xml = self._read() or '<settings version="2">\n</settings>\n'
        v = str(value).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        line = '<setting id="{0}">{1}</setting>'.format(key, v)
        pat = re.compile(r'<setting id="{0}"[^>]*?(/>|>[^<]*</setting>)'.format(re.escape(key)))
        if pat.search(xml):
            xml = pat.sub(lambda m: line, xml, count=1)
        else:
            xml = xml.replace("</settings>", "    {0}\n</settings>".format(line), 1)
        xbmcvfs.mkdirs(self.path.rsplit("/", 1)[0] + "/")
        f = xbmcvfs.File(self.path, "w")
        try:
            ok = f.write(xml)
        finally:
            f.close()
        if ok is False:
            raise IOError("master wizard settings not written")


class ServiceEnv(object):
    """Startup-service adapter: no dialogs. NikeFlix 4.1.6: in every profile; the wizard's state is the master
    profile's (MasterSettings outside it)."""

    def apply_in_place(self, entry):
        return apply_in_place(_PathsConfig(), entry)

    def __init__(self):
        import xbmc
        self._xbmc = xbmc
        self._monitor = xbmc.Monitor()
        self._addon = None
        self._is_master = None
        self.buildfile = distconfig.BUILDFILE

    def _a(self):
        if self._addon is None:
            import xbmcaddon
            self._addon = xbmcaddon.Addon(distconfig.WIZARD_ID)
        return self._addon

    def is_master(self):
        if self._is_master is None:
            self._is_master = is_master()
        return self._is_master

    def setting(self, key):
        if self.is_master():
            return self._a().getSetting(key)
        return MasterSettings(distconfig.WIZARD_ID).get(key)

    def set_setting(self, key, value):
        if self.is_master():
            self._a().setSetting(key, value)
        else:
            MasterSettings(distconfig.WIZARD_ID).set(key, value)

    @property
    def build_name(self):
        return self.setting("buildname")

    def has_build_addons(self):
        """NikeFlix 4.1.7: the build's own add-ons are installed (a device provisioned from the archive)."""
        import xbmc
        from resources.libs.nikeflix import service
        return all(xbmc.getCondVisibility("System.HasAddon({0})".format(a)) for a in service.BUILD_ADDONS)

    @property
    def build_version(self):
        return self.setting("buildversion")

    @property
    def wizard_version(self):
        return self._a().getAddonInfo("version")

    def wait_for_abort(self, seconds):
        return self._monitor.waitForAbort(min(float(seconds), 1.0))

    def fetch_text(self, url, timeout):
        return fetch_text(url, timeout)

    def set_property(self, key, value):
        import xbmcgui
        xbmcgui.Window(10000).setProperty(key, value)

    def toast(self, msg):
        self._xbmc.executebuiltin('Notification(NikeFlix Wizard,{0},6000)'.format(msg.replace(",", " ")))

    def log(self, msg):
        self._xbmc.log(msg, self._xbmc.LOGINFO)

    def now(self):
        return time.time()


class InstallEnv(object):
    """Build-install adapter (plugin context, master profile only)."""

    def __init__(self, config, dialog, progress_dialog):
        self.config = config
        self.dialog = dialog
        self.dp = progress_dialog
        self.home = config.HOME
        self.userdata = config.MASTERPROFILE
        self.addons_dir = config.ADDONS
        self.live_addons_db = os.path.join(config.DATABASE, "Addons33.db")
        self.wizard_id = config.ADDON_ID
        self.staging = os.path.join(config.MASTERPROFILE, "addon_data", config.ADDON_ID, "install")
        self.kodi_version = translate_version()
        self.purge_locked = purge_locked

    def log(self, msg):
        import xbmc
        xbmc.log("[NikeFlix Wizard] {0}".format(msg), xbmc.LOGINFO)

    def progress(self, pct, text):
        self.dp.update(max(0, min(100, int(pct))), text)
        return True  # cancelling half-way through a wipe would leave a broken setup

    def download(self, url, dest, progress):
        def cb(pct, text):
            self.dp.update(pct, text)
            return not self.dp.iscanceled()
        http_download(url, dest, cb)

    def confirm_install(self, entry, compat):
        msg = ("Install NikeFlix {0}?[CR][CR]This is a clean install: every profile, setting, database and "
               "add-on on this device is removed first. Accounts (Trakt, debrid, IPTV) are set up again per "
               "profile afterwards.").format(entry["version"])
        if compat == "warn":
            msg += "[CR][CR]Built for Kodi {0}; this device runs Kodi {1}.".format(entry["kodi"], self.kodi_version)
        return self.dialog.yesno("NikeFlix Wizard", msg, nolabel="Cancel", yeslabel="Install")

    def ask_backup(self, default_root):
        if self.config.get_setting("backup_before_install") == "false":
            return "skip", None
        root = self.config.get_setting("backup_path") or default_root
        root = translate(root) if root.startswith("special://") else root
        choice = self.dialog.yesno("NikeFlix Wizard",
                                   "Back up the current setup first?[CR]{0}".format(root),
                                   nolabel="No backup", yeslabel="Back up")
        if choice:
            return "backup", root
        sure = self.dialog.yesno("NikeFlix Wizard", "Wipe this device WITHOUT a backup?",
                                 nolabel="Cancel", yeslabel="Wipe without backup")
        return ("skip", None) if sure else ("cancel", None)

    def confirm_backup_errors(self, report):
        return self.dialog.yesno("NikeFlix Wizard",
                                 "{0} files could not be backed up. Continue anyway?".format(report["errors"]),
                                 nolabel="Cancel", yeslabel="Continue")

    def want_fen(self):
        mode = self.config.get_setting("fen_install") or "0"  # 0 ask, 1 always, 2 never
        if mode == "1":
            return True
        if mode == "2":
            return False
        return self.dialog.yesno("NikeFlix Wizard",
                                 "Install the Fen 4 fallback player?[CR]It is downloaded from its author and "
                                 "checked against a pinned hash (not bundled with NikeFlix).",
                                 nolabel="Skip", yeslabel="Install Fen 4")

    fen_fetch = staticmethod(fen.urllib_fetch)

    def sync_platform_store(self, keep=None):
        """tvOS only (tvosstore.py): drop Kodi's stored userdata xml copies that differ from the new build."""
        import xbmc
        if not xbmc.getCondVisibility("System.Platform.TVOS"):
            return "not tvos"
        import xbmcvfs
        from resources.libs.nikeflix import tvosstore, wipe as nfwipe
        base = "special://masterprofile/"

        class Vfs(object):
            def listdir(self, rel):
                return xbmcvfs.listdir(base + rel)[1]

            def exists(self, rel):
                return xbmcvfs.exists(base + rel)

            def read(self, rel):
                f = xbmcvfs.File(base + rel)
                try:
                    return bytes(f.readBytes())
                finally:
                    f.close()

            def delete(self, rel):
                return bool(xbmcvfs.delete(base + rel))

        kept = ["%s" % nfwipe.KEEP_OPTIONS[k].split("userdata/", 1)[1] for k, on in (keep or {}).items()
                if on and k in nfwipe.KEEP_OPTIONS]
        kept.append("addon_data/%s/settings.xml" % self.wizard_id)
        addon_ids = [a for a in os.listdir(self.addons_dir) if "." in a]
        res = tvosstore.drop_stale(self.userdata, Vfs(), addon_ids, keep=kept)
        self.log("[Build Install] tvOS stored copies dropped: {0}, failed: {1}".format(res["removed"], len(res["failed"])))
        return res


class _PathsConfig(object):
    """The few paths InPlaceEnv needs, from Kodi's special paths (the startup service stays dialog-free: no
    resources.libs.common import)."""

    def __init__(self):
        self.HOME = translate("special://home/")
        self.MASTERPROFILE = translate("special://masterprofile/")
        self.ADDONS = translate("special://home/addons/")
        self.DATABASE = translate("special://database/")
        self.ADDON_ID = distconfig.WIZARD_ID


class InPlaceEnv(object):
    """What installer.prepare and inplace.update need, without any dialog (background service, master profile)."""

    def __init__(self, config):
        self.config = config
        self.home = config.HOME
        self.userdata = config.MASTERPROFILE
        self.addons_dir = config.ADDONS
        # the master profile's database from any profile (4.1.6: the in-place update also runs outside the master)
        self.live_addons_db = os.path.join(config.MASTERPROFILE, "Database", "Addons33.db")
        self.wizard_id = config.ADDON_ID
        self.staging = os.path.join(config.MASTERPROFILE, "addon_data", config.ADDON_ID, "inplace")
        self.kodi_version = translate_version()

    def log(self, msg):
        import xbmc
        xbmc.log("[NikeFlix Wizard] {0}".format(msg), xbmc.LOGINFO)

    def progress(self, pct, text):
        return True

    def download(self, url, dest, progress):
        # 4.1.6: abort-aware. This runs on the startup service's thread; a profile switch or shutdown asks the service
        # to stop and Kodi kills it after 5 s, which can hang Kodi 21.3 (H3). Each 1 MB chunk checks the abort, and a
        # stalled read gives up after 10 s; the update is retried later (service.RETRY_S).
        import xbmc
        monitor = xbmc.Monitor()
        http_download(url, dest, lambda pct, text: not monitor.abortRequested(), timeout=10)


INPLACE_LOCK = "nikeflixwizard.inplace.running"   # Home property: epoch seconds while an in-place update runs
INPLACE_LOCK_S = 1800


def apply_in_place(config, entry):
    """NikeFlix 4.1.7: the startup service and the wizard's Update card both call this; one runs at a time."""
    from resources.libs.nikeflix import inplace
    import xbmc
    import xbmcgui
    home = xbmcgui.Window(10000)
    try:
        held = float(home.getProperty(INPLACE_LOCK) or 0)
    except ValueError:
        held = 0.0
    if held and 0 <= time.time() - held < INPLACE_LOCK_S:
        raise IOError("another in-place update is running")
    home.setProperty(INPLACE_LOCK, str(time.time()))
    try:
        report = inplace.update(InPlaceEnv(config), entry)
    finally:
        home.clearProperty(INPLACE_LOCK)
    if report.get("updated"):
        xbmc.executebuiltin("UpdateLocalAddons")
    if report.get("fen_repaired") is True:   # 4.1.7: Fen's row was put back; enable it now as the Fen installer does
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled",'
                            '"params":{"addonid":"plugin.video.fen","enabled":true}}')
    return report


def translate_version():
    import xbmc
    label = xbmc.getInfoLabel("System.BuildVersion") or ""
    return label.split(" ")[0].split("-")[0]
