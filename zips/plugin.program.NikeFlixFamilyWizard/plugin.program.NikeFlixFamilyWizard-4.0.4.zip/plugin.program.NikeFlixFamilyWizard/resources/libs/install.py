################################################################################
#      Copyright (C) 2019 drinfernoo                                           #
#                                                                              #
#  This Program is free software; you can redistribute it and/or modify        #
#  it under the terms of the GNU General Public License as published by        #
#  the Free Software Foundation; either version 2, or (at your option)         #
#  any later version.                                                          #
#                                                                              #
#  This Program is distributed in the hope that it will be useful,             #
#  but WITHOUT ANY WARRANTY; without even the implied warranty of              #
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the                #
#  GNU General Public License for more details.                                #
#                                                                              #
#  You should have received a copy of the GNU General Public License           #
#  along with XBMC; see the file COPYING.  If not, write to                    #
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.       #
#  http://www.gnu.org/copyleft/gpl.html                                        #
################################################################################

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

import glob
import os
import re
import shutil

from resources.libs.common.config import CONFIG


###########################
#      Fresh Install      #
###########################


def keep_options():
    """Opt-in keep options (T23): all default OFF. Profiles, guisettings, repositories and credentials are
    never kept; Trakt/debrid/login save-restore was removed (plan G4: re-provisioned per profile)."""
    from resources.libs.nikeflix import wipe as nfwipe
    return {k: CONFIG.get_setting(k) == 'true' for k in nfwipe.KEEP_OPTIONS}


def wipe(ask_backup=True):
    """Remove all runtime state under the Kodi home (incl. userdata/profiles/** and every database).

    A safety backup outside the Kodi home is offered first (default location special://home/../
    nikeflix-preinstall-backup, or the 'backup_path' setting). Returns True when the wipe ran.
    """
    from resources.libs.common import logging
    from resources.libs.nikeflix import kodi_glue
    from resources.libs.nikeflix import wipe as nfwipe

    dialog = xbmcgui.Dialog()
    progress_dialog = xbmcgui.DialogProgress()

    from resources.libs.nikeflix import familyguard
    lived_in = familyguard.refuse_reasons(CONFIG.HOME)
    if lived_in:  # Family (T70/T75): never wipe existing Family profiles; they move with the NikeFlix migration
        logging.log('[Fresh Start] refused on a lived-in Family device: {0}'.format('; '.join(lived_in)))
        dialog.ok(CONFIG.ADDONTITLE, familyguard.MESSAGE)
        return False

    if ask_backup and CONFIG.get_setting('backup_before_install') != 'false':
        root = CONFIG.get_setting('backup_path') or nfwipe.default_backup_root(CONFIG.HOME)
        root = xbmcvfs.translatePath(root) if root.startswith('special://') else root
        if dialog.yesno(CONFIG.ADDONTITLE, 'Back up the current setup first?[CR]{0}'.format(root),
                        nolabel='No backup', yeslabel='Back up'):
            progress_dialog.create(CONFIG.ADDONTITLE, 'Backing up...')
            try:
                report = nfwipe.make_backup(CONFIG.HOME, root)
            except nfwipe.WipeError as e:
                progress_dialog.close()
                dialog.ok(CONFIG.ADDONTITLE, 'Backup failed: {0}[CR]Nothing was removed.'.format(e))
                return False
            progress_dialog.close()
            logging.log('[Fresh Start] backup: {0} files, {1} errors'.format(report['files'], report['errors']))
        elif not dialog.yesno(CONFIG.ADDONTITLE, 'Wipe this device WITHOUT a backup?',
                              nolabel='Cancel', yeslabel='Wipe without backup'):
            return False

    plan = nfwipe.plan_wipe(CONFIG.HOME, CONFIG.ADDON_ID, keep=keep_options())
    progress_dialog.create(CONFIG.ADDONTITLE, 'Removing all profiles, settings, databases and add-ons...')
    report = nfwipe.execute_wipe(plan, on_locked=kodi_glue.purge_locked,
                                 progress=lambda pct, rel: progress_dialog.update(pct) or True)
    progress_dialog.close()
    logging.log('[Fresh Start] deleted {0} files, purged {1}, failed {2}'.format(
        report['deleted'], len(report['purged']), len(report['failed'])), level=xbmc.LOGINFO)
    CONFIG.clear_setting('build')
    return True


def fresh_start(install=None, over=False):
    from resources.libs.common import logging
    from resources.libs.common import tools

    dialog = xbmcgui.Dialog()

    if not over and not dialog.yesno(CONFIG.ADDONTITLE,
                                     'Remove every profile, setting, database and add-on from this device?',
                                     nolabel='Cancel', yeslabel='Continue'):
        logging.log_notify(CONFIG.ADDONTITLE, '[COLOR {0}]Fresh Start: Cancelled![/COLOR]'.format(CONFIG.COLOR2))
        return False
    if not wipe():
        return False
    if over or install == 'restore':
        return True
    dialog.ok(CONFIG.ADDONTITLE, 'Kodi will now close to finish the clean-up.')
    tools.kill_kodi(over=True)


def choose_file_manager():
    if not xbmc.getCondVisibility('System.HasAddon(script.kodi.android.update)'):
        from resources.libs.gui import addon_menu
        addon_menu.install_from_kodi('script.kodi.android.update')
    
    try:
        updater = xbmcaddon.Addon('script.kodi.android.update')
    except RuntimeError as e:
        return False
        
    updater.setSetting('File_Manager', '1')
    
    CONFIG.open_settings('script.kodi.android.update', 0, 4, True)
    

def install_apk(name, url):
    from resources.libs.downloader import Downloader
    from resources.libs.common import logging
    from resources.libs.common import tools
    from resources.libs.gui import window

    dialog = xbmcgui.Dialog()
    progress_dialog = xbmcgui.DialogProgress()
    
    addon = xbmcaddon.Addon()
    path = addon.getSetting('apk_path')
    apk = os.path.basename(url).replace('\\', '').replace('/', '').replace(':', '').replace('*', '').replace('?', '').replace('"', '').replace('<', '').replace('>', '').replace('|', '')
    apk = apk if apk.endswith('.apk') else '{}.apk'.format(apk)
    lib = os.path.join(path, apk)
    
    if not xbmc.getCondVisibility('System.HasAddon(script.kodi.android.update)'):
        from resources.libs.gui import addon_menu
        addon_menu.install_from_kodi('script.kodi.android.update')
        
    try:
        updater = xbmcaddon.Addon('script.kodi.android.update')
    except RuntimeError as e:
        return False
        
    file_manager = int(updater.getSetting('File_Manager'))
    custom_manager = updater.getSetting('Custom_Manager')
    use_manager = {0: 'com.android.documentsui', 1: custom_manager}[file_manager]
    
    if tools.platform() == 'android':
        redownload = True
        yes = True
        if os.path.exists(lib):
            redownload = dialog.yesno(CONFIG.ADDONTITLE, '[COLOR {}]{}[/COLOR] already exists. Would you like to redownload it?'.format(CONFIG.COLOR1, apk),
                               yeslabel="[B]Redownload[/B]",
                               nolabel="[B]Install[/B]")
            yes = False
        else:
            yes = dialog.yesno(CONFIG.ADDONTITLE,
                                   "[COLOR {0}]Would you like to download and install: ".format(CONFIG.COLOR2)
                                   +'\n'+"[COLOR {0}]{1}[/COLOR]".format(CONFIG.COLOR1, name),
                                   yeslabel="[B][COLOR springgreen]Download[/COLOR][/B]",
                                   nolabel="[B][COLOR red]Cancel[/COLOR][/B]")
                                   
            if not yes:
                logging.log_notify(CONFIG.ADDONTITLE,
                               '[COLOR {0}]ERROR: Install Cancelled[/COLOR]'.format(CONFIG.COLOR2))
                return
        
        if yes or redownload:
            response = tools.open_url(url, check=True)
            if not response:
                logging.log_notify(CONFIG.ADDONTITLE,
                                   '[COLOR {0}]APK Installer: Invalid Apk Url![/COLOR]'.format(CONFIG.COLOR2))
                return
                
            progress_dialog.create(CONFIG.ADDONTITLE,
                          '[COLOR {0}][B]Downloading:[/B][/COLOR] [COLOR {1}]{2}[/COLOR]'.format(CONFIG.COLOR2, CONFIG.COLOR1, apk)
                          +'\n'+''
                          +'\n'+'Please Wait')
            
            try:
                os.remove(lib)
            except:
                pass
            Downloader().download(url, lib)
            xbmc.sleep(100)
            progress_dialog.close()
                
        dialog.ok(CONFIG.ADDONTITLE, '[COLOR {}]{}[/COLOR] downloaded to [COLOR {}]{}[/COLOR]. If installation doesn\'t start by itself, navigate to that location to install the APK.'.format(CONFIG.COLOR1, apk, CONFIG.COLOR1, path))
        
        logging.log('Opening {} with {}'.format(lib, use_manager), level=xbmc.LOGINFO)
        xbmc.executebuiltin('StartAndroidActivity({},,,"content://{}")'.format(use_manager, lib))
    else:
        logging.log_notify(CONFIG.ADDONTITLE,
                           '[COLOR {0}]ERROR: None Android Device[/COLOR]'.format(CONFIG.COLOR2))
