################################################################################
#      Copyright (C) 2019 drinfernoo                                           #
#                                                                              #
#  This Program is free software; you can redistribute it and/or modify        #
#  it under the terms of the GNU General Public License as published by        #
#  the Free Software Foundation; either version 2, or (at your option)         #
#  any later version.                                                          #
#                                                                              #
#  This Program is distributed in the hope that it will be useful,             #
#  but WITHOUT ANY WARRANTY; without even the implied warranty of              #
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the                #
#  GNU General Public License for more details.                                #
#                                                                              #
#  You should have received a copy of the GNU General Public License           #
#  along with XBMC; see the file COPYING.  If not, write to                    #
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.       #
#  http://www.gnu.org/copyleft/gpl.html                                        #
################################################################################

try:  # Python 3
    from urllib.parse import quote_plus
except ImportError:  # Python 2
    from urllib import quote_plus

from resources.libs import check
from resources.libs.common import directory
from resources.libs.common.config import CONFIG


class BuildMenu:
    """Builds from the NikeFlix feed (nikeflix.builds/1, T23). Versions compare semantically."""

    def get_listing(self):
        from resources.libs.nikeflix import feed

        parsed = check.load_feed()
        directory.add_file('Kodi Version: {0}'.format(CONFIG.KODIV), icon=CONFIG.ICONBUILDS, themeit=CONFIG.THEME3)
        directory.add_dir('Clean-install options', {'mode': 'savedata'}, icon=CONFIG.ICONSAVE, themeit=CONFIG.THEME3)
        directory.add_separator()
        if parsed is None:
            directory.add_file('The NikeFlix build feed is unavailable right now.', icon=CONFIG.ICONBUILDS, themeit=CONFIG.THEME3)
            return
        if not parsed['builds']:
            directory.add_file('No installable build is published yet.', icon=CONFIG.ICONBUILDS, themeit=CONFIG.THEME3)
            return
        for b in parsed['builds']:
            label = '[{0}] {1} (v{2})'.format(b['kodi'], b['name'], b['version'])
            if b['name'] == CONFIG.BUILDNAME and feed.update_available(parsed, CONFIG.BUILDNAME, CONFIG.BUILDVERSION):
                label += ' [COLOR red][UPDATE from v{0}][/COLOR]'.format(CONFIG.BUILDVERSION)
            directory.add_dir(label, {'mode': 'viewbuild', 'name': b['name']}, description=b.get('description', ''),
                              icon=CONFIG.ICONBUILDS, menu=self.create_install_menu(b['name']), themeit=CONFIG.THEME2)

    def view_build(self, name):
        from resources.libs.nikeflix import feed

        entry = check.build_entry(name)
        if not entry:
            directory.add_file('{0} was not found in the NikeFlix feed.'.format(name), themeit=CONFIG.THEME3)
            return
        build = '{0} (v{1})'.format(name, entry['version'])
        if CONFIG.BUILDNAME == name and CONFIG.BUILDVERSION:
            build += ' [COLOR red][INSTALLED v{0}][/COLOR]'.format(CONFIG.BUILDVERSION)
        # The feed entry being viewed, not the installed build: THEME4 ("Current Build:") read as if it were installed.
        directory.add_file('Build: ' + build, description=entry.get('description', ''), themeit=CONFIG.THEME3)
        directory.add_separator()
        directory.add_dir('Clean-install options', {'mode': 'savedata'}, icon=CONFIG.ICONSAVE, themeit=CONFIG.THEME3)
        directory.add_file('Build Information', {'mode': 'buildinfo', 'name': name}, themeit=CONFIG.THEME3)
        compat = feed.kodi_compat(entry['kodi'], '{0:.1f}'.format(CONFIG.KODIV))
        if compat != 'ok':
            directory.add_file('[I]Built for Kodi {0} (installed: {1})[/I]'.format(entry['kodi'], CONFIG.KODIV),
                               themeit=CONFIG.THEME3)
        directory.add_separator('INSTALL')
        directory.add_file('Clean Install (removes all profiles, settings, databases and add-ons)',
                           {'mode': 'install', 'name': name}, themeit=CONFIG.THEME1)

    def build_info(self, name):
        from resources.libs.gui import window

        entry = check.build_entry(name)
        if not entry:
            return
        rows = [('Build Name', name), ('Build Version', entry['version']), ('Kodi Version', entry['kodi']),
                ('Edition', entry.get('edition', 'family')), ('SHA-256', entry['sha256'])]
        if entry.get('size'):
            rows.append(('Size', '{0} MB'.format(int(entry['size']) // 1048576)))
        if entry.get('description'):
            rows.append(('Description', entry['description']))
        msg = '[CR]'.join('[COLOR {0}]{1}:[/COLOR] [COLOR {2}]{3}[/COLOR]'.format(CONFIG.COLOR2, k, CONFIG.COLOR1, v)
                          for k, v in rows)
        window.show_text_box('Viewing Build Info: {0}'.format(name), msg)

    def create_install_menu(self, name):
        buildname = quote_plus(name)
        return [
            (CONFIG.THEME2.format(name), 'RunAddon({0}, ?mode=viewbuild&name={1})'.format(CONFIG.ADDON_ID, buildname)),
            (CONFIG.THEME3.format('Clean Install'), 'RunPlugin(plugin://{0}/?mode=install&name={1})'.format(CONFIG.ADDON_ID, buildname)),
            (CONFIG.THEME3.format('Build Information'), 'RunPlugin(plugin://{0}/?mode=buildinfo&name={1})'.format(CONFIG.ADDON_ID, buildname)),
            (CONFIG.THEME2.format('{0} Settings'.format(CONFIG.ADDONTITLE)), 'RunPlugin(plugin://{0}/?mode=settings)'.format(CONFIG.ADDON_ID)),
        ]
