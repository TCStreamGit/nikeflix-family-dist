################################################################################
#      Copyright (C) 2019 drinfernoo                                           #
#                                                                              #
#  This Program is free software; you can redistribute it and/or modify        #
#  it under the terms of the GNU General Public License as published by        #
#  the Free Software Foundation; either version 2, or (at your option)         #
#  any later version.                                                          #
#                                                                              #
#  This Program is distributed in the hope that it will be useful,             #
#  but WITHOUT ANY WARRANTY; without even the implied warranty of              #
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the                #
#  GNU General Public License for more details.                                #
#                                                                              #
#  You should have received a copy of the GNU General Public License           #
#  along with XBMC; see the file COPYING.  If not, write to                    #
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.       #
#  http://www.gnu.org/copyleft/gpl.html                                        #
################################################################################

"""NikeFlix Wizard startup service (T23).

Every profile (NikeFlix 4.1.6), dialog-free and abort-responsive: see resources/libs/nikeflix/service.py for the
contract. The build state is the master profile's wizard settings, read and written from whichever profile runs
(plan T05: the legacy service showed modals on every profile load; this one never shows any).
"""
from resources.libs.nikeflix import kodi_glue
from resources.libs.nikeflix import service


if __name__ == '__main__':
    service.run(kodi_glue.ServiceEnv())
