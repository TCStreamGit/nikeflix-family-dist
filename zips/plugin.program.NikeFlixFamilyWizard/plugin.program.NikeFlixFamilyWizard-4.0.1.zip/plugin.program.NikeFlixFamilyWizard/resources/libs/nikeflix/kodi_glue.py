# SPDX-License-Identifier: GPL-2.0-or-later
# Copyright (C) 2026 NikeFlix (derived work of OpenWizard, Copyright (C) 2019 drinfernoo; see NOTICE.txt)
"""Kodi adapters for the pure NikeFlix wizard core (T23). Kodi modules are imported lazily."""
import json
import os
import sqlite3
import time

from resources.libs.nikeflix import distconfig
from resources.libs.nikeflix import fen

USER_AGENT = "NikeFlixWizard/4 (Kodi)"


def translate(path):
    import xbmcvfs
    return xbmcvfs.translatePath(path)


def same_path(a, b):
    def norm(p):
        return os.path.normcase(os.path.normpath(os.path.abspath(p or "")))
    return bool(a) and bool(b) and norm(a) == norm(b)


def is_master():
    """True when the active profile is the master profile (special://profile == special://masterprofile)."""
    return same_path(translate("special://profile/"), translate("special://masterprofile/"))


def http_download(url, dest, progress=None, timeout=30, max_bytes=8 * 1024 ** 3):
    """HTTPS download with progress (stdlib only, so it works while add-on modules are being replaced)."""
    import urllib.request

    if not url.startswith("https://"):
        raise IOError("HTTPS only")
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(req, timeout=timeout) as resp, open(dest, "wb") as out:
        total = int(resp.headers.get("Content-Length") or 0)
        done = 0
        while True:
            chunk = resp.read(1024 * 1024)
            if not chunk:
                break
            done += len(chunk)
            if done > max_bytes:
                raise IOError("download exceeds size cap")
            out.write(chunk)
            if progress is not None and total:
                if progress(int(100 * done / total), "Downloading {0} / {1} MB".format(done // 1048576, total // 1048576)) is False:
                    raise IOError("cancelled")


def fetch_text(url, timeout=5):
    import urllib.request

    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.read(1024 * 1024).decode("utf-8", "replace")


def purge_locked(path, exc=None):
    """A database Kodi holds open cannot be deleted on Windows: empty its tables instead."""
    if not path.lower().endswith(".db"):
        return False
    try:
        con = sqlite3.connect(path, timeout=10.0)
        try:
            tables = [r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table' "
                                                "AND name NOT LIKE 'sqlite_%' AND name != 'version'")]
            for t in tables:
                con.execute('DELETE FROM "{0}"'.format(t.replace('"', '""')))
            con.commit()
        finally:
            con.close()
        return True
    except sqlite3.Error:
        return False


class ServiceEnv(object):
    """Startup-service adapter: no dialogs, settings only touched in the master profile."""

    def __init__(self):
        import xbmc
        self._xbmc = xbmc
        self._monitor = xbmc.Monitor()
        self._addon = None
        self.buildfile = distconfig.BUILDFILE

    def _a(self):
        if self._addon is None:
            import xbmcaddon
            self._addon = xbmcaddon.Addon(distconfig.WIZARD_ID)
        return self._addon

    def is_master(self):
        return is_master()

    def setting(self, key):
        return self._a().getSetting(key)

    def set_setting(self, key, value):
        self._a().setSetting(key, value)

    @property
    def build_name(self):
        return self.setting("buildname")

    @property
    def build_version(self):
        return self.setting("buildversion")

    @property
    def wizard_version(self):
        return self._a().getAddonInfo("version")

    def wait_for_abort(self, seconds):
        return self._monitor.waitForAbort(min(float(seconds), 1.0))

    def fetch_text(self, url, timeout):
        return fetch_text(url, timeout)

    def set_property(self, key, value):
        import xbmcgui
        xbmcgui.Window(10000).setProperty(key, value)

    def toast(self, msg):
        self._xbmc.executebuiltin('Notification(NikeFlix Wizard,{0},6000)'.format(msg.replace(",", " ")))

    def log(self, msg):
        self._xbmc.log(msg, self._xbmc.LOGINFO)

    def now(self):
        return time.time()


class InstallEnv(object):
    """Build-install adapter (plugin context, master profile only)."""

    def __init__(self, config, dialog, progress_dialog):
        self.config = config
        self.dialog = dialog
        self.dp = progress_dialog
        self.home = config.HOME
        self.userdata = config.MASTERPROFILE
        self.addons_dir = config.ADDONS
        self.live_addons_db = os.path.join(config.DATABASE, "Addons33.db")
        self.wizard_id = config.ADDON_ID
        self.staging = os.path.join(config.MASTERPROFILE, "addon_data", config.ADDON_ID, "install")
        self.kodi_version = translate_version()
        self.purge_locked = purge_locked

    def log(self, msg):
        import xbmc
        xbmc.log("[NikeFlix Wizard] {0}".format(msg), xbmc.LOGINFO)

    def progress(self, pct, text):
        self.dp.update(max(0, min(100, int(pct))), text)
        return True  # cancelling half-way through a wipe would leave a broken setup

    def download(self, url, dest, progress):
        def cb(pct, text):
            self.dp.update(pct, text)
            return not self.dp.iscanceled()
        http_download(url, dest, cb)

    def confirm_install(self, entry, compat):
        msg = ("Install NikeFlix {0}?[CR][CR]This is a clean install: every profile, setting, database and "
               "add-on on this device is removed first. Accounts (Trakt, debrid, IPTV) are set up again per "
               "profile afterwards.").format(entry["version"])
        if compat == "warn":
            msg += "[CR][CR]Built for Kodi {0}; this device runs Kodi {1}.".format(entry["kodi"], self.kodi_version)
        return self.dialog.yesno("NikeFlix Wizard", msg, nolabel="Cancel", yeslabel="Install")

    def ask_backup(self, default_root):
        if self.config.get_setting("backup_before_install") == "false":
            return "skip", None
        root = self.config.get_setting("backup_path") or default_root
        root = translate(root) if root.startswith("special://") else root
        choice = self.dialog.yesno("NikeFlix Wizard",
                                   "Back up the current setup first?[CR]{0}".format(root),
                                   nolabel="No backup", yeslabel="Back up")
        if choice:
            return "backup", root
        sure = self.dialog.yesno("NikeFlix Wizard", "Wipe this device WITHOUT a backup?",
                                 nolabel="Cancel", yeslabel="Wipe without backup")
        return ("skip", None) if sure else ("cancel", None)

    def confirm_backup_errors(self, report):
        return self.dialog.yesno("NikeFlix Wizard",
                                 "{0} files could not be backed up. Continue anyway?".format(report["errors"]),
                                 nolabel="Cancel", yeslabel="Continue")

    def want_fen(self):
        mode = self.config.get_setting("fen_install") or "0"  # 0 ask, 1 always, 2 never
        if mode == "1":
            return True
        if mode == "2":
            return False
        return self.dialog.yesno("NikeFlix Wizard",
                                 "Install the Fen 4 fallback player?[CR]It is downloaded from its author and "
                                 "checked against a pinned hash (not bundled with NikeFlix).",
                                 nolabel="Skip", yeslabel="Install Fen 4")

    fen_fetch = staticmethod(fen.urllib_fetch)


def translate_version():
    import xbmc
    label = xbmc.getInfoLabel("System.BuildVersion") or ""
    return label.split(" ")[0].split("-")[0]
