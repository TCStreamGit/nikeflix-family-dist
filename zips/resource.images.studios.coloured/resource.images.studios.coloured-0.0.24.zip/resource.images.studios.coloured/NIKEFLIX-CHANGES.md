# NikeFlix changes to resource.images.studios.coloured

This add-on is redistributed by NikeFlix under its original licence (CC-BY-SA-3.0).

- Upstream: https://mirrors.kodi.tv/addons/omega/addons.xml.gz 0.0.24
- Upstream ZIP: https://mirrors.kodi.tv/addons/omega/resource.images.studios.coloured/resource.images.studios.coloured-0.0.24.zip
- Upstream sha256: de985b7c671e1f171f8ac8a71a9f24f035ffabebaeee3c3a173e570d8b3c50d6
- NikeFlix version: 0.0.24

No source changes: this is the unmodified upstream release, repackaged with this notice.
