# NikeFlix changes to screensaver.titan.bingie.mod

This add-on is redistributed by NikeFlix under its original licence (Apache-2.0).

- Upstream: https://github.com/AchillesPunks/repository.titan.bingie.mod (zip only; drinfernoo source repo 404) 1.0.0
- Upstream ZIP: https://raw.githubusercontent.com/AchillesPunks/repository.titan.bingie.mod/master/omega/screensaver.titan.bingie.mod/screensaver.titan.bingie.mod-1.0.0.zip
- Upstream sha256: 78d6a9bbad8f5be80c6a59f7dee105e2350532f0f457a10a06580608af307beb
- NikeFlix version: 1.0.0+nikeflix.1

## Patches

- `0001-require-skin-nikeflix.patch`: Depend on skin.nikeflix 1.0.0 (plan B2 new skin id, T22) instead of skin.titan.bingie.mod, which NikeFlix no longer ships.
