# NikeFlix changes to plugin.program.autocompletion

This add-on is redistributed by NikeFlix under its original licence (GPL-2.0-or-later).

- Upstream: https://github.com/finkleandeinhorn/plugin.program.autocompletion 2.1.2
- Upstream ZIP: https://mirrors.kodi.tv/addons/omega/plugin.program.autocompletion/plugin.program.autocompletion-2.1.2.zip
- Upstream sha256: 0432e06967bef696ab34298d46c23143fdfde5ed30c98a1854e89b868d5d669a
- NikeFlix version: 2.1.2

No source changes: this is the unmodified upstream release, repackaged with this notice.
