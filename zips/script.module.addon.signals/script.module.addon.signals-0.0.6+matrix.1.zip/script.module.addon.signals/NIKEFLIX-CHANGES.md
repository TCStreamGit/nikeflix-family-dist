# NikeFlix changes to script.module.addon.signals

This add-on is redistributed by NikeFlix under its original licence (LGPL-2.1-only).

- Upstream: https://github.com/ruuk/script.module.addon.signals 0.0.6+matrix.1
- Upstream ZIP: https://mirrors.kodi.tv/addons/omega/script.module.addon.signals/script.module.addon.signals-0.0.6+matrix.1.zip
- Upstream sha256: a41629f328429d08d79ef3c8b59c93d6f4c06b1a6e76806babd44f2457a9a1fb
- NikeFlix version: 0.0.6+matrix.1

No source changes: this is the unmodified upstream release, repackaged with this notice.
