# NikeFlix changes to script.module.musicbrainz

This add-on is redistributed by NikeFlix under its original licence (GPL-3.0-only).

- Upstream: https://github.com/kodi-community-addons/script.module.musicbrainz 0.7.0
- Upstream ZIP: https://raw.githubusercontent.com/AchillesPunks/repository.titan.bingie.mod/master/omega/script.module.musicbrainz/script.module.musicbrainz-0.7.0.zip
- Upstream sha256: cb33a0324d6bd373f19ff532e31986974a17276c73c96835e10b0dc76283fc0b
- NikeFlix version: 0.7.0

No source changes: this is the unmodified upstream release, repackaged with this notice.
