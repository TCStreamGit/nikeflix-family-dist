# NikeFlix changes to resource.images.moviegenreicons.bingie

This add-on is redistributed by NikeFlix under its original licence (GPL-3.0-only).

- Upstream: https://github.com/cartmandos/resource.images.moviegenreicons.bingie/ 1.0.0
- Upstream ZIP: https://raw.githubusercontent.com/AchillesPunks/repository.titan.bingie.mod/master/omega/resource.images.moviegenreicons.bingie/resource.images.moviegenreicons.bingie-1.0.0.zip
- Upstream sha256: 29d20144ecbddabf0d952fab4bb6e794123d56e05bd1bb47e4399ffff48bec04
- NikeFlix version: 1.0.0

No source changes: this is the unmodified upstream release, repackaged with this notice.
