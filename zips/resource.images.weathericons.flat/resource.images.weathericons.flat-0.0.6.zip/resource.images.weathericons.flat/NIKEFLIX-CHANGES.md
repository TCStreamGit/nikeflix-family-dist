# NikeFlix changes to resource.images.weathericons.flat

This add-on is redistributed by NikeFlix under its original licence (CC-BY-SA-3.0).

- Upstream: https://mirrors.kodi.tv/addons/omega/addons.xml.gz 0.0.6
- Upstream ZIP: https://mirrors.kodi.tv/addons/omega/resource.images.weathericons.flat/resource.images.weathericons.flat-0.0.6.zip
- Upstream sha256: 9f7500db6d16683127f3169c32a04637ddb9503f28b2e571efb21fb3bc168d76
- NikeFlix version: 0.0.6

No source changes: this is the unmodified upstream release, repackaged with this notice.
