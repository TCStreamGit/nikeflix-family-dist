# NikeFlix changes to script.common.plugin.cache

This add-on is redistributed by NikeFlix under its original licence (GPL-3.0-only).

- Upstream: https://github.com/anxdpanic/script.common.plugin.cache 3.0.0
- Upstream ZIP: https://mirrors.kodi.tv/addons/omega/script.common.plugin.cache/script.common.plugin.cache-3.0.0.zip
- Upstream sha256: d4543aa67794c8305eaba8891d832ae38c3c9013edf9d0cae81346ad644b90d4
- NikeFlix version: 3.0.0

No source changes: this is the unmodified upstream release, repackaged with this notice.
