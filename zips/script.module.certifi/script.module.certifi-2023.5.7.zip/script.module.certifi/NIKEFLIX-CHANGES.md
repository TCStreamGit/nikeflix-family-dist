# NikeFlix changes to script.module.certifi

This add-on is redistributed by NikeFlix under its original licence (MPL-2.0).

- Upstream: https://github.com/certifi/python-certifi 2023.5.7
- Upstream ZIP: https://mirrors.kodi.tv/addons/omega/script.module.certifi/script.module.certifi-2023.5.7.zip
- Upstream sha256: c16d4cd2efe6e57dbb5e8d71a9beb3af213b1e3d717e8b0b24f0cbdc4c645070
- NikeFlix version: 2023.5.7

No source changes: this is the unmodified upstream release, repackaged with this notice.
