# NikeFlix changes to script.module.unidecode

This add-on is redistributed by NikeFlix under its original licence (GPL-2.0-or-later).

- Upstream: https://pypi.org/project/Unidecode 1.3.6
- Upstream ZIP: https://mirrors.kodi.tv/addons/omega/script.module.unidecode/script.module.unidecode-1.3.6.zip
- Upstream sha256: f66257736002b479f9e109259d691113412a7f2215139aa5534d795d8d6925a7
- NikeFlix version: 1.3.6

No source changes: this is the unmodified upstream release, repackaged with this notice.
