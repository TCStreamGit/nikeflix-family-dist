# NikeFlix changes to script.artwork.beef

This add-on is redistributed by NikeFlix under its original licence (MIT).

- Upstream: https://github.com/rmrector/script.artwork.beef 0.28.8
- Upstream ZIP: https://raw.githubusercontent.com/AchillesPunks/repository.titan.bingie.mod/master/omega/script.artwork.beef/script.artwork.beef-0.28.8.zip
- Upstream sha256: 35dbcb612c84ad17a837436da69848c1f17f5fd719300efa88074cf3b086d1da
- NikeFlix version: 0.28.8+nikeflix.1

## Patches

- `0001-h3-switch-quiescence.patch`: H3 Option C (DEC-H3-C-STAGING, staged, not released): the idle loop (`scanning` reports busy) skips its pass and acknowledges while a NikeFlix profile switch is pending, so Kodi does not have to kill it during LogOff; the added nikeflix_quiesce.py reads one Home window property only (no global getCondVisibility replacement; every pause ends on its own). Evidence docs/evidence/H3-QUIESCE-V5.md.
