# NikeFlix changes to script.wikipedia

This add-on is redistributed by NikeFlix under its original licence (GPL-3.0-or-later).

- Upstream: https://raw.githubusercontent.com/jurialmunkey/repository.jurialmunkey/master/omega/zips/addons.xml 0.2.0
- Upstream ZIP: https://raw.githubusercontent.com/jurialmunkey/repository.jurialmunkey/master/omega/zips/script.wikipedia/script.wikipedia-0.2.0.zip
- Upstream sha256: 21275e560c03c92f9ccac7672617f904d17a176cefcff0f9848f40c91ac71a13
- NikeFlix version: 0.2.0

No source changes: this is the unmodified upstream release, repackaged with this notice.
