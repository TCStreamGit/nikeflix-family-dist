# -*- coding: utf-8 -*-
"""NikeFlix 4.1 rows (Tanner 2026-11-19, approved preview v13): what Home, Shows and Movies show, in order.

Each page keeps its personal rows and fills the rest from a pool that rotates every visit:
- Home: Continue Watching (everything), Top 10, Top Picks, My List, three rotating rows, New on NikeFlix.
- Shows: Continue Watching (shows only), Top 10 Shows, Because You Watched <show>, New Episodes, four rotating show rows.
- Movies: Continue Watching (movies only), Top 10 Movies, In Theatres Now (always), Movies Like <film>, four
  rotating movie rows.
- My NikeFlix: the profile's watchlist, favourites and Trakt lists, then rotating public Trakt lists.
No row name appears on two pages; Shows rows hold only shows and Movies rows only films.

Pure Python (no Kodi). A row is a dict: label, path (a TMDb Helper plugin path), optional limit. `{name}` in a label
is the profile name. Rows whose label needs a title ("Because You Watched ...", "Movies Like ...") are "seeded":
rotate.py looks up the profile's last-watched show / film and falls back to the page's next pool row when there is none.
"""
TMDBH = "plugin://plugin.video.themoviedb.helper/?"


def tm(**q):
    """TMDb Helper path. Keys keep their order (TMDb Helper reads them by name)."""
    return TMDBH + "&".join("%s=%s" % (k.replace("__", "."), v) for k, v in q.items())


def disc(kind, **q):
    return tm(info="discover", tmdb_type=kind, **q)


# --- fixed rows ----------------------------------------------------------------------------------------------------
# TMDb Helper 6.17.9 types (lab probe + source, 2026-11-19): Trakt on-deck / recommendations / trending and TMDb
# trending take "movie" or "tv" only ("both" comes back empty); TMDb trending also takes "all" (movies and shows,
# ranked); the random and watchlist lists take "both".
HOME_FIXED = [
    {"label": "Continue Watching for {name}", "path": tm(info="trakt_ondeck", tmdb_type="tv")},   # episodes in progress
    {"label": "Top 10 in Canada Today", "path": tm(info="trending_day", tmdb_type="all", nikeflix="top10"), "limit": 10},
    {"label": "Top Picks for {name}", "path": tm(info="trakt_recommendations", tmdb_type="movie")},
    {"label": "My List", "path": tm(info="trakt_watchlist", tmdb_type="both", list_name="Watchlist")},
    # the preview's score cards (service.nikeflix Live sports); empty, so hidden, when nothing is live or Live sports is Off
    {"label": "Live Sports Now", "path": "plugin://service.nikeflix/?mode=sports&row=live&filter=&nikeflix=sports"},
]
# recent releases: TMDb Helper's relative dates (t = today), so the path never goes stale
HOME_LAST = {"label": "New on NikeFlix", "path": disc("movie", primary_release_date__gte="t-60",
                                                       primary_release_date__lte="t", sort_by="popularity.desc")}

SHOWS_FIXED = [
    {"label": "Continue Watching for {name}", "path": tm(info="trakt_ondeck", tmdb_type="tv")},
    {"label": "Top 10 Shows in Canada Today", "path": tm(info="trakt_trending", tmdb_type="tv", nikeflix="top10"), "limit": 10},
    {"label": "Because You Watched {title}", "path": None, "seed": "tv"},
    {"label": "New Episodes", "path": tm(info="on_the_air", tmdb_type="tv")},
]
MOVIES_FIXED = [
    {"label": "Continue Watching for {name}", "path": tm(info="trakt_ondeck", tmdb_type="movie")},
    {"label": "Top 10 Movies in Canada Today", "path": tm(info="trakt_trending", tmdb_type="movie", nikeflix="top10"), "limit": 10},
    {"label": "In Theatres Now", "path": tm(info="now_playing", tmdb_type="movie")},
    {"label": "Movies Like {title}", "path": None, "seed": "movie"},
]

# nikeflix=top10 marks a Top 10 row for the skin (big rank numbers, IncludesHomeWidgets.xml NikeFlixTop10Rank);
# TMDb Helper ignores the extra parameter (lab 2026-11-19: same list with and without it).

# --- rotating pools ------------------------------------------------------------------------------------------------
HOME_POOL = [
    {"label": "Trending Now", "path": tm(info="trending_week", tmdb_type="all")},
    {"label": "Critically Acclaimed", "path": disc("tv", sort_by="vote_average.desc", vote_count__gte="2000")},
    {"label": "Hidden Gems for You", "path": tm(info="trakt_becausemostwatched", tmdb_type="both")},
    {"label": "Canadian Stories", "path": disc("movie", with_origin_country="CA", sort_by="popularity.desc")},
    {"label": "Watch in One Weekend", "path": disc("tv", with_status="3", sort_by="vote_count.desc")},
    {"label": "Popular on NikeFlix", "path": tm(info="popular", tmdb_type="movie")},
    {"label": "Top Rated TV Shows", "path": tm(info="top_rated", tmdb_type="tv")},
    {"label": "Box Office Hits", "path": tm(info="trakt_boxoffice", tmdb_type="movie")},
    {"label": "Fan Favourites", "path": disc("tv", sort_by="vote_count.desc")},
]
SHOW_POOL = [
    {"label": "Crime TV Shows", "path": disc("tv", with_genres="80", with_id="True")},
    {"label": "Reality TV", "path": disc("tv", with_genres="10764", with_id="True")},
    {"label": "Sitcoms", "path": disc("tv", with_genres="35", with_id="True")},
    {"label": "Docuseries", "path": disc("tv", with_genres="99", with_id="True")},
    {"label": "Sci-Fi & Fantasy Series", "path": disc("tv", with_genres="10765", with_id="True")},
    {"label": "K-Dramas", "path": disc("tv", with_origin_country="KR", with_genres="18", with_id="True")},
    {"label": "Anime Series", "path": disc("tv", with_genres="16", with_id="True", with_original_language="ja")},
    {"label": "Canadian TV", "path": disc("tv", with_origin_country="CA", sort_by="popularity.desc")},
    {"label": "British TV", "path": disc("tv", with_origin_country="GB", sort_by="popularity.desc")},
    {"label": "Mystery Series", "path": disc("tv", with_genres="9648", with_id="True")},
    {"label": "Bingeworthy TV Shows", "path": tm(info="random_mostplayed", tmdb_type="tv")},
    {"label": "Popular TV Shows", "path": tm(info="popular", tmdb_type="tv")},
]
MOVIE_POOL = [
    {"label": "Coming Soon", "path": tm(info="upcoming", tmdb_type="movie")},
    {"label": "Holiday Movies", "path": disc("movie", with_keywords="207317", with_id="True", sort_by="popularity.desc")},
    {"label": "Action & Adventure", "path": disc("movie", with_genres="28", with_id="True")},
    {"label": "Comedies", "path": disc("movie", with_genres="35", with_id="True")},
    {"label": "Thrillers", "path": disc("movie", with_genres="53", with_id="True")},
    {"label": "Romantic Movies", "path": disc("movie", with_genres="10749", with_id="True")},
    {"label": "Sci-Fi Movies", "path": disc("movie", with_genres="878", with_id="True")},
    {"label": "Family Movie Night", "path": disc("movie", with_genres="10751", with_id="True")},
    {"label": "Horror Movies", "path": disc("movie", with_genres="27", with_id="True")},
    {"label": "Award-Winning Films", "path": tm(info="top_rated", tmdb_type="movie", sort_by="vote_count.desc")},
    {"label": "Movies Based on Real Life", "path": disc("movie", with_keywords="9672", with_id="True")},
    {"label": "90s Classics", "path": disc("movie", primary_release_date__gte="1990-01-01",
                                           primary_release_date__lte="1999-12-31", sort_by="vote_count.desc")},
    {"label": "Feel-Good Movies", "path": disc("movie", with_genres="35,10751", with_id="True")},
]

# My NikeFlix (preview: My List, the profile's Trakt lists): the profile's own Trakt rows when signed in; signed
# out, public Trakt lists only (a personal row would make TMDb Helper ask for a Trakt sign-in). Names are not used on
# Home, Shows or Movies.
MY_FIXED = [
    {"label": "Your Watchlist", "path": tm(info="trakt_watchlist", tmdb_type="both", list_name="Watchlist")},
    {"label": "Favourite Movies", "path": tm(info="trakt_favorites", tmdb_type="movie", list_name="Favourites")},
    {"label": "Favourite Shows", "path": tm(info="trakt_favorites", tmdb_type="tv", list_name="Favourites")},
    {"label": "Your Lists", "path": tm(info="trakt_mylists", tmdb_type="both")},
    {"label": "Lists You Liked", "path": tm(info="trakt_likedlists", tmdb_type="both")},
]
# Popular Lists / Trending Lists are signed-in only (rotate.NEEDS_TRAKT): TMDb Helper opens a random public list and,
# when Trakt leaves out the list owner's slug, reads it as the profile's own list and asks for a Trakt sign-in
# (4.1.0 stage lab, 2026-11-20). Signed out, the six public rows fill the page.
MY_POOL = [
    {"label": "Most Anticipated Movies", "path": tm(info="trakt_anticipated", tmdb_type="movie")},
    {"label": "Most Anticipated Shows", "path": tm(info="trakt_anticipated", tmdb_type="tv")},
    {"label": "Popular Movies on Trakt", "path": tm(info="trakt_popular", tmdb_type="movie")},
    {"label": "Popular Shows on Trakt", "path": tm(info="trakt_popular", tmdb_type="tv")},
    {"label": "Most Played Movies This Week", "path": tm(info="trakt_mostplayed", tmdb_type="movie")},
    {"label": "Most Played Shows This Week", "path": tm(info="trakt_mostplayed", tmdb_type="tv")},
    {"label": "Popular Lists", "path": tm(info="random_popularlists", tmdb_type="list")},
    {"label": "Trending Lists", "path": tm(info="random_trendinglists", tmdb_type="list")},
]

# --- pages ---------------------------------------------------------------------------------------------------------
# page -> (skin-string prefix pattern, number of slots, fixed rows, rotating pool, rows after the rotating ones)
PAGES = {
    "home": {"key": "nikeflix.row.home.%d", "slots": 8, "fixed": HOME_FIXED, "pool": HOME_POOL, "last": [HOME_LAST]},
    "shows": {"key": "bingiehub-tvshows-%d0", "first": 51, "slots": 8, "fixed": SHOWS_FIXED, "pool": SHOW_POOL, "last": []},
    "movies": {"key": "bingiehub-movies-%d0", "first": 51, "slots": 8, "fixed": MOVIES_FIXED, "pool": MOVIE_POOL, "last": []},
    "my": {"key": "bingiehub-mylist-%d0", "first": 51, "slots": 8, "fixed": MY_FIXED, "pool": MY_POOL, "last": []},
}


def slot_keys(page):
    p = PAGES[page]
    first = p.get("first", 1)
    return [p["key"] % (first + i) for i in range(p["slots"])]


def rotating_count(page):
    p = PAGES[page]
    return p["slots"] - len(p["fixed"]) - len(p["last"])


def pick(pool, n, visit):
    """n rows from the pool for this visit; consecutive visits move a whole block on (the preview's rotation)."""
    if not pool:
        return []
    return [pool[(visit * n + i) % len(pool)] for i in range(min(n, len(pool)))]


def plan(page, visit):
    """The page's rows for a visit, before seeding: fixed rows, the rotating block, then the closing rows.
    Also returns the pool rows a missing seed may borrow (those not shown this visit)."""
    p = PAGES[page]
    n = rotating_count(page)
    chosen = pick(p["pool"], n, visit)
    spare = [r for r in p["pool"] if r not in chosen]
    return list(p["fixed"]) + chosen + list(p["last"]), spare


def all_labels():
    """Every fixed and pool label (with placeholders), page by page: used to prove names are unique across pages."""
    out = {}
    for page, p in PAGES.items():
        out[page] = [r["label"] for r in p["fixed"] + p["pool"] + p["last"]]
    return out
