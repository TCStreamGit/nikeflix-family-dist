# -*- coding: utf-8 -*-
"""NikeFlix 4.1 Settings (approved preview, Tanner 2026-11-19): one Netflix-style screen for the settings people
change, each written where it really lives (a Kodi setting, an Umbrella setting, this add-on's own setting, a skin
setting or the weather add-on). Kodi's own screens stay one click away under Advanced.

The skin window (Custom_1124_NikeFlixSettings.xml) shows, for every row, the Home property nikeflix.set.<key>.
OK on a row runs RunScript(service.nikeflix,action=setting,key=<key>): a choice row moves to its next choice and
saves it; an action row opens its screen and refreshes the row when that screen closes. The window runs
action=settings_refresh when it opens. The sports rows come with the live sports hub (step 6).
"""
UMB = "plugin.video.umbrella"
OWN = "service.nikeflix"
WX = "weather.openmeteo"
LIVE = "plugin.video.giptv"
OFF_STILL = "0"     # Umbrella patch 0006: 0 = never ask (upstream allows 2-40 and has no off)

SECTIONS = ["Playback", "Subtitles & Audio", "Trakt", "Live TV", "Appearance", "Sports", "Weather", "Advanced", "About"]

NETFLIX_SUBS = {"subtitles.backgroundtype": 1, "subtitles.bordersize": 12, "subtitles.shadowsize": 10, "subtitles.shadowopacity": 60}
SHADOW_SUBS = {"subtitles.backgroundtype": 1, "subtitles.bordersize": 0, "subtitles.shadowsize": 30, "subtitles.shadowopacity": 100}
BOX_SUBS = {"subtitles.backgroundtype": 2, "subtitles.bordersize": 0, "subtitles.shadowsize": 0, "subtitles.shadowopacity": 60}

ROWS = [
    # Playback
    {"key": "autonext", "section": "Playback", "label": "Autoplay next episode",
     "help": "Plays the next episode when the credits start.",
     "store": ("addon", UMB, "enable.playnext"), "options": [("On", "true"), ("Off", "false")]},
    {"key": "still", "section": "Playback", "label": "Ask if I'm still watching",
     "help": "After this many episodes in a row with no button pressed. Off never asks.",
     "store": ("addon", UMB, "stillwatching.count"),
     "options": [("After 1 episode", "1"), ("After 2 episodes", "2"), ("After 3 episodes", "3"),
                 ("After 4 episodes", "4"), ("After 5 episodes", "5"), ("Off", OFF_STILL)]},
    {"key": "autoprev", "section": "Playback", "label": "Autoplay previews while browsing",
     "help": "Trailers play behind the billboard.",
     "store": ("skinbool", "BingieAutoTrailer"), "options": [("On", True), ("Off", False)]},
    {"key": "skipintro", "section": "Playback", "label": "Skip intros automatically",
     "help": "Otherwise Skip Intro shows during the intro.",
     "store": ("addon", OWN, "skip.intro"), "options": [("Off", "0"), ("On", "1")], "aliases": {"2": 0}},
    # Subtitles & Audio
    {"key": "audiolang", "section": "Subtitles & Audio", "label": "Audio language",
     "help": "Every title starts in this language when it has it.",
     "store": ("kodi", "locale.audiolanguage"),
     "options": [("English", "English"), ("Original language", "original"), ("French", "French"), ("Spanish", "Spanish")]},
    {"key": "sublang", "section": "Subtitles & Audio", "label": "Subtitle language",
     "help": "Every title starts with these subtitles. Off hides them.",
     "store": ("kodi", "locale.subtitlelanguage"),
     "options": [("English", "English"), ("Off", "none"), ("French", "French"), ("Spanish", "Spanish")]},
    {"key": "subsize", "section": "Subtitles & Audio", "label": "Subtitle size",
     "help": "Small, Medium or Large.",
     "store": ("kodi", "subtitles.fontsize"), "options": [("Small", 38), ("Medium", 46), ("Large", 56)], "nearest": True},
    {"key": "substyle", "section": "Subtitles & Audio", "label": "Subtitle style",
     "help": "Netflix, Drop shadow or Background.",
     "store": ("kodimulti",), "options": [("Netflix", NETFLIX_SUBS), ("Drop shadow", SHADOW_SUBS), ("Background", BOX_SUBS)]},
    # Trakt
    {"key": "trakt", "section": "Trakt", "label": "Trakt account",
     "help": "Watch history, Continue Watching and My List sync for this profile.",
     "action": "trakt", "value": "trakt"},
    # Live TV
    {"key": "live", "section": "Live TV", "label": "Live TV provider",
     "help": "The add-on that plays Live TV and sports.",
     "action": "Addon.OpenSettings(%s)" % LIVE, "value": "live"},
    # Appearance
    {"key": "xmas", "section": "Appearance", "label": "Christmas look",
     "help": "Automatic shows it December 1 to 26.",
     "store": ("skin", "nikeflix.xmas"), "options": [("Automatic", ""), ("On", "on"), ("Off", "off")]},
    {"key": "soundpack", "section": "Appearance", "label": "Interface sounds",
     "help": "Apple TV by default, from Kodi's own add-on repository. Kodi's built-in sounds are the other choice.",
     "action": "soundpack", "value": "soundpack"},
    {"key": "soundvol", "section": "Appearance", "label": "Interface sound volume",
     "help": "How loud the menu sounds are. Off turns them off.",
     "store": ("sound",), "options": [("Quiet", 40), ("Medium", 65), ("Loud", 90), ("Off", 0)]},
    # Sports (step 6: sports/live.py, sports/hub.py)
    {"key": "sports", "section": "Sports", "label": "Live sports",
     "help": "Off hides scores, games and sports rows everywhere, and nothing sports-related loads.",
     "store": ("addon", OWN, "sports.enabled"), "options": [("On", "true"), ("Off", "false")]},
    {"key": "favteams", "section": "Sports", "label": "Favourite teams",
     "help": "Their games go first in Live Now, on the best source.", "action": "fav:teams", "value": "fav:teams"},
    {"key": "favleagues", "section": "Sports", "label": "Favourite leagues",
     "help": "When your teams aren't playing, these leagues go first.", "action": "fav:leagues", "value": "fav:leagues"},
    {"key": "favsports", "section": "Sports", "label": "Favourite sports", "help": "Then these sports.",
     "action": "fav:sports", "value": "fav:sports"},
    {"key": "favchannels", "section": "Sports", "label": "Favourite channels",
     "help": "When a game is on one of these, NikeFlix plays it from there and lists it first.",
     "action": "fav:channels", "value": "fav:channels"},
    {"key": "srcpref", "section": "Sports", "label": "Best source",
     "help": "Which channel NikeFlix picks when a game is on more than one.",
     "store": ("addon", OWN, "sports.source"),
     "options": [("Best available", "0"), ("Canadian channels first", "1"), ("US channels first", "2")]},
    {"key": "hidescores", "section": "Sports", "label": "Hide scores",
     "help": "Spoiler-free: scores stay hidden until you open the game.",
     "store": ("addon", OWN, "sports.hide_scores"), "options": [("On", "true"), ("Off", "false")]},
    # Weather
    {"key": "weather", "section": "Weather", "label": "Show weather",
     "help": "Top right of Home, beside the clock.",
     "store": ("skin", "home_header"), "options": [("On", "-weathclock"), ("Off", "time")], "contains": ("weath", 0, 1),
     "labels": {"home_header.label": {"-weathclock": "Clock + Weather", "time": "Clock"}}},
    {"key": "wxloc", "section": "Weather", "label": "Location",
     "help": "Automatic finds where you are. If it can't, pick a place here.",
     "action": "wxloc", "value": "wxloc"},
    {"key": "wxunit", "section": "Weather", "label": "Units", "help": "Always Celsius.", "value": "Celsius"},
    # Advanced
    {"key": "advskin", "section": "Advanced", "label": "Skin settings", "help": "NikeFlix's own skin options, widgets and menus.",
     "action": "ActivateWindow(SkinSettings)", "value": "Open"},
    {"key": "advlook", "section": "Advanced", "label": "Change skin", "help": "Kodi's Look and feel screen.",
     "action": "ActivateWindow(InterfaceSettings)", "value": "Open"},
    {"key": "advkodi", "section": "Advanced", "label": "All Kodi settings", "help": "Player, Media, Interface, System and Services.",
     "action": "ActivateWindow(Settings)", "value": "Open"},
    {"key": "advaddons", "section": "Advanced", "label": "Add-ons", "help": "Installed add-ons and repositories.",
     "action": "ActivateWindow(AddonBrowser)", "value": "Open"},
    {"key": "advfiles", "section": "Advanced", "label": "File manager", "help": "Kodi's file manager.",
     "action": "ActivateWindow(FileManager)", "value": "Open"},
    # About
    {"key": "about", "section": "About", "label": "NikeFlix", "help": "This device's NikeFlix and Kodi versions.", "value": "about"},
]
BY_KEY = {r["key"]: r for r in ROWS}
# Kodi's own values for a profile the build did not seed, shown in words rather than raw
RAW_WORDS = {"mediadefault": "Title's default", "default": "Title's default", "original": "Original language",
             "none": "Off", "forced_only": "Forced only"}
BUSY = "nikeflix.set.busy"         # Home property while a Settings script runs
PICKED = "nikeflix.wx.picked"      # skin string: "1" when the weather place was picked in Settings


def _same(a, b):
    if isinstance(b, bool):
        return (a is b) if isinstance(a, bool) else str(a).strip().lower() == str(b).lower()
    try:
        return float(a) == float(b)
    except (TypeError, ValueError):
        return str(a if a is not None else "").strip().lower() == str(b).strip().lower()


def read(row, env):
    kind = row["store"][0]
    if kind == "kodi":
        return env.kodi_get(row["store"][1])
    if kind == "addon":
        return env.addon_get(row["store"][1], row["store"][2])
    if kind == "skin":
        return env.skin_get(row["store"][1])
    if kind == "skinbool":
        return env.skin_bool(row["store"][1])
    return None


def current_index(row, env):
    """Index of the row's current choice, or None when the stored value matches no choice."""
    kind = row["store"][0]
    opts = row["options"]
    if kind == "sound":
        if str(env.kodi_get("audiooutput.guisoundmode")) == "0":
            return len(opts) - 1
        try:
            vol = int(env.kodi_get("audiooutput.guisoundvolume"))
        except (TypeError, ValueError):
            return None
        return min(((i, v) for i, (_, v) in enumerate(opts) if v), key=lambda iv: abs(iv[1] - vol))[0]
    if kind == "kodimulti":
        now = dict((sid, env.kodi_get(sid)) for sid in opts[0][1])
        for i, (_, want) in enumerate(opts):
            if all(_same(now.get(sid), v) for sid, v in want.items()):
                return i
        return None
    raw = read(row, env)
    for i, (_, v) in enumerate(opts):
        if _same(raw, v):
            return i
    if raw is not None and str(raw) in (row.get("aliases") or {}):
        return row["aliases"][str(raw)]
    if row.get("nearest"):
        try:
            n = float(raw)
        except (TypeError, ValueError):
            return None
        return min(range(len(opts)), key=lambda i: (abs(opts[i][1] - n), -opts[i][1]))   # a tie goes to the bigger size
    if row.get("contains"):
        text, yes, no = row["contains"]           # the skin's other header layouts: weather shown or not
        return yes if text in str(raw or "") else no
    return None


def write(row, value, env):
    kind = row["store"][0]
    if kind == "kodi":
        env.kodi_set(row["store"][1], value)
    elif kind == "kodimulti":
        for sid, v in value.items():
            env.kodi_set(sid, v)
    elif kind == "addon":
        env.addon_set(row["store"][1], row["store"][2], value)
    elif kind == "skin":
        env.skin_set(row["store"][1], value)
        for label_key, names in (row.get("labels") or {}).items():
            env.skin_set(label_key, names.get(value, ""))
    elif kind == "skinbool":
        env.skin_set_bool(row["store"][1], value)
    elif kind == "sound":
        if value:
            env.kodi_set("audiooutput.guisoundmode", 1)
            env.kodi_set("audiooutput.guisoundvolume", value)
        else:
            env.kodi_set("audiooutput.guisoundmode", 0)


def display(row, env):
    if "options" in row:
        i = current_index(row, env)
        if i is not None:
            return row["options"][i][0]
        if row["store"][0] == "kodimulti":
            return "Custom"                    # changed in Kodi's own subtitle settings
        raw = str(read(row, env) or "")
        if row["key"] == "still" and raw.isdigit():
            return "After %s episodes" % raw   # a count set in Umbrella's own settings (up to 40)
        return RAW_WORDS.get(raw.strip().lower(), raw)
    v = row.get("value", "")
    if v == "trakt":
        return "Signed in" if env.prop("nikeflix.trakt.connected") == "true" else "Sign in"
    if v == "live":
        return env.addon_name(LIVE) or "Not installed"
    if v == "wxloc":
        place = env.addon_get(WX, "loc1")
        return place if place else "Not found - pick a place"
    if v.startswith("fav:"):
        return fav_display(v[4:], env)
    if v == "soundpack":
        current = env.kodi_get(SOUND_SETTING) or ""
        name = next((n for n, aid in SOUND_PACKS if aid == current), current)
        if current and not env.addon_installed(current):
            return name + " (OK to install)"
        return name or "Off"
    if v == "about":
        return "Version %s  ·  Kodi %s" % (env.build_version(), env.kodi_version())
    return v


def refresh(env, keys=None):
    for r in ROWS:
        if keys is None or r["key"] in keys:
            env.set_prop("nikeflix.set." + r["key"], display(r, env))


def choose_location(env):
    """Location: Automatic (the weather add-on finds this device by its internet address on its next start) or a
    place picked with the weather add-on's own search. Choosing Automatic forgets a place picked here earlier; a
    place the add-on found by itself is kept (clearing it would hide the weather until the next start, review)."""
    pick = env.select("Weather location", ["Automatic", "Choose a place"])
    if pick == 0:
        env.addon_set(OWN, "weather.location_override", "")
        env.addon_set(OWN, "weather.auto_locate", "true")
        if env.skin_get(PICKED) == "1":
            for sid, v in (("loc1", ""), ("loc1user", ""), ("loc1lat", "0"), ("loc1lon", "0")):
                env.addon_set(WX, sid, v)
            env.skin_set(PICKED, "")
    elif pick == 1:
        before = env.addon_get(WX, "loc1")
        env.builtin_wait("RunScript(%s,loc1)" % WX)
        after = env.addon_get(WX, "loc1")
        if after and after != before:
            env.skin_set(PICKED, "1")


FAV_SETTING = {"teams": "sports.fav_teams", "leagues": "sports.fav_leagues", "sports": "sports.fav_sports",
               "channels": "sports.fav_channels"}


def _favs(kind, env):
    return [x for x in (env.addon_get(OWN, FAV_SETTING[kind]) or "").split("|") if x]


def _fav_name(kind, key, env):
    from resources.lib.sports import scoreboard as sb
    if kind == "teams":
        lg, _, ab = key.partition(":")
        for t in env.teams().get(lg) or []:
            if t["ab"] == ab:
                return t["name"]
        return ab
    if kind == "leagues":
        return sb.LEAGUE.get(key, {}).get("name", key)
    return key


def fav_display(kind, env):
    """None / "Maple Leafs, Oilers" / "Maple Leafs, Oilers +2" (the preview's wording)."""
    names = [_fav_name(kind, k, env) for k in _favs(kind, env)]
    if not names:
        return "None"
    return ", ".join(names[:2]) + (" +%d" % (len(names) - 2) if len(names) > 2 else "")


def choose_favourites(kind, env):
    """Never pre-filled: nothing is a favourite until the viewer picks it (Tanner 2026-11-19)."""
    from resources.lib.sports import scoreboard as sb
    chosen = _favs(kind, env)
    if kind in ("teams", "channels"):
        groups = ([(l["id"], l["name"]) for l in sb.LEAGUES if env.teams().get(l["id"])] if kind == "teams"
                  else [(n["id"], n["name"]) for n in sb.NETWORKS])
        while True:
            labels = []
            for gid, name in groups:
                n = len([c for c in chosen if (c.startswith(gid + ":") if kind == "teams" else
                                               c in next(x["feeds"] for x in sb.NETWORKS if x["id"] == gid))])
                labels.append(name + ("  (%d)" % n if n else ""))
            g = env.select("Favourite teams" if kind == "teams" else "Favourite channels", labels)
            if g is None or g < 0:
                break
            gid = groups[g][0]
            if kind == "teams":
                items = env.teams()[gid]
                keys = ["%s:%s" % (gid, t["ab"]) for t in items]
                names = [t["full"] for t in items]
            else:
                keys = list(next(x["feeds"] for x in sb.NETWORKS if x["id"] == gid))
                names = keys
            pre = [i for i, k in enumerate(keys) if k in chosen]
            picked = env.multiselect(groups[g][1], names, pre)
            if picked is None:
                continue
            chosen = [c for c in chosen if c not in keys] + [keys[i] for i in picked]
    else:
        keys = [l["id"] for l in sb.LEAGUES] if kind == "leagues" else list(sb.SPORTS)
        names = [l["name"] for l in sb.LEAGUES] if kind == "leagues" else list(sb.SPORTS)
        pre = [i for i, k in enumerate(keys) if k in chosen]
        picked = env.multiselect("Favourite leagues" if kind == "leagues" else "Favourite sports", names, pre)
        if picked is None:
            return
        chosen = [keys[i] for i in picked]
    env.addon_set(OWN, FAV_SETTING[kind], "|".join(chosen))


SOUND_SETTING = "lookandfeel.soundskin"
# the preview's Apple TV pack (resource.uisounds.appletv, Kodi's official repository; it declares no licence, so
# NikeFlix never ships it: Kodi downloads it on the device after the viewer agrees) and Kodi's own built-in pack
SOUND_PACKS = [("Apple TV", "resource.uisounds.appletv"), ("Kodi", "resource.uisounds.kodi")]


def choose_soundpack(env):
    """OK on Interface sounds: a pack that is set but not installed is installed (Kodi asks first); otherwise the row
    moves to the next pack, installing it first when needed. The sounds only change once the pack is there."""
    current = env.kodi_get(SOUND_SETTING) or ""
    ids = [aid for _, aid in SOUND_PACKS]
    if current in ids and not env.addon_installed(current):
        target = current
    else:
        target = ids[(ids.index(current) + 1) % len(ids)] if current in ids else ids[0]
    if not env.addon_installed(target):
        env.builtin_wait("InstallAddon(%s)" % target)
        if not env.addon_installed(target):
            return                      # declined, or no network: nothing changes
    env.kodi_set(SOUND_SETTING, target)


def activate(key, env):
    """OK on a row. Returns True when the row did something."""
    row = BY_KEY.get(key)
    if row is None:
        return False
    act = row.get("action")
    if act == "trakt":
        env.trakt_account()
    elif act == "soundpack":
        choose_soundpack(env)
    elif act and act.startswith("fav:"):
        choose_favourites(act[4:], env)
    elif act == "wxloc":
        choose_location(env)
    elif act:
        if act.startswith("ActivateWindow("):
            env.builtin(act)          # Kodi's own screens: nothing on this screen changes
            return True
        env.builtin_wait(act)
    elif "options" in row:
        i = current_index(row, env)
        n = len(row["options"])
        for step in range(1, n + 1):
            # a choice the add-on refuses (an Umbrella without patch 0006 refuses 0 and 1) is skipped
            nxt = (step - 1) if i is None else (i + step) % n
            write(row, row["options"][nxt][1], env)
            if row["store"][0] != "addon" or current_index(row, env) == nxt:
                break
    else:
        return False
    refresh(env, [key])
    return True


DIALOG_OPEN = "System.HasActiveModalDialog | Window.IsActive(addonsettings) | Window.IsActive(virtualkeyboard) | Window.IsActive(selectdialog)"


class SettingsEnv(object):
    """Kodi side of the settings screen (everything above is pure and unit-tested with a fake)."""

    def __init__(self, kodi):
        import xbmc
        self.kodi, self._xbmc = kodi, xbmc

    def _rpc(self, method, params):
        import json
        out = json.loads(self._xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": method, "params": params})))
        return out.get("result")

    def kodi_get(self, sid):
        return (self._rpc("Settings.GetSettingValue", {"setting": sid}) or {}).get("value")

    def kodi_set(self, sid, value):
        self._rpc("Settings.SetSettingValue", {"setting": sid, "value": value})

    def addon_get(self, addon_id, sid):
        import xbmcaddon
        try:
            return xbmcaddon.Addon(addon_id).getSetting(sid)
        except RuntimeError:          # add-on not installed
            return ""

    def addon_set(self, addon_id, sid, value):
        import xbmcaddon
        try:
            xbmcaddon.Addon(addon_id).setSetting(sid, str(value))
        except RuntimeError:
            self.kodi.log("settings: %s is not installed" % addon_id, "warning")

    def addon_installed(self, addon_id):
        return bool(self._rpc("Addons.GetAddonDetails", {"addonid": addon_id, "properties": ["enabled"]}))

    def addon_name(self, addon_id):
        import xbmcaddon
        try:
            return xbmcaddon.Addon(addon_id).getAddonInfo("name")
        except RuntimeError:
            return ""

    def skin_get(self, key):
        return self._xbmc.getInfoLabel("Skin.String(%s)" % key)

    def _settle(self, done):
        """Builtins run on Kodi's GUI thread after this call returns; wait (up to 2 s) until the change reads back,
        so the row shows the new value (lab run 1: Christmas look read back the old value)."""
        for _ in range(40):
            if done():
                return
            if self.kodi.wait(0.05):
                return

    def skin_set(self, key, value):
        if value == "":
            self.kodi.builtin("Skin.Reset(%s)" % key)
        else:
            self.kodi.builtin('Skin.SetString(%s,"%s")' % (key, str(value).replace('"', '\\"')))
        self._settle(lambda: self.skin_get(key) == str(value))

    def skin_bool(self, key):
        return self.kodi.cond("Skin.HasSetting(%s)" % key)

    def skin_set_bool(self, key, value):
        self.kodi.builtin(("Skin.SetBool(%s)" if value else "Skin.Reset(%s)") % key)
        self._settle(lambda: self.skin_bool(key) is bool(value))

    def prop(self, key):
        return self.kodi.get_prop(key)

    def set_prop(self, key, value):
        self.kodi.set_prop(key, value)

    def builtin(self, cmd):
        self.kodi.builtin(cmd)

    def builtin_wait(self, cmd, timeout=600):
        """Run a builtin that opens a dialog and return once no dialog has been open for 1.5 s (so the row can
        refresh). A flow of several dialogs (the weather search: keyboard, lookup, list) counts as one."""
        self.kodi.builtin(cmd)
        for _ in range(20):                       # give the dialog up to 2 s to open
            if self.kodi.cond(DIALOG_OPEN):
                break
            if self.kodi.wait(0.1):
                return
        waited, closed = 0.0, 0.0
        while waited < timeout and closed < 1.5:
            if self.kodi.wait(0.25):
                return
            waited += 0.25
            closed = 0.0 if self.kodi.cond(DIALOG_OPEN) else closed + 0.25

    def select(self, heading, items):
        import xbmcgui
        return xbmcgui.Dialog().select(heading, items)

    def multiselect(self, heading, items, preselect):
        """-> the chosen indexes, or None when the viewer backs out (nothing changes then)."""
        import xbmcgui
        return xbmcgui.Dialog().multiselect(heading, items, preselect=preselect)

    def teams(self):
        """{league: [teams]}: the catalogue the Live sports service keeps; a league still missing is fetched now."""
        if not hasattr(self, "_teams"):
            from resources.lib.sports import live, scoreboard as sb, teams
            self._teams = teams.refresh(self.kodi.translate(live.TEAMS), live.http_json, sb.LEAGUES,
                                        only_missing=True).get("teams", {})
        return self._teams

    def trakt_account(self):
        from resources.lib.trakt_account import show
        show(self.kodi)

    def build_version(self):
        """The NikeFlix build installed by the wizard (its buildversion setting), else the skin's own version."""
        import xbmcaddon
        v = self.addon_get("plugin.program.nikeflixwizard", "buildversion")
        if v and v != "true":
            return v
        try:
            return xbmcaddon.Addon("skin.nikeflix").getAddonInfo("version")
        except RuntimeError:
            return ""

    def kodi_version(self):
        return self._xbmc.getInfoLabel("System.BuildVersion").split(" ")[0]
