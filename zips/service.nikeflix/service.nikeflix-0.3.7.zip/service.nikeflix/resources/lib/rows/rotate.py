# -*- coding: utf-8 -*-
"""NikeFlix 4.1 rows: write each page's rows into the skin strings its row slots read, and swap the rotating ones
for the next visit.

- Home's rows read `nikeflix.row.home.<n>.{label,path,limit}`; the Shows and Movies hubs read
  `bingiehub-{tvshows,movies,mylist}-5x0.{label,path,limit,target}`. Skin strings are per profile.
- When a settled profile starts, every page is written once. That puts the profile's name in "Continue Watching
  for ..." and finds the last-watched show and film.
- The skin sets the Home property `nikeflix.rows.rotate.<page>` when Home or a hub closes. The service then writes
  that page's next visit, so rows never change in front of the viewer.
- Network work (the last-watched lookup through TMDb Helper) runs on one background thread, never in the poll loop.
"""
import datetime
import json
import os
import threading

from . import catalog

REQUEST = "nikeflix.rows.rotate.%s"   # one Home property per page, set by the skin when the page closes
RELOAD = "TMDbHelper.Widgets.Reload"     # TMDb Helper's own widget refresh token
STATE_FILE = "rows.json"
HISTORY = {"tv": catalog.tm(info="trakt_history", tmdb_type="tv"), "movie": catalog.tm(info="trakt_history", tmdb_type="movie")}
SEEDED = {"tv": ("Because You Watched %s", "recommendations"), "movie": ("Movies Like %s", "similar")}


def quote(value):
    """A Kodi builtin argument: quoted, so commas and brackets in a title stay one argument."""
    return '"%s"' % str(value).replace("\\", "\\\\").replace('"', '\\"')


def last_watched(rpc, kind):
    """(title, tmdb id) of the profile's most recent Trakt history item of that kind, or None."""
    res = rpc("Files.GetDirectory", {"directory": HISTORY[kind], "media": "video",
                                     "properties": ["title", "uniqueid", "showtitle"], "limits": {"start": 0, "end": 5}})
    for item in (res or {}).get("files") or []:
        tmdb = ((item.get("uniqueid") or {}).get("tmdb") or "").strip()
        title = (item.get("showtitle") or item.get("title") or item.get("label") or "").strip()
        if tmdb.isdigit() and title:
            return title, tmdb
    return None


# lists that need the profile's Trakt sign-in (empty without it); without a sign-in they are swapped for public rows.
# The random list rows can ask for a sign-in too (a public list whose owner slug Trakt leaves out is read as "me").
NEEDS_TRAKT = ("info=trakt_ondeck", "info=trakt_recommendations", "info=trakt_watchlist", "info=trakt_becausemostwatched",
               "info=trakt_history", "info=trakt_inprogress", "info=trakt_nextepisodes", "info=trakt_favorites",
               "info=trakt_mylists", "info=trakt_likedlists", "info=random_popularlists", "info=random_trendinglists")


# 4.1.5 (Tanner 2026-11-21): Continue Watching works without Trakt too. For a profile that is not signed in (Guest)
# TMDb Helper builds it from the profile's own watch history (patch 0006, Umbrella's local watched.db) and never asks
# Trakt, so the row stays.
LOCAL_FALLBACK = ("nikeflix=continue",)


def personal(path):
    """A row of the profile's own data (Trakt's, or its local history): it refreshes with TMDb Helper's reload."""
    return any(t + "&" in (path or "") + "&" for t in NEEDS_TRAKT)


def needs_trakt(path):
    if any(t + "&" in (path or "") + "&" for t in LOCAL_FALLBACK):
        return False
    return personal(path)


def resolve(page, visit, name, rpc, today, connected=False):
    """The page's rows for this visit with every placeholder filled.

    Without a Trakt sign-in no row may ask Trakt for the profile's own data: TMDb Helper answers such a request with
    an "Unauthorised 401" dialog (lab 2026-11-19), and Kodi loads a row's list even while the row is hidden. So
    those rows - and seeded rows without data - borrow the page's spare public pool rows; the page stays full."""
    rows, spare = catalog.plan(page, visit)
    spare = [dict(r) for r in spare if not needs_trakt(r.get("path"))]
    nlast = len(catalog.PAGES[page]["last"])
    out, missing = [], 0
    for r in rows:
        r = dict(r)
        seed = r.pop("seed", None)
        if not connected and (seed in SEEDED or needs_trakt(r.get("path"))):
            missing += 1      # filled with public rows after the others, before the closing row(s)
            continue
        if seed in SEEDED:
            found = None
            try:
                found = last_watched(rpc, seed)
            except Exception:
                found = None
            if found:
                fmt, info = SEEDED[seed]
                r = {"label": fmt % found[0], "path": catalog.tm(info=info, tmdb_type=seed, tmdb_id=found[1])}
            elif spare:
                r = dict(spare.pop(0))
            else:
                continue
        # no profile name (the build's seed): "Continue Watching", "Top Picks"
        r["label"] = r["label"].replace("{name}", name) if name else r["label"].replace(" for {name}", "")
        out.append(r)
    fill = spare[:missing]
    at = len(out) - nlast if nlast else len(out)
    return out[:at] + fill + out[at:]


DEFAULT_LIMIT = "75"   # the skin's WidgetsGlobalLimit
# the row controls' ids: Home's widgets 2510, 2520 ...; a hub's rows 1510, 1520 ... (IncludesHubs.xml)
TOP10_IDS = {"home": 2510, "shows": 1510, "movies": 1510}


def write(page, rows, set_string, stop=lambda: False, reload_token=""):
    """Personal (Trakt) rows carry TMDb Helper's refresh token, so Continue Watching updates after playback; the
    service rewrites them whenever TMDb Helper changes the token (Home property TMDbHelper.Widgets.Reload)."""
    for key, r in zip(catalog.slot_keys(page), rows):
        if stop():
            return False
        path = r["path"] + "&widget=true"
        if reload_token and personal(r["path"]):
            path += "&reload=" + reload_token
        set_string(key + ".label", r["label"])
        set_string(key + ".path", path)
        set_string(key + ".limit", str(r.get("limit") or DEFAULT_LIMIT))
        if page != "home":
            set_string(key + ".target", "videos")
    # Top 10 rows show big rank numbers (IncludesHomeWidgets.xml NikeFlixTop10Rank): one flag per page and row id
    if page in TOP10_IDS:
        base = TOP10_IDS[page]
        for i in range(len(catalog.slot_keys(page))):
            top = i < len(rows) and "nikeflix=top10" in rows[i]["path"]
            set_string("nikeflix.top10.%s.%d" % (page, base + 10 * i), "1" if top else "")
            sport = i < len(rows) and "nikeflix=sports" in rows[i]["path"]
            set_string("nikeflix.sports.%s.%d" % (page, base + 10 * i), "1" if sport else "")
    # a page with fewer rows this visit (My NikeFlix signed out): the slots left over are emptied, so no earlier
    # personal row stays behind to ask Trakt for a sign-in
    for key in catalog.slot_keys(page)[len(rows):]:
        if stop():
            return False
        set_string(key + ".label", "")
        set_string(key + ".path", "")
    return True


class RowsEnv(object):
    """Kodi side: profile name, skin strings, JSON-RPC, per-profile state file, today's date."""

    def __init__(self, kodi):
        self.kodi = kodi

    def profile_name(self):
        import xbmc
        return xbmc.getInfoLabel("System.ProfileName")

    def set_string(self, key, value):
        if value == "":
            self.kodi.builtin("Skin.Reset(%s)" % key)
            return
        self.kodi.builtin("Skin.SetString(%s,%s)" % (key, quote(value)))

    def rpc(self, method, params):
        import xbmc
        out = json.loads(xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": method, "params": params})))
        return out.get("result")

    def state_path(self):
        return os.path.join(self.kodi.translate("special://profile/addon_data/service.nikeflix/"), STATE_FILE)

    def today(self):
        return datetime.date.today()


class Rows(object):
    """Polled once a second by service.py, only in a settled profile and never while a profile switch is pending."""

    def __init__(self, env, kodi):
        self.env, self.kodi = env, kodi
        self.started = False
        self.queue = []
        self.worker = None
        self.visits = self._load()
        self.connected = None
        self.reload_token = None

    def _load(self):
        try:
            with open(self.env.state_path(), encoding="utf-8") as fh:
                v = json.load(fh)
            return {p: int(v.get(p, 0)) for p in catalog.PAGES}
        except Exception:
            return {p: 0 for p in catalog.PAGES}

    def _save(self):
        try:
            p = self.env.state_path()
            os.makedirs(os.path.dirname(p), exist_ok=True)
            with open(p, "w", encoding="utf-8") as fh:
                json.dump(self.visits, fh)
        except Exception as exc:
            self.kodi.log("rows: state not saved: %s" % type(exc).__name__, "warning")

    def poll(self):
        if not self.started:
            self.started = True
            self.queue.extend(p for p in catalog.PAGES if p not in self.queue)
        connected = self.kodi.get_prop("nikeflix.trakt.connected") == "true"
        if connected != self.connected:   # signed in or out: every page swaps its personal / public rows
            if self.connected is not None:
                self.queue.extend(p for p in catalog.PAGES if p not in self.queue)
            self.connected = connected
        token = self.kodi.get_prop(RELOAD)
        if token != self.reload_token:     # TMDb Helper asks its widgets to refresh (after playback, a Trakt sync)
            if self.reload_token is not None:
                self.queue.extend(p for p in catalog.PAGES if p not in self.queue)
            self.reload_token = token
        for page in catalog.PAGES:
            if self.kodi.get_prop(REQUEST % page):
                self.kodi.clear_prop(REQUEST % page)
                self.visits[page] = self.visits.get(page, 0) + 1
                self._save()
                if page not in self.queue:
                    self.queue.append(page)
        if self.queue and (self.worker is None or not self.worker.is_alive()):
            pages, self.queue = list(self.queue), []
            self.worker = threading.Thread(target=self._apply, args=(pages,), name="nikeflix-rows")
            self.worker.daemon = True
            self.worker.start()

    def end(self, timeout=3.0):
        """Service exit (profile switch or shutdown): wait briefly for a running write; it stops at its next check."""
        w = self.worker
        if w is not None and w.is_alive():
            w.join(timeout)

    def _stop(self):
        """A profile switch or shutdown: write nothing more (skin strings belong to the profile loaded now)."""
        return bool(self.kodi.get_prop("nikeflix.quiesce")) or self.kodi.aborted()

    def _apply(self, pages):
        name = self.env.profile_name()
        for page in pages:
            if self._stop():
                return
            try:
                rpc = self.env.rpc

                def guarded(method, params):    # no TMDb Helper lookup once a profile switch has begun
                    if self._stop():
                        raise RuntimeError("profile switch")
                    return rpc(method, params)
                rows = resolve(page, self.visits.get(page, 0), name, guarded, self.env.today(), connected=bool(self.connected))
                if not write(page, rows, self.env.set_string, self._stop, reload_token=self.reload_token or ""):
                    return
                self.kodi.log("rows: %s visit %d -> %s" % (page, self.visits.get(page, 0), " | ".join(r["label"] for r in rows)))
            except Exception as exc:
                self.kodi.log("rows: %s not written: %s" % (page, type(exc).__name__), "warning")
