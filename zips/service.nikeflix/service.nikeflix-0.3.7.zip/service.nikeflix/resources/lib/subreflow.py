# -*- coding: utf-8 -*-
"""NikeFlix 4.1.5 Netflix-style subtitles (Tanner 2026-11-21, approved preview v20): every cue of an external text
subtitle (SRT) is rewritten the way Netflix sets its subtitles before Kodi shows it. Pure Python, no Kodi.

Netflix's rules (Timed Text Style Guide), as the preview's subLayout() applies them:
- at most two lines of at most 42 characters; a cue that fits on one line stays on one line;
- two lines are balanced with the bottom line the longer one, and break after punctuation where they can;
- two speakers keep one line each, each starting with a dash;
- a cue longer than two lines can hold (84 characters) becomes two cues, its time shared out by length.
The preview allowed a split line up to 46 characters; NikeFlix keeps Netflix's 42 and only goes over it when no
split fits (a very long word), up to the preview's 46.

"Keep subtitles at the bottom": {\\an8}-style position tags are dropped, so a line a file puts at the top of the picture
comes up at the bottom (Kodi's own subtitles.overridestyles does the same for styled subtitles).

Embedded subtitles (inside the video file) never pass through here: Kodi reads them from the stream.

Callers: Umbrella and a4kSubtitles (NikeFlix patches) load this file with nikeflix_subtitles.py and call
reflow_file() on the SRT they are about to hand to Kodi.
"""
import io
import os
import re

MAX_LINE = 42           # Netflix: characters a line
SOFT_MAX_LINE = 46      # the preview's limit, only when no split fits in 42
MAX_CUE = 2 * MAX_LINE  # more than this becomes two cues
MIN_PART_MS = 700       # a split cue keeps at least this long on screen

_TAG = re.compile(r"<[^>]*>|\{\\[^}]*\}")
_POS = re.compile(r"\{\\an?\d+\}")
_TIME = re.compile(r"^\s*(\d{1,2}):(\d{2}):(\d{2})[,.](\d{1,3})\s*-->\s*(\d{1,2}):(\d{2}):(\d{2})[,.](\d{1,3})(.*)$")
_PUNCT = re.compile(r"[,.;:?!…]$")
_DASH = re.compile(r"^\s*(?:<[^>]*>\s*)*[-‐–—]")


def visible(text):
    """The text as seen on screen: tags removed."""
    return _TAG.sub("", text or "")


def _vlen(text):
    return len(visible(text))


def is_dialogue(lines):
    """Two (or more) speakers: every line starts with a dash."""
    return len(lines) >= 2 and all(_DASH.match(l) for l in lines)


def _best_split(words, limit):
    best = None
    for k in range(1, len(words)):
        a, b = " ".join(words[:k]), " ".join(words[k:])
        la, lb = _vlen(a), _vlen(b)
        if la > limit or lb > limit:
            continue
        score = abs(lb - la) + (6 if la > lb else 0) + (-14 if _PUNCT.search(visible(a).rstrip()) else 0)
        if best is None or score < best[0]:
            best = (score, [a, b])
    return best[1] if best else None


def layout(lines):
    """One cue's text lines -> at most two lines, Netflix-style (the preview's subLayout)."""
    lines = [l.strip() for l in lines if l and l.strip()]
    if not lines:
        return []
    if len(lines) == 2 and is_dialogue(lines):
        return lines
    words = " ".join(lines).split()
    whole = " ".join(words)
    if _vlen(whole) <= MAX_LINE:
        return [whole]
    for limit in (MAX_LINE, SOFT_MAX_LINE):
        split = _best_split(words, limit)
        if split:
            return split
    return _greedy_two(words)


def _greedy_two(words):
    """No balanced split fits (a word longer than a line): fill the first line, the rest on the second."""
    first, rest = [], list(words)
    while rest and (not first or _vlen(" ".join(first + rest[:1])) <= SOFT_MAX_LINE):
        first.append(rest.pop(0))
    return [" ".join(first)] + ([" ".join(rest)] if rest else [])


def _split_text(words):
    """A cue too long for two lines -> two word lists, cut where a sentence or clause ends nearest the middle."""
    total = _vlen(" ".join(words))
    best = None
    for k in range(1, len(words)):
        a = _vlen(" ".join(words[:k]))
        b = total - a - 1
        end = visible(words[k - 1]).rstrip()
        bonus = 30 if re.search(r"[.?!…]$", end) else (12 if _PUNCT.search(end) else 0)
        over = max(0, a - MAX_CUE) + max(0, b - MAX_CUE)
        score = abs(a - b) - bonus + 1000 * over
        if best is None or score < best[0]:
            best = (score, k)
    k = best[1] if best else max(1, len(words) // 2)
    return words[:k], words[k:]


def split_cue(start, end, lines):
    """One cue -> [(start, end, lines)], each with at most two lines (times in ms)."""
    lines = [l.strip() for l in lines if l and l.strip()]
    if not lines:
        return []
    if is_dialogue(lines):
        groups = [lines[i:i + 2] for i in range(0, len(lines), 2)]
    else:
        words = " ".join(lines).split()
        groups = [words]
        while any(_vlen(" ".join(g)) > MAX_CUE for g in groups) and len(groups) < 8:
            out = []
            for g in groups:
                out.extend(_split_text(g) if _vlen(" ".join(g)) > MAX_CUE and len(g) > 1 else [g])
            if len(out) == len(groups):
                break
            groups = out
        groups = [[" ".join(g)] for g in groups]
    if len(groups) == 1:
        return [(start, end, layout(groups[0]))]
    sizes = [max(1, _vlen(" ".join(g))) for g in groups]
    span = max(0, end - start)
    if span < MIN_PART_MS * len(groups):
        # too short to show the parts one after another: keep one cue, two lines (the extra words are not lost)
        return [(start, end, layout(lines))]
    out, at = [], start
    for i, (g, n) in enumerate(zip(groups, sizes)):
        stop = end if i == len(groups) - 1 else at + int(round(span * n / float(sum(sizes))))
        out.append((at, stop, layout(g)))
        at = stop
    return out


# --- SRT ----------------------------------------------------------------------------------------------------------
def _ms(h, m, s, f):
    return ((int(h) * 60 + int(m)) * 60 + int(s)) * 1000 + int((f + "00")[:3])


def _stamp(ms):
    ms = max(0, int(ms))
    h, ms = divmod(ms, 3600000)
    m, ms = divmod(ms, 60000)
    s, ms = divmod(ms, 1000)
    return "%02d:%02d:%02d,%03d" % (h, m, s, ms)


def parse_srt(text):
    """-> [(start ms, end ms, [lines], extra timing text)]; blocks without a timing line are skipped."""
    cues = []
    block = []
    for raw in (text or "").replace("\r\n", "\n").replace("\r", "\n").split("\n") + [""]:
        if raw.strip():
            block.append(raw)
            continue
        if block:
            for i, line in enumerate(block[:2]):
                m = _TIME.match(line)
                if m:
                    g = m.groups()
                    cues.append((_ms(*g[0:4]), _ms(*g[4:8]), block[i + 1:], g[8]))
                    break
            block = []
    return cues


def write_srt(cues):
    out = []
    for n, (start, end, lines) in enumerate(cues, 1):
        out.append("%d\n%s --> %s\n%s\n" % (n, _stamp(start), _stamp(end), "\n".join(lines)))
    return "\n".join(out)


def reflow_srt(text, two_lines=True, bottom=True):
    """-> (new SRT text, number of cues changed). Unchanged text when nothing needs changing."""
    cues = parse_srt(text)
    if not cues:
        return text, 0
    out, changed = [], 0
    for start, end, lines, _extra in cues:
        before = list(lines)
        if bottom:
            lines = [_POS.sub("", l) for l in lines]
        lines = [l for l in lines if visible(l).strip()]
        if two_lines:
            parts = split_cue(start, end, lines)
        else:
            parts = [(start, end, [l.strip() for l in lines if l.strip()])]
        parts = [p for p in parts if p[2]]
        if [list(p[2]) for p in parts] != [[l.strip() for l in before if l.strip()]] or len(parts) != 1:
            changed += 1
        out.extend(parts)
    if not changed:
        return text, 0
    return write_srt(out), changed


def _decode(data):
    for enc in ("utf-8-sig", "cp1252"):
        try:
            return data.decode(enc)
        except UnicodeDecodeError:
            continue
    return data.decode("latin-1")


def reflow_file(path, two_lines=True, bottom=True, log=None):
    """Rewrite an external SRT in place (UTF-8 with a BOM, which Kodi reads as UTF-8). Returns the path to hand to
    Kodi: always `path`; any problem leaves the file as it was."""
    try:
        if not path or os.path.splitext(path)[1].lower() != ".srt" or not os.path.isfile(path):
            return path
        if not two_lines and not bottom:
            return path
        with io.open(path, "rb") as fh:
            data = fh.read()
        new, changed = reflow_srt(_decode(data), two_lines=two_lines, bottom=bottom)
        if changed:
            tmp = path + ".nikeflix"
            with io.open(tmp, "wb") as fh:
                fh.write(b"\xef\xbb\xbf" + new.encode("utf-8"))
            os.replace(tmp, path)
        if log:
            log("subtitles: %s rewritten Netflix-style (%d cues changed)" % (os.path.basename(path), changed))
    except Exception as exc:  # never lose the subtitle over this
        if log:
            log("subtitles: %s left as it was (%s)" % (os.path.basename(path or ""), exc))
    return path
