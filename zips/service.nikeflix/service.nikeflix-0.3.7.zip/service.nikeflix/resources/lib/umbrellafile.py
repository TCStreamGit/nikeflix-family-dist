# -*- coding: utf-8 -*-
"""Keep Umbrella's profile settings file complete and equal to Kodi's values (NikeFlix 4.1.4).

Umbrella does not read its settings through Kodi. `control.make_settings_dict` parses
`addon_data/plugin.video.umbrella/settings.xml` straight from disk (minidom) and caches the result in the Home property
`umbrella_settings`; a setting missing from that file reads as ''. Two field failures on 2026-11-21:

* The build seeds each profile with a short file (35-39 settings). Kodi fills in the defaults only when it saves the
  file, so until then `int(getSetting('cache.providers'))` raised and every play fell back to Fen.
* On tvOS Kodi keeps userdata *.xml in its own store (NSUserDefaults) and never writes the disk file, so the file
  stayed short for good, and Umbrella never saw a value NikeFlix gave it (the Trakt token, Premiumize). The Trakt
  broker then saw a stale Umbrella cache every minute, pushed the token again, and the reloads got the account
  rate-limited by Trakt (429, Retry-After of minutes; Umbrella slept up to 246 s before playing).

`sync` takes every setting id Umbrella defines, asks Kodi for its value (Kodi returns the default for an unset id),
writes the complete file to disk when it differs, and publishes the same values as Umbrella's cache, so the cache
can never lag behind. Nothing here logs a value.
"""
import json
import os
import re
from xml.sax.saxutils import escape

UMB = "plugin.video.umbrella"
CACHE_PROP = "umbrella_settings"
DEFS = "special://home/addons/%s/resources/settings.xml" % UMB
FILE = "special://profile/addon_data/%s/settings.xml" % UMB
TVOS_EVERY_S = 600.0     # tvOS: Umbrella's own saves never reach the disk file, so re-sync while the profile is open
START_DELAY_S = 5.0

_ID = re.compile(r'<setting\s+id="([^"]+)"')


def setting_ids(defs_xml):
    """Every setting id Umbrella defines, in order, once each."""
    seen, out = set(), []
    for sid in _ID.findall(defs_xml or ""):
        if sid not in seen:
            seen.add(sid)
            out.append(sid)
    return out


def render(values):
    body = "\n".join('    <setting id="%s">%s</setting>' % (k, escape(v or "")) for k, v in sorted(values.items()))
    return '<settings version="2">\n%s\n</settings>\n' % body


def sync(env):
    """One pass. Returns None (Umbrella absent or unreadable), False (already in step) or True (file rewritten)."""
    ids = setting_ids(env.read_defs())
    if not ids:
        return None
    values = {}
    for sid in ids:
        v = env.get_value(sid)
        values[sid] = "" if v is None else v
    new = render(values)
    changed = env.read_disk() != new
    if changed:
        env.write_disk(new)
    env.set_cache(json.dumps(values))
    return changed


class UmbrellaFile(object):
    """Polled by service.py in a settled profile: one sync shortly after the profile starts, then every
    TVOS_EVERY_S on tvOS. `sync_now` is called by the Trakt broker and the household keys right after they write."""

    def __init__(self, env, guard_ready):
        self.env, self.guard_ready = env, guard_ready
        self.ready_since = None
        self.next_sync = 0.0
        self.done_once = False

    def sync_now(self, why=""):
        try:
            changed = sync(self.env)
        except Exception as exc:   # never break a caller
            self.env.log("umbrella settings: sync failed (%s)" % type(exc).__name__, "warning")
            return None
        if changed:
            self.env.log("umbrella settings: file completed and brought in step with Kodi%s" % (" (%s)" % why if why else ""))
        return changed

    def poll(self):
        if not self.env.installed():
            return None
        now = self.env.clock()
        if not self.guard_ready():
            self.ready_since = None
            return None
        if self.ready_since is None:
            self.ready_since = now
        if now - self.ready_since < START_DELAY_S:
            return None
        if self.done_once and not (self.env.is_tvos() and now >= self.next_sync):
            return None
        why = "tvOS refresh" if self.done_once else "profile start"
        self.done_once = True
        self.next_sync = now + TVOS_EVERY_S
        return self.sync_now(why)


class UmbrellaFileEnv(object):
    def __init__(self, kodi):
        self.kodi = kodi

    def clock(self):
        return self.kodi.now()

    def log(self, msg, level="info"):
        self.kodi.log(msg, level)

    def installed(self):
        import xbmc
        return bool(xbmc.getCondVisibility("System.HasAddon(%s)" % UMB))

    def is_tvos(self):
        import xbmc
        return bool(xbmc.getCondVisibility("System.Platform.TVOS"))

    def read_defs(self):
        try:
            with open(self.kodi.translate(DEFS), encoding="utf-8", errors="replace") as fh:
                return fh.read()
        except OSError:
            return ""

    def get_value(self, sid):
        import xbmcaddon
        try:
            return xbmcaddon.Addon(UMB).getSetting(sid)
        except Exception:
            return None

    def read_disk(self):
        try:
            with open(self.kodi.translate(FILE), encoding="utf-8", errors="replace") as fh:
                return fh.read()
        except OSError:
            return None

    def write_disk(self, text):
        path = self.kodi.translate(FILE)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        tmp = path + ".nikeflix.tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            fh.write(text)
        os.replace(tmp, path)

    def set_cache(self, raw):
        self.kodi.set_prop(CACHE_PROP, raw)
