# -*- coding: utf-8 -*-
"""NikeFlix 4.1.5 Netflix-style subtitles on every profile (approved preview v20).

- The font: Kodi lists subtitle fonts from special://home/media/Fonts (not from the skin). The build ships Inter Medium
  there as settings_ui.SUB_FONT_FILE; an install updated through the repository never got it, so the service copies
  it from the skin (skin.nikeflix/fonts/Inter-Medium.ttf) when it is missing or different.
- The look: a profile still on the 4.1.0-4.1.4 Netflix look (thin 12 % border, 10 % shadow at 60 %, sizes 38/46/56,
  Kodi's font, positions from the file) moves to the 4.1.5 one once (own setting subs.applied). A value the viewer
  changed in Kodi's own subtitle settings is never touched.
Pure decisions over an env (unit-tested with a fake); SubtitleEnv is the Kodi side.
"""
from resources.lib import settings_ui as su

FONT_SOURCE = "special://home/addons/skin.nikeflix/fonts/Inter-Medium.ttf"
FONT_DIR = "special://home/media/Fonts/"
APPLIED = "subs.applied"
VERSION = "4.1.5"
OLD_LOOK = {"subtitles.bordersize": 12, "subtitles.shadowsize": 10, "subtitles.shadowopacity": 60}
OLD_SIZES = {38: 34, 46: 40, 56: 48, 42: 40}       # 42 is Kodi's own default
OLD_FONT = ("DEFAULT", "", "arial.ttf")


def _num(v):
    try:
        return int(float(v))
    except (TypeError, ValueError):
        return None


def migrate(env):
    """-> {setting: value} written (empty when the profile already has the 4.1.5 look or it was applied before).
    The look is changed once; the font, which Kodi only lists after a restart once it is copied in, is retried on
    every profile start until Kodi takes it (subs.applied "4.1.5-font" until then)."""
    applied = env.addon_get(su.OWN, APPLIED) or ""
    if applied == VERSION:
        return {}
    written = {}

    def put(sid, value):
        env.kodi_set(sid, value)
        written[sid] = value

    if applied != VERSION + "-font":
        if all(_num(env.kodi_get(k)) == v for k, v in OLD_LOOK.items()):
            for k, v in su.NETFLIX_SUBS.items():
                if k != "subtitles.fontname" and _num(env.kodi_get(k)) != v:
                    put(k, v)
        size = _num(env.kodi_get("subtitles.fontsize"))
        if size in OLD_SIZES:
            put("subtitles.fontsize", OLD_SIZES[size])
        if _num(env.kodi_get("subtitles.overridestyles")) == 0:
            put("subtitles.overridestyles", su.BOTTOM_ON)
    font = str(env.kodi_get("subtitles.fontname") or "")
    if font in OLD_FONT and env.font_ready():
        put("subtitles.fontname", su.SUB_FONT_FAMILY)
        font = str(env.kodi_get("subtitles.fontname") or "")   # Kodi refuses a family it has not listed yet
    env.addon_set(su.OWN, APPLIED, VERSION if font not in OLD_FONT else VERSION + "-font")
    return written


def font_plan(source_size, target_size):
    """True when the font must be copied (missing, or a different file)."""
    return source_size is not None and source_size != target_size


class SubtitleEnv(object):
    """Kodi side: guisettings through JSON-RPC, files through xbmcvfs (special:// paths)."""

    def __init__(self, kodi):
        import xbmcvfs
        self.kodi, self.vfs = kodi, xbmcvfs
        self._settings = su.SettingsEnv(kodi)

    def kodi_get(self, sid):
        return self._settings.kodi_get(sid)

    def kodi_set(self, sid, value):
        self._settings.kodi_set(sid, value)

    def addon_get(self, aid, sid):
        return self._settings.addon_get(aid, sid)

    def addon_set(self, aid, sid, value):
        self._settings.addon_set(aid, sid, value)

    def _size(self, path):
        if not self.vfs.exists(path):
            return None
        try:
            return self.vfs.Stat(path).st_size()
        except Exception:
            return None

    def ensure_font(self):
        target = FONT_DIR + su.SUB_FONT_FILE
        src, dst = self._size(FONT_SOURCE), self._size(target)
        if not font_plan(src, dst):
            return dst is not None
        self.vfs.mkdirs(FONT_DIR)
        ok = bool(self.vfs.copy(FONT_SOURCE, target))
        self.kodi.log("subtitles: %s %s" % (su.SUB_FONT_FILE, "copied into media/Fonts" if ok else "could not be copied"))
        return ok

    def font_ready(self):
        if not hasattr(self, "_font"):
            self._font = self.ensure_font()
        return self._font


class SubtitleCare(object):
    """Once per profile, in a settled profile: the font into media/Fonts and the 4.1.5 look (migrate)."""

    def __init__(self, kodi, env=None):
        self.kodi, self.env, self.done = kodi, env, False

    def poll(self):
        if self.done:
            return
        self.done = True
        env = self.env or SubtitleEnv(self.kodi)
        written = migrate(env)
        if written:
            self.kodi.log("subtitles: Netflix-style look applied (%s)" % ", ".join(
                "%s=%s" % kv for kv in sorted(written.items())))
