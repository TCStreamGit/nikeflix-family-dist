# -*- coding: utf-8 -*-
"""YouTube keys from the household's NikeFlix PC (NikeFlix 4.1.3, Tanner 2026-11-20: "Yes, build 4.1.3" - automatic
YouTube key delivery).

The YouTube add-on needs its own API key and OAuth client. Without them, any call it makes to YouTube's Data API
stops on its "key.requirement" dialog. NikeFlix keeps the keys in the PC's vault (`household.youtube.youtube.api.*`)
and never in a build: the dist repositories are public.

Delivery is a two-message exchange on the home network, started by the PC (`tools/nfprovision youtube`):
  PC -> device  "NIKEFLIX-KEYS/1 HELLO <nonce>"            to UDP PORT, unicast, from a private address
  device -> PC  "NIKEFLIX-KEYS/1 NEED youtube <fp> <nonce>"  the device's key fingerprint, or "none"
  PC -> device  "NIKEFLIX-KEYS/1 KEYS <json>"               only when the fingerprints differ
  device -> PC  "NIKEFLIX-KEYS/1 OK <fp>"
The device answers only private (RFC 1918 / loopback) addresses. It accepts KEYS only from an address that sent a
HELLO in the last HELLO_TTL_S, and it never sends a key. Keys are stored once per device
(special://masterprofile/addon_data/service.nikeflix/household-keys.json). They are applied to the YouTube add-on of
whichever profile is in use: Kodi keeps add-on settings per profile, so each profile gets them when it next starts.
Nothing here logs a key.

NikeFlix 4.1.4 (Tanner 2026-11-21: "all installs should have this premiumize and other api keys already"): the same
exchange carries the household accounts. NEED ends with "accounts <fp>", KEYS may carry
{"accounts": {"pm_key", "pm_id", "tmdb"}} (Premiumize API key and customer id, TMDb API key), and every profile gets
them in Umbrella (its settings and its disk file, umbrellafile.py) and Fen (databases/settings.db) when it starts.
A 4.1.3 PC tool reads only the youtube fingerprint and keeps working.

Per-profile preferences travel the same way: {"profiles": {"<profile name>": {"skip.intro": "1"}}}, NEED ending with
"profiles <fp>". Only the whitelisted NikeFlix settings in PROFILE_PREFS are accepted. A profile applies a given set
once (its fingerprint is remembered in the hidden setting skip.household.prefs), so a later change made on the
device itself is kept until the household sends a different set.
"""
import hashlib
import ipaddress
import json
import os
import socket
import threading
import time

PORT = 50181
MAGIC = "NIKEFLIX-KEYS/1"
HELLO_TTL_S = 60.0
DELAY_S = 15.0
CHECK_EVERY_S = 600.0
YT = "plugin.video.youtube"
FIELDS = (("api_key", "youtube.api.key"), ("api_id", "youtube.api.id"), ("api_secret", "youtube.api.secret"))
STORE = "special://masterprofile/addon_data/service.nikeflix/household-keys.json"
ACCOUNT_FIELDS = ("pm_key", "pm_id", "tmdb")
TRAKT_FIELDS = ("access_token", "refresh_token")
PROFILE_PREFS = {"skip.intro": ("0", "1", "2"), "skip.recap": ("0", "1", "2")}   # NikeFlix settings a household may set
PREFS_APPLIED = "skip.household.prefs"
UMB = "plugin.video.umbrella"
FEN = "plugin.video.fen"
FEN_DB = "special://profile/addon_data/plugin.video.fen/databases/settings.db"
UMB_KEYS = (("premiumizetoken", "pm_key"), ("premiumizeusername", "pm_id"), ("tmdb.apikey", "tmdb"))
FEN_KEYS = (("pm.token", "pm_key"), ("pm.account_id", "pm_id"), ("tmdb_api", "tmdb"))


def fingerprint(keys):
    if not keys or not all(keys.get(f) for f, _ in FIELDS):
        return "none"
    return hashlib.sha256("|".join(keys[f] for f, _ in FIELDS).encode("utf-8")).hexdigest()[:16]


def valid_accounts(acc):
    if not isinstance(acc, dict):
        return None
    out = {}
    for f in ACCOUNT_FIELDS:
        v = acc.get(f)
        if not isinstance(v, str) or not v or len(v) > 256 or any(c.isspace() for c in v):
            return None
        out[f] = v
    return out


def valid_profiles(prof):
    """{name: {setting: value}} with whitelisted settings and values only; None when anything else is in it."""
    if not isinstance(prof, dict) or len(prof) > 20:
        return None
    out = {}
    for name, prefs in prof.items():
        if not isinstance(name, str) or not name.strip() or len(name) > 64 or not isinstance(prefs, dict):
            return None
        clean = {}
        for k, v in prefs.items():
            if k not in PROFILE_PREFS or not isinstance(v, str) or v not in PROFILE_PREFS[k]:
                return None
            clean[k] = v
        out[name.strip()] = clean
    return out


def valid_trakt(body):
    """{"profile": name, "token": {access_token, refresh_token, created_at, expires_in, scope?, username?},
    "client_id"?: str} for ONE profile, normalised; None when anything is off."""
    if not isinstance(body, dict):
        return None
    name, tok = body.get("profile"), body.get("token")
    if not isinstance(name, str) or not name.strip() or len(name) > 64 or not isinstance(tok, dict):
        return None
    out = {}
    for f in TRAKT_FIELDS:
        v = tok.get(f)
        if not isinstance(v, str) or not v or len(v) > 512 or any(c.isspace() for c in v):
            return None
        out[f] = v
    try:
        out["created_at"], out["expires_in"] = int(tok.get("created_at")), int(tok.get("expires_in"))
    except (TypeError, ValueError):
        return None
    for f in ("scope", "username"):
        v = tok.get(f, "")
        if not isinstance(v, str) or len(v) > 128:
            return None
        out[f] = v
    cid = body.get("client_id", "")
    if not isinstance(cid, str) or len(cid) > 128 or any(c.isspace() for c in cid):
        return None
    return {"profile": name.strip(), "token": out, "client_id": cid}


def fingerprint_profiles(prof):
    if not prof:
        return "none"
    return hashlib.sha256(("profiles|" + json.dumps(prof, sort_keys=True)).encode("utf-8")).hexdigest()[:16]


def fingerprint_accounts(acc):
    if not acc or not all(acc.get(f) for f in ACCOUNT_FIELDS):
        return "none"
    return hashlib.sha256(("accounts|" + "|".join(acc[f] for f in ACCOUNT_FIELDS)).encode("utf-8")).hexdigest()[:16]


def valid_keys(keys):
    if not isinstance(keys, dict):
        return None
    out = {}
    for f, _ in FIELDS:
        v = keys.get(f)
        if not isinstance(v, str) or not v or len(v) > 256 or any(c.isspace() for c in v):
            return None
        out[f] = v
    return out


def is_private(ip):
    try:
        a = ipaddress.ip_address(ip)
    except ValueError:
        return False
    return a.is_private or a.is_loopback


class KeyStore(object):
    def __init__(self, path):
        self.path = path

    def _raw(self):
        try:
            with open(self.path, encoding="utf-8") as fh:
                d = json.load(fh)
            return d if isinstance(d, dict) else {}
        except (OSError, ValueError):
            return {}

    def load(self):
        return valid_keys(self._raw().get("youtube"))

    def load_accounts(self):
        return valid_accounts(self._raw().get("accounts"))

    def load_profiles(self):
        return valid_profiles(self._raw().get("profiles"))

    def load_trakt(self, profile):
        """The pending Trakt hand-off for `profile`, or None."""
        pend = self._raw().get("trakt") or {}
        return valid_trakt(dict(pend.get(profile) or {}, profile=profile)) if profile in pend else None

    def save_trakt(self, handoff):
        d = self._raw()
        d.setdefault("trakt", {})[handoff["profile"]] = {"token": handoff["token"], "client_id": handoff["client_id"]}
        self._write(d)

    def drop_trakt(self, profile):
        d = self._raw()
        if profile in (d.get("trakt") or {}):
            del d["trakt"][profile]
            self._write(d)

    def save(self, keys=None, accounts=None, profiles=None):
        """Store the sections given; a section not given keeps what the device had."""
        d = self._raw()
        if keys is not None:
            d["youtube"] = keys
        if accounts is not None:
            d["accounts"] = accounts
        if profiles is not None:
            d["profiles"] = profiles
        d["received_at"] = int(time.time())
        self._write(d)

    def _write(self, d):
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        tmp = self.path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(d, fh)
        os.replace(tmp, self.path)


class Responder(object):
    """The device side of the exchange (pure: `handle` takes a datagram and returns the reply, if any)."""

    def __init__(self, store, clock=time.time):
        self.store, self.clock = store, clock
        self.hellos = {}            # ip -> time of its last HELLO
        self.received = threading.Event()

    def handle(self, data, ip):
        if not is_private(ip):
            return None
        try:
            text = data.decode("utf-8")
        except UnicodeDecodeError:
            return None
        if not text.startswith(MAGIC + " "):
            return None
        verb, _, rest = text[len(MAGIC) + 1:].partition(" ")
        now = self.clock()
        if verb == "HELLO":
            nonce = rest.strip()[:64]
            self.hellos[ip] = now
            return ("%s NEED youtube %s %s accounts %s profiles %s" % (
                MAGIC, fingerprint(self.store.load()), nonce, fingerprint_accounts(self.store.load_accounts()),
                fingerprint_profiles(self.store.load_profiles()))).encode("utf-8")
        if verb == "KEYS":
            if now - self.hellos.get(ip, -1e9) > HELLO_TTL_S:
                return None
            try:
                body = json.loads(rest) or {}
            except ValueError:
                body = None
            if isinstance(body, dict) and "trakt" in body:     # a Trakt hand-off travels on its own
                tr = valid_trakt(body.get("trakt"))
                if tr is None:
                    return ("%s BAD" % MAGIC).encode("utf-8")
                self.store.save_trakt(tr)
                self.received.set()
                return ("%s OK trakt %s" % (MAGIC, tr["profile"].replace(" ", "_"))).encode("utf-8")
            if not isinstance(body, dict) or not ("youtube" in body or "accounts" in body or "profiles" in body):
                return ("%s BAD" % MAGIC).encode("utf-8")
            keys = valid_keys(body.get("youtube")) if "youtube" in body else None
            acc = valid_accounts(body.get("accounts")) if "accounts" in body else None
            prof = valid_profiles(body.get("profiles")) if "profiles" in body else None
            if ("youtube" in body and keys is None) or ("accounts" in body and acc is None) or \
                    ("profiles" in body and prof is None):
                return ("%s BAD" % MAGIC).encode("utf-8")
            self.store.save(keys=keys, accounts=acc, profiles=prof)
            self.received.set()
            return ("%s OK %s accounts %s" % (MAGIC, fingerprint(self.store.load()),
                                              fingerprint_accounts(self.store.load_accounts()))).encode("utf-8")
        return None


def apply_youtube(env, keys):
    """Write the keys into this profile's YouTube add-on where they differ. Returns the number of settings changed."""
    changed = 0
    for f, sid in FIELDS:
        if env.yt_get(sid) != keys[f]:
            env.yt_set(sid, keys[f])
            changed += 1
    return changed


def apply_accounts(env, acc):
    """The household accounts into this profile's Umbrella and Fen where they differ. Returns settings changed."""
    changed = 0
    if env.addon_installed(UMB):
        want = dict((sid, acc[f]) for sid, f in UMB_KEYS)
        want["premiumize.enable"] = "true"
        for sid, v in want.items():
            if env.addon_get(UMB, sid) != v:
                env.addon_set(UMB, sid, v)
                changed += 1
        if changed:
            env.sync_umbrella()
    if env.addon_installed(FEN):
        changed += env.fen_set(dict((sid, acc[f]) for sid, f in FEN_KEYS))
    return changed


def apply_profile_prefs(env, profiles):
    """This profile's household preferences, once per set (see PREFS_APPLIED). Returns settings changed."""
    prefs = (profiles or {}).get(env.profile_name() or "")
    if not prefs:
        return 0
    fp = fingerprint_profiles({"p": prefs})
    if env.own_get(PREFS_APPLIED) == fp:
        return 0
    changed = 0
    for k, v in sorted(prefs.items()):
        if env.own_get(k) != v:
            env.own_set(k, v)
            changed += 1
    env.own_set(PREFS_APPLIED, fp)
    return changed


class YtKeys(object):
    """Polled by service.py in a settled profile: listens for the PC and applies the stored keys to this profile."""

    def __init__(self, env, guard_ready):
        self.env, self.guard_ready = env, guard_ready
        self.store = KeyStore(env.store_path())
        self.responder = Responder(self.store)
        self.ready_since = None
        self.next_apply = 0.0
        self.stop = threading.Event()
        self.thread = None
        self.port = PORT

    def poll(self):
        now = self.env.clock()
        if not self.guard_ready():
            self.ready_since = None
            return None
        if self.ready_since is None:
            self.ready_since = now
        if now - self.ready_since < DELAY_S:
            return None
        if self.thread is None:
            self.thread = threading.Thread(target=self._listen, name="nikeflix-ytkeys")
            self.thread.daemon = True
            self.thread.start()
        if self.responder.received.is_set() or now >= self.next_apply:
            self.responder.received.clear()
            self.next_apply = now + CHECK_EVERY_S
            keys = self.store.load()
            applied = None
            if keys and self.env.youtube_installed():
                n = apply_youtube(self.env, keys)
                if n:
                    self.env.log("YouTube keys applied to this profile (%d setting(s))" % n)
                    applied = "applied"
            acc = self.store.load_accounts()
            if acc:
                n = apply_accounts(self.env, acc)
                if n:
                    self.env.log("household accounts applied to this profile (%d setting(s))" % n)
                    applied = "applied"
            name = self.env.profile_name() or ""
            pending = self.store.load_trakt(name) if name else None
            if pending and self.env.trakt_import(pending):
                self.store.drop_trakt(name)
                self.env.log("Trakt sign-in received for this profile")
                applied = "applied"
            n = apply_profile_prefs(self.env, self.store.load_profiles())
            if n:
                self.env.log("household preferences applied to this profile (%d setting(s))" % n)
                applied = "applied"
            return applied
        return None

    def _listen(self):
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            sock.bind(("", self.port))
            sock.settimeout(1.0)
        except OSError as exc:
            self.env.log("YouTube keys: cannot listen on UDP %d (%s)" % (self.port, type(exc).__name__), "warning")
            return
        try:
            while not self.stop.is_set():
                try:
                    data, addr = sock.recvfrom(4096)
                except socket.timeout:
                    continue
                except OSError:
                    break
                try:
                    reply = self.responder.handle(data, addr[0])
                    if reply:
                        sock.sendto(reply, addr)
                except Exception as exc:   # one bad datagram never stops the listener
                    self.env.log("YouTube keys: datagram ignored (%s)" % type(exc).__name__, "warning")
        finally:
            sock.close()

    def end(self):
        self.stop.set()
        if self.thread is not None:
            self.thread.join(2.0)


class YtKeysEnv(object):
    def __init__(self, kodi):
        self.kodi = kodi

    def clock(self):
        return time.time()

    def log(self, msg, level="info"):
        self.kodi.log(msg, level)

    def store_path(self):
        return self.kodi.translate(STORE)

    def youtube_installed(self):
        import xbmc
        return bool(xbmc.getCondVisibility("System.HasAddon(%s)" % YT))

    def yt_get(self, sid):
        import xbmcaddon
        try:
            return xbmcaddon.Addon(YT).getSetting(sid)
        except RuntimeError:
            return None

    def yt_set(self, sid, value):
        import xbmcaddon
        xbmcaddon.Addon(YT).setSetting(sid, value)

    def profile_name(self):
        import xbmc
        return xbmc.getInfoLabel("System.ProfileName")

    def own_get(self, sid):
        import xbmcaddon
        try:
            return xbmcaddon.Addon("service.nikeflix").getSetting(sid)
        except RuntimeError:
            return None

    def own_set(self, sid, value):
        import xbmcaddon
        xbmcaddon.Addon("service.nikeflix").setSetting(sid, value)

    def trakt_import(self, handoff):
        """Save the handed-off token as this profile's Trakt sign-in and give it to the consumers (the broker)."""
        from resources.lib.traktbroker import Broker, Token, TraktEnv, S_CLIENT
        env = TraktEnv(self.kodi)
        if handoff.get("client_id") and not (env.get_own(S_CLIENT) or "").strip():
            env.set_own_all({S_CLIENT: handoff["client_id"]})
        b = Broker(env)
        tok = Token.from_response(handoff["token"], env.now(), handoff["token"].get("username", ""))
        if tok is None or not b.configured():
            return False
        b.save(tok)
        b.push(tok)
        return True

    def addon_installed(self, addon_id):
        import xbmc
        return bool(xbmc.getCondVisibility("System.HasAddon(%s)" % addon_id))

    def addon_get(self, addon_id, sid):
        import xbmcaddon
        try:
            return xbmcaddon.Addon(addon_id).getSetting(sid)
        except RuntimeError:
            return None

    def addon_set(self, addon_id, sid, value):
        import xbmcaddon
        xbmcaddon.Addon(addon_id).setSetting(sid, value)

    def sync_umbrella(self):
        from resources.lib.umbrellafile import UmbrellaFile, UmbrellaFileEnv
        UmbrellaFile(UmbrellaFileEnv(self.kodi), lambda: True).sync_now("household accounts")

    def fen_set(self, values):
        """Fen keeps its settings in databases/settings.db; write only rows that differ. Fen reads them at its next
        start in this profile. Returns rows changed; 0 when Fen has not made its database yet (next check retries)."""
        import sqlite3
        path = self.kodi.translate(FEN_DB)
        if not os.path.isfile(path):
            return 0
        con = sqlite3.connect(path, timeout=5)
        changed = 0
        try:
            for k, v in values.items():
                row = con.execute("select setting_value from settings where setting_id=?", (k,)).fetchone()
                if row is not None and row[0] == v:
                    continue
                con.execute("insert into settings (setting_id, setting_type, setting_default, setting_value) values "
                            "(?, 'string', 'empty_setting', ?) on conflict(setting_id) do update set "
                            "setting_value=excluded.setting_value", (k, v))
                changed += 1
            con.commit()
        finally:
            con.close()
        return changed
