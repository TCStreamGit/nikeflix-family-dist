# -*- coding: utf-8 -*-
"""NikeFlix 4.1.5 Sound & Picture (approved preview v21, Tanner 2026-11-21): "maybe have a homepod mode or device
specific settings if it detects a device for like audio and video. Like sometimes kodi doesnt sound that good when I
am using my homepods and that and I have to restart the device sometimes".

Speakers (service.nikeflix setting sound.speakers, per profile like Kodi's own audio settings) writes a set of Kodi
audio settings. List choices are named by label and looked up in Kodi's own option list at run time:
  - HomePod (the live Apple TV check with a HomePod stereo pair, 2026-11-21): passthrough off, stereo upmix off,
    stream noise off, keep the output open Always, resampling High, stereo (or Surround), the output Fixed at 48 kHz.
    This keeps the HomePods connected. It does not cure the crackling of a HomePod STEREO PAIR: the live check heard it
    with every setting and none on a single HomePod. Kodi's tvOS sink plays through Apple's low-latency AudioUnit
    path, and the second pod of a pair gets its channel relayed over Wi-Fi; a single HomePod or a stronger Wi-Fi link
    avoids it (Settings says so under the rows);
  - TV speakers: stereo, no passthrough;
  - Soundbar or receiver: passthrough on, with Dolby Digital, Dolby Digital Plus, DTS, TrueHD and DTS-HD;
  - Automatic: on Apple TV, what the Apple TV plays through. Kodi 21's tvOS sink (AESinkDARWINTVOS.mm) reads the
    AVAudioSession route and logs it at INFO each time it opens ("audio route = AirPlay" / "HDMIOutput" / ...,
    with "maximumOutputNumberOfChannels N"), but offers one device, "Default", and no setting or infolabel
    carries the route. So the route is read from Kodi's own log: AirPlay -> HomePod; HDMI, Bluetooth or headphones ->
    TV speakers; no route line -> HomePod. On HDMI, Automatic only sets the channel count the route reports (2, 5.1
    or 7.1) and leaves passthrough as it is, so a receiver on HDMI keeps its surround (review). Elsewhere Automatic is
    TV speakers once chosen, and the device's own audio settings are left alone until someone chooses Speakers here.

Fix the sound reopens Kodi's audio output without a restart: Kodi's audio engine reopens its sink whenever
audiooutput.audiodevice changes (ActiveAE RECONFIGURE -> NeedReconfigureSink -> OpenSink), and a device it cannot
open falls back to the first device it knows. Pointing the setting at a placeholder and straight back reopens the
output twice, the second time on the device it was using; on Apple TV each open reads the route again. It also runs
by itself on wake (Kodi's System.OnWake, sent on Apple TV when Kodi returns to the foreground, or the end of Kodi's
screensaver after at least a minute) when Speakers is HomePod, or Automatic on Apple TV, never while anything plays.
A reopen that was cut off and left the placeholder behind is undone by resetting the device setting to Kodi's
default."""
import re

OWN = "service.nikeflix"
SPEAKERS = ("auto", "homepod", "tv", "receiver")
SURROUND = ("auto", "2.0", "5.1", "7.1")
CHANNELS = {"2.0": 1, "5.1": 8, "7.1": 10}          # AE_CH_LAYOUT_2_0 / _5_1 / _7_1 (Kodi's audiooutput.channels)
ALWAYS = 153722867        # audiooutput.streamsilence "Always": Kodi 21 writes EndTime<minutes>::Max().count()
KODI_SILENCE_DEFAULT = 1  # Kodi's default: the output closes after a minute of silence (0 is "Off": at once)
QUALITY_HIGH = 50         # audiooutput.processquality AE_QUALITY_HIGH (Kodi's default is 30, medium)
PASSTHROUGH = ("audiooutput.ac3passthrough", "audiooutput.eac3passthrough", "audiooutput.dtspassthrough",
               "audiooutput.truehdpassthrough", "audiooutput.dtshdpassthrough")
DEVICE = "audiooutput.audiodevice"
PLACEHOLDER = "nikeflix-reopen"
NAMES = {"homepod": "HomePod", "tv": "TV speakers", "receiver": "Soundbar or receiver"}
WAKE_GAP_S = 60.0         # at most one automatic reopen a minute
WAKE_KEEP_S = 600.0       # a wake seen during playback waits this long for the player to stop
SCREENSAVER_MIN_S = 60.0  # a screensaver counts as a wake only after this long (AirPlay drops after about a minute)
ROUTE_CHANNELS = {2: "2.0", 6: "5.1", 8: "7.1"}

ROUTE_RE = re.compile(r"audio route = (\S+)")
MAXCH_RE = re.compile(r"maximumOutputNumberOfChannels (\d+)")


def route_from_log(text):
    """(route, max channels) from the last lines Kodi's tvOS sink logged when it opened, or ("", 0)."""
    routes = ROUTE_RE.findall(text or "")
    chans = MAXCH_RE.findall(text or "")
    route = routes[-1] if routes else ""
    return ("" if route == "NONE" else route), (int(chans[-1]) if chans else 0)


def resolve(speakers, tvos, route=""):
    """The speaker profile in use: Automatic follows the Apple TV's route (HomePod when it is not known), elsewhere
    it is TV speakers."""
    if speakers in NAMES:
        return speakers
    if not tvos:
        return "tv"
    r = (route or "").lower()
    if "airplay" in r:
        return "homepod"
    if r.startswith("hdmi") or "bluetooth" in r or "headphone" in r or "speaker" in r:
        return "tv"
    return "homepod"


def channel_label(profile, surround, maxch=0):
    """The audiooutput.channels choice, by its label: Surround when set; HomePods stereo (the live Apple TV check with a
    HomePod stereo pair, 2026-11-21); TV speakers stereo; a receiver 5.1, or 7.1 on an 8-channel route."""
    if surround in CHANNELS:
        return surround
    if profile in ("homepod", "tv"):
        return "2.0"
    return "7.1" if maxch > 6 else "5.1"


def channels(profile, surround, maxch=0):
    return CHANNELS[channel_label(profile, surround, maxch)]


class Label(object):
    """A list setting's choice named by its label; apply() looks the value up in Kodi's own option list."""

    def __init__(self, label):
        self.label = label

    def __eq__(self, other):
        return isinstance(other, Label) and other.label == self.label

    def __repr__(self):
        return "Label(%r)" % self.label


# the values when Kodi's option list cannot be read or does not name the label (read live on Kodi 21.3, tvOS 26.6.1)
OPTION_FALLBACK = {("audiooutput.config", "Fixed"): 1, ("audiooutput.streamsilence", "Always"): ALWAYS,
                   ("audiooutput.processquality", "High"): QUALITY_HIGH, ("audiooutput.channels", "2.0"): 1,
                   ("audiooutput.channels", "5.1"): 8, ("audiooutput.channels", "7.1"): 10}


def option_value(options, sid, label):
    for o in (options or {}).get(sid) or []:
        if str(o.get("label", "")).strip().lower() == label.lower():
            return o.get("value")
    return OPTION_FALLBACK[(sid, label)]


def values(profile, surround="auto", maxch=0):
    """The Kodi audio settings a speaker profile writes, in the order they must be written: passthrough before Fixed
    (Kodi refuses a passthrough write once the output is Fixed) and the sample rate after it (the setting only exists
    while the output is Fixed)."""
    ch = ("audiooutput.channels", Label(channel_label(profile, surround, maxch)))
    if profile == "homepod":
        # the live Apple TV check (HomePod stereo pair): a fixed 48 kHz PCM output, kept open
        return [("audiooutput.passthrough", False), ("audiooutput.stereoupmix", False), ("audiooutput.streamnoise", False),
                ("audiooutput.streamsilence", Label("Always")), ("audiooutput.processquality", Label("High")), ch,
                ("audiooutput.config", Label("Fixed")), ("audiooutput.samplerate", 48000)]
    if profile == "tv":
        return [("audiooutput.passthrough", False), ch]
    return [("audiooutput.passthrough", True)] + [(sid, True) for sid in PASSTHROUGH] + [ch]


def choice(env, sid, allowed):
    v = str(env.addon_get(OWN, sid) or "").strip().lower()
    return v if v in allowed else "auto"


def route_values(surround, maxch):
    """Automatic on an Apple TV route that is not AirPlay: only the channel count the route reports (or Surround)."""
    if surround in CHANNELS:
        return [("audiooutput.channels", Label(surround))]
    near = min(ROUTE_CHANNELS, key=lambda n: abs(n - maxch)) if maxch else 2
    return [("audiooutput.channels", Label(ROUTE_CHANNELS[near]))]


def _options(env):
    try:
        return env.kodi_options() if hasattr(env, "kodi_options") else {}
    except Exception:
        return {}


def _is_fixed(env, options):
    return str(env.kodi_get("audiooutput.config")) == str(option_value(options, "audiooutput.config", "Fixed"))


def apply(env, tvos, route_reader):
    """Write the chosen Speakers profile (with Surround) into Kodi and remember which one. Returns (profile, written).
    A setting this Kodi does not have (tvOS has no E-AC3, DTS or TrueHD passthrough) is skipped."""
    speakers = choice(env, "sound.speakers", SPEAKERS)
    surround = choice(env, "sound.surround", SURROUND)
    route, maxch = route_reader() if tvos else ("", 0)
    profile = resolve(speakers, tvos, route)
    if speakers == "auto" and tvos and profile == "tv":
        want = route_values(surround, maxch)
    else:
        want = values(profile, surround, maxch)
    options = _options(env)
    written = {}
    if profile != "homepod" and _is_fixed(env, options) and (
            profile == "receiver" or env.addon_get(OWN, "sound.applied") == "homepod"):
        # HomePod fixed the output; passthrough needs it unfixed. Kodi's own default comes back.
        env.kodi_reset("audiooutput.config")
        written["audiooutput.config"] = "default"
    for sid, v in want:
        if isinstance(v, Label):
            v = option_value(options, sid, v.label)
        if env.kodi_get(sid) is None:
            continue
        env.kodi_set(sid, v)
        written[sid] = v
    env.addon_set(OWN, "sound.applied", profile)
    return profile, written


def apply_surround(env, tvos, route_reader):
    """Surround changed: only the channel count moves."""
    speakers = choice(env, "sound.speakers", SPEAKERS)
    surround = choice(env, "sound.surround", SURROUND)
    route, maxch = route_reader() if tvos else ("", 0)
    profile = resolve(speakers, tvos, route)
    if speakers == "auto" and tvos and profile == "tv":
        label = route_values(surround, maxch)[0][1].label
    else:
        label = channel_label(profile, surround, maxch)
    n = option_value(_options(env), "audiooutput.channels", label)
    env.kodi_set("audiooutput.channels", n)
    return n


def reopen(get, put, wait, reset=None):
    """Reopen Kodi's audio output: the device setting to a placeholder and back. True when the device setting reads
    back as it was. A placeholder left by a reopen that was cut off is reset to Kodi's default device instead."""
    device = get(DEVICE)
    if not device:
        return False
    if PLACEHOLDER in device:
        if reset is not None:
            reset(DEVICE)
        return False
    driver = device.split(":", 1)[0] if ":" in device else ""
    aborted = False
    try:
        put(DEVICE, (driver + ":" if driver else "") + PLACEHOLDER)
        aborted = bool(wait(1.0))    # the engine reconfigures on its own thread
    finally:
        put(DEVICE, device)          # always, even when Kodi is stopping the script
    if aborted:
        return False
    wait(1.0)
    return get(DEVICE) == device


def wake_fix_wanted(env, tvos):
    speakers = choice(env, "sound.speakers", SPEAKERS)
    return speakers == "homepod" or (speakers == "auto" and tvos)


class SoundCare(object):
    """service.nikeflix poller: Automatic on Apple TV applies its profile when the route differs from the one last
    applied (first start included), and a wake reopens the output (Fix the sound) when the speakers want it."""

    def __init__(self, env, ready):
        self.env, self.ready = env, ready
        self.started = False
        self.wake_at = None
        self.last_fix = None

    def poll(self):
        env = self.env
        hit = env.take_wake()
        if hit:
            self.wake_at = env.now()
        if not self.ready():
            return None
        if not self.started:
            self.started = True
            self.auto()
        if self.wake_at is None:
            return None
        now = env.now()
        if now - self.wake_at > WAKE_KEEP_S:
            self.wake_at = None
            return None
        if env.playing():
            return None                  # never during playback: waits for the player to stop
        self.wake_at = None
        if not wake_fix_wanted(env, env.tvos()):
            return None
        if self.last_fix is not None and now - self.last_fix < WAKE_GAP_S:
            return None
        self.last_fix = now
        ok = reopen(env.kodi_get, env.kodi_set, env.wait, getattr(env, "kodi_reset", None))
        env.log("sound: audio output reopened after wake (%s)" % ("ok" if ok else "device not restored"))
        self.auto()
        return "reopened"

    def auto(self):
        env = self.env
        tvos = env.tvos()
        if not tvos or choice(env, "sound.speakers", SPEAKERS) != "auto":
            return None
        seen = env.route()
        route = seen[0]
        want = resolve("auto", True, route)
        if env.addon_get(OWN, "sound.applied") == want:
            return None
        profile, _written = apply(env, True, lambda: seen)
        env.log("sound: Automatic uses the %s settings (route %s)" % (NAMES[profile], route or "not logged"))
        return profile


class SoundEnv(object):
    """Kodi side of SoundCare (the logic above is pure and unit-tested with a fake)."""

    def __init__(self, kodi):
        import xbmc
        self.kodi, self._xbmc = kodi, xbmc
        self._hits = []
        hits = self._hits
        started = [None]
        clock = kodi.now

        class _Wake(xbmc.Monitor):
            def onNotification(self, sender, method, data):
                if method == "System.OnWake":
                    hits.append("wake")

            def onScreensaverActivated(self):
                started[0] = clock()

            def onScreensaverDeactivated(self):
                if started[0] is not None and clock() - started[0] >= SCREENSAVER_MIN_S:
                    hits.append("screensaver")
                started[0] = None

        self._monitor = _Wake()

    def take_wake(self):
        if not self._hits:
            return None
        what = self._hits[-1]
        del self._hits[:]
        return what

    def _rpc(self, method, params):
        import json
        out = json.loads(self._xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": method, "params": params})))
        return out.get("result")

    def kodi_get(self, sid):
        return (self._rpc("Settings.GetSettingValue", {"setting": sid}) or {}).get("value")

    def kodi_set(self, sid, value):
        self._rpc("Settings.SetSettingValue", {"setting": sid, "value": value})

    def kodi_reset(self, sid):
        self._rpc("Settings.ResetSettingValue", {"setting": sid})

    def kodi_options(self):
        return audio_options(self._rpc)

    def addon_get(self, addon_id, sid):
        import xbmcaddon
        try:
            return xbmcaddon.Addon(addon_id).getSetting(sid)
        except RuntimeError:
            return ""

    def addon_set(self, addon_id, sid, value):
        import xbmcaddon
        try:
            xbmcaddon.Addon(addon_id).setSetting(sid, str(value))
        except RuntimeError:
            pass

    def tvos(self):
        return self.kodi.cond("System.Platform.TVOS")

    def playing(self):
        return self.kodi.cond("Player.HasMedia")

    def route(self):
        return read_route(self.kodi.translate("special://logpath/kodi.log"))

    def now(self):
        return self.kodi.now()

    def wait(self, seconds):
        return self.kodi.wait(seconds)

    def log(self, message):
        self.kodi.log(message)


def audio_options(rpc):
    """{setting id: [{"label", "value"}]} for Kodi's audio settings (Settings > System > Audio, expert level)."""
    got = rpc("Settings.GetSettings", {"level": "expert", "filter": {"section": "system", "category": "audio"}}) or {}
    return dict((x.get("id"), x.get("options")) for x in got.get("settings", []) if x.get("options"))


def read_route(path, limit=4 * 1024 * 1024):
    """The last route Kodi's tvOS sink logged (reads at most the last `limit` bytes of the log)."""
    try:
        with open(path, "rb") as fh:
            fh.seek(0, 2)
            size = fh.tell()
            fh.seek(max(0, size - limit))
            text = fh.read().decode("utf-8", "replace")
    except OSError:
        return "", 0
    return route_from_log(text)
