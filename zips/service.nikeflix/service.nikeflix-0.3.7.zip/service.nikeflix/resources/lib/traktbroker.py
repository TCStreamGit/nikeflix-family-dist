# -*- coding: utf-8 -*-
"""Trakt Hub (T30/T31/T33): one Trakt sign-in per profile, shared with every Trakt add-on in the build.

Tanner: "I want to have just one Trakt add-on that connects all the Trakt add-ons together ... I log into only one,
and then they're all logged in. And I want it to retain the login." (U1, U5: one login per profile, never shared.)

How it works
  * The NikeFlix Trakt app is a PUBLIC client (Trakt "client id" only, no client secret; the device-code flow and the
    refresh grant are sent without a secret). The client id is a per-device slot (`trakt.client_id`, filled on the
    device, never in Git).
  * `Trakt Account` (power menu, Skin NikeFlix) opens this broker: Connect (Trakt device code: "go to
    trakt.tv/activate and enter XXXX"), status, Disconnect. The token is stored in THIS profile's service.nikeflix
    settings (Kodi keeps add-on settings per profile), so a profile's login is never visible to another profile.
  * The broker pushes the profile's token into the add-ons that use Trakt - TMDb Helper (`trakt_token` + its window
    properties) and Umbrella (its `trakt.*` settings, custom client = NikeFlix app) - and refreshes it before it
    expires, pushing again. The add-ons never refresh or ask for a login of their own (their managed patches route
    sign-in to this broker and ask the broker to refresh), so there is no second login prompt and no re-auth nag.
  * At a profile end and start the shared Kodi window properties the add-ons cache a token in (`TraktUserToken`,
    `TraktIsAuth`, `umbrella.trakt.access_token`, Umbrella's `umbrella_settings` cache) are cleared, so no profile
    can read another profile's token (isolation).

Decisions only live here; the Kodi side (settings, Home properties, HTTP, dialogs) is `TraktEnv`, so the logic is
unit-tested with fakes (tests/test_trakt_broker.py). Nothing here logs or toasts a token or a code.
"""
import json

API = "https://api.trakt.tv"
REDIRECT_URI = "urn:ietf:wg:oauth:2.0:oob"
TMDBH = "plugin.video.themoviedb.helper"
UMBRELLA = "plugin.video.umbrella"

# own settings (per profile)
S_CLIENT = "trakt.client_id"
S_ACCESS, S_REFRESH, S_EXPIRES, S_CREATED, S_EXPIRES_IN = ("trakt.access_token", "trakt.refresh_token",
                                                            "trakt.expires_at", "trakt.created_at", "trakt.expires_in")
S_SCOPE, S_USER, S_NEEDS_SIGNIN = "trakt.scope", "trakt.username", "trakt.needs_signin"
STORE_KEYS = (S_ACCESS, S_REFRESH, S_EXPIRES, S_CREATED, S_EXPIRES_IN, S_SCOPE, S_USER, S_NEEDS_SIGNIN)

# Home window properties (shared by every profile in one Kodi process; cleared at profile end)
P_BROKER = "nikeflix.trakt.broker"              # "true" when a client id is configured (consumer patches check it)
P_CLIENT = "nikeflix.trakt.client_id"
P_CONNECTED = "nikeflix.trakt.connected"        # "true" while this profile holds a token
P_USER = "nikeflix.trakt.username"
P_REFRESH_REQUESTED = "nikeflix.trakt.refresh_requested"   # set by a consumer that got a 401
P_STATUS = "nikeflix.trakt.status"              # not_configured | signed_out | connected | needs_signin
TMDBH_PROPS = ("TraktUserToken", "TraktIsAuth", "TraktRefreshAttempts", "TraktRefreshTimeStamp", "TraktAttemptedLogin")
UMBRELLA_TOKEN_PROP = "umbrella.trakt.access_token"
UMBRELLA_CACHE_PROP = "umbrella_settings"       # Umbrella's settings cache (holds its trakt.* values)
UMBRELLA_UPDATE_PROP = "umbrella.updateSettings"  # Umbrella brackets its own writes with this ('false' .. 'true')
SHARED_PROPS = TMDBH_PROPS + (UMBRELLA_TOKEN_PROP, UMBRELLA_CACHE_PROP, P_CONNECTED, P_USER, P_STATUS,
                              P_REFRESH_REQUESTED)

REFRESH_AHEAD = 6 * 3600.0      # refresh when less than this is left (Trakt tokens last 24 h or 90 days)
CHECK_EVERY = 60.0              # service tick budget
MIN_REFRESH_GAP = 15 * 60.0     # never refresh more often than this (a consumer's request included)
RETRY_AFTER_NETWORK = 600.0     # a network failure: try again later
RETRY_AFTER_REJECT = 6 * 3600.0  # the refresh token was rejected for good: wait for the user (Trakt Account)
REJECTIONS_BEFORE_SIGNOUT = 2   # an ambiguous rejection (no invalid_grant body) is believed only the second time
CONSUMER_REPAIR_EVERY = 60.0
REPAIR_GAP_MAX = 3600.0         # a repair that does not stick backs off (x4) up to once an hour (4.1.4: the tvOS loop)
MIN_POLL_INTERVAL = 5
DEVICE_POLL_ERRORS_MAX = 10     # transient errors tolerated while the user enters the code
PLACEHOLDER_USER = "NikeFlix"   # Umbrella treats an empty user name as "not signed in"

STATUS_NOT_CONFIGURED, STATUS_SIGNED_OUT, STATUS_CONNECTED, STATUS_NEEDS_SIGNIN = (
    "not_configured", "signed_out", "connected", "needs_signin")


def _f(value, default=0.0):
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


class Token(object):
    """A Trakt token as the add-ons expect it."""

    def __init__(self, access, refresh, created_at, expires_in, scope="public", username=""):
        self.access, self.refresh = access or "", refresh or ""
        self.created_at, self.expires_in = int(_f(created_at)), int(_f(expires_in))
        self.scope, self.username = scope or "public", username or ""

    @property
    def expires_at(self):
        return float(self.created_at + self.expires_in)

    @classmethod
    def from_response(cls, data, now, username=""):
        if not isinstance(data, dict) or not data.get("access_token"):
            return None
        return cls(data["access_token"], data.get("refresh_token", ""), data.get("created_at") or int(now),
                   data.get("expires_in") or 0, data.get("scope") or "public", username)

    @classmethod
    def from_store(cls, own):
        if not own.get(S_ACCESS):
            return None
        return cls(own.get(S_ACCESS), own.get(S_REFRESH), own.get(S_CREATED), own.get(S_EXPIRES_IN),
                   own.get(S_SCOPE), own.get(S_USER))

    def store_values(self):
        return {S_ACCESS: self.access, S_REFRESH: self.refresh, S_EXPIRES: "%d" % int(self.expires_at),
                S_CREATED: "%d" % self.created_at, S_EXPIRES_IN: "%d" % self.expires_in, S_SCOPE: self.scope,
                S_USER: self.username, S_NEEDS_SIGNIN: "false"}

    def tmdbh_json(self):
        """TMDb Helper `trakt_token`: the device-token response as it stores it (`data_dumps`)."""
        return json.dumps({"access_token": self.access, "token_type": "bearer", "expires_in": self.expires_in,
                           "refresh_token": self.refresh, "scope": self.scope, "created_at": self.created_at},
                          separators=(",", ":"), sort_keys=True)

    def umbrella_values(self, client_id):
        return {"traktuserkey.customenabled": "true", "trakt.clientid": client_id, "trakt.clientsecret": "",
                "trakt.user.token": self.access, "trakt.refreshtoken": self.refresh,
                "trakt.token.expires": repr(self.expires_at), "trakt.isauthed": "true",
                "trakt.authed.clientid": client_id, "trakt.user.name": self.username or PLACEHOLDER_USER}


def umbrella_cleared(client_id):
    return {"traktuserkey.customenabled": "true", "trakt.clientid": client_id, "trakt.clientsecret": "",
            "trakt.user.token": "", "trakt.refreshtoken": "", "trakt.token.expires": "", "trakt.isauthed": "false",
            "trakt.authed.clientid": "", "trakt.user.name": ""}


class Broker(object):
    """Store, consumers and the Trakt calls. `env` is TraktEnv (or a fake)."""

    def __init__(self, env):
        self.env = env

    # ---- configuration and store ---------------------------------------------------------------------------------
    def client_id(self):
        return (self.env.get_own(S_CLIENT) or "").strip()

    def configured(self):
        return bool(self.client_id())

    def token(self):
        return Token.from_store(self.env.get_own_all(STORE_KEYS))

    def needs_signin(self):
        return (self.env.get_own(S_NEEDS_SIGNIN) or "").lower() == "true"

    def status(self):
        if not self.configured():
            return STATUS_NOT_CONFIGURED
        if self.token() is None:
            return STATUS_NEEDS_SIGNIN if self.needs_signin() else STATUS_SIGNED_OUT
        return STATUS_NEEDS_SIGNIN if self.needs_signin() else STATUS_CONNECTED

    def publish_props(self):
        """Home properties the consumer patches and the skin read. Never a token."""
        cid = self.client_id()
        if cid:
            self.env.set_prop(P_BROKER, "true")
            self.env.set_prop(P_CLIENT, cid)
        else:
            self.env.clear_prop(P_BROKER)
            self.env.clear_prop(P_CLIENT)
        tok = self.token()
        status = self.status()
        self.env.set_prop(P_STATUS, status)
        if tok is not None and status == STATUS_CONNECTED:
            self.env.set_prop(P_CONNECTED, "true")
            self.env.set_prop(P_USER, tok.username)
        else:
            self.env.clear_prop(P_CONNECTED)
            self.env.clear_prop(P_USER)

    def clear_shared_props(self):
        """Profile end/start: no token cached in a shared window property survives into another profile."""
        for p in SHARED_PROPS:
            self.env.clear_prop(p)

    def save(self, token):
        self.env.set_own_all(token.store_values())

    def forget(self, needs_signin=False):
        values = {k: "" for k in STORE_KEYS}
        values[S_NEEDS_SIGNIN] = "true" if needs_signin else "false"
        self.env.set_own_all(values)

    # ---- consumers ----------------------------------------------------------------------------------------------
    def _write_umbrella(self, values):
        """Umbrella's service rebuilds its settings cache on a settings change only while `umbrella.updateSettings`
        is not 'false': bracket the writes the way Umbrella itself does (one rebuild, after the last key)."""
        self.env.set_prop(UMBRELLA_UPDATE_PROP, "false")
        try:
            items = list(values.items())
            self.env.set_addon_all(UMBRELLA, dict(items[:-1]))
        finally:
            self.env.set_prop(UMBRELLA_UPDATE_PROP, "true")
        self.env.set_addon_all(UMBRELLA, dict(items[-1:]))
        # Umbrella reads its settings file from disk and caches it: bring both in step with Kodi now (umbrellafile)
        sync = getattr(self.env, "sync_umbrella", None)
        if sync is not None:
            sync()

    def push(self, token):
        """Give the profile's token to TMDb Helper and Umbrella (settings + the window properties they cache)."""
        cid = self.client_id()
        done = []
        if self.env.addon_present(TMDBH):
            self.env.set_addon(TMDBH, "trakt_token", token.tmdbh_json())
            self.env.set_prop("TraktUserToken", token.tmdbh_json())
            self.env.set_prop("TraktIsAuth", repr(token.expires_at))
            self.env.set_prop("TraktRefreshAttempts", "0")
            self.env.clear_prop("TraktRefreshTimeStamp")
            self.env.clear_prop("TraktAttemptedLogin")
            done.append(TMDBH)
        if self.env.addon_present(UMBRELLA):
            self._write_umbrella(token.umbrella_values(cid))
            self.env.set_prop(UMBRELLA_TOKEN_PROP, token.access)
            done.append(UMBRELLA)
        self.env.clear_prop(P_REFRESH_REQUESTED)
        self.publish_props()
        self.env.log("trakt: token pushed to %s (expires in %d min)" % (
            ", ".join(done) or "no consumer", max(0, int((token.expires_at - self.env.now()) / 60))))
        return done

    def clear_consumers(self):
        cid = self.client_id()
        if self.env.addon_present(TMDBH):
            self.env.set_addon(TMDBH, "trakt_token", "")
        if self.env.addon_present(UMBRELLA):
            self._write_umbrella(umbrella_cleared(cid))
        for p in TMDBH_PROPS + (UMBRELLA_TOKEN_PROP,):
            self.env.clear_prop(p)
        self.publish_props()

    def consumers_hold(self, token):
        """True when both installed consumers hold exactly this token: on disk and, for Umbrella, in the settings
        cache its service rebuilt (a stale cache means Umbrella still uses the old token)."""
        if self.env.addon_present(TMDBH):
            raw = self.env.get_addon(TMDBH, "trakt_token") or ""
            try:
                if (json.loads(raw) or {}).get("access_token") != token.access:
                    return False
            except ValueError:
                return False
        if self.env.addon_present(UMBRELLA):
            if self.env.get_addon(UMBRELLA, "trakt.user.token") != token.access:
                return False
            if self.env.get_addon(UMBRELLA, "trakt.isauthed") != "true":
                return False
            cache = self.env.umbrella_cache(("trakt.user.token",))
            if cache is not None and cache.get("trakt.user.token") != token.access:
                return False
        return True

    # ---- Trakt calls (no client secret: public client) ------------------------------------------------------------
    def device_code(self):
        status, data = self.env.post(API + "/oauth/device/code", {"client_id": self.client_id()})
        if status != 200 or not isinstance(data, dict) or not data.get("device_code"):
            return None, "trakt_device_code_%s" % status
        return data, None

    def poll_device_token(self, device_code):
        """-> ("ok", token) | ("pending", None) | ("slow_down", None) | ("transient", None) |
        ("expired"|"denied"|"invalid"|"used"|"error", None)"""
        status, data = self.env.post(API + "/oauth/device/token", {"client_id": self.client_id(), "code": device_code})
        if status == 200:
            tok = Token.from_response(data, self.env.now())
            return ("ok", tok) if tok else ("error", None)
        if status == 0 or status >= 500:
            return "transient", None
        return ({400: "pending", 429: "slow_down", 410: "expired", 418: "denied", 404: "invalid", 409: "used"}
                .get(status, "error"), None)

    def refresh(self, token):
        """-> ("ok", token) | ("rejected", None) (Trakt says the refresh token is no good: invalid_grant) |
        ("ambiguous", None) (4xx without that verdict: a wrong client id, a block, a one-off) |
        ("network", None) (try again later)."""
        status, data = self.env.post(API + "/oauth/token", {
            "client_id": self.client_id(), "refresh_token": token.refresh, "redirect_uri": REDIRECT_URI,
            "grant_type": "refresh_token"})
        if status == 200:
            new = Token.from_response(data, self.env.now(), token.username)
            return ("ok", new) if new else ("ambiguous", None)
        if status in (400, 401, 403):
            err = (data or {}).get("error") if isinstance(data, dict) else ""
            return ("rejected" if err == "invalid_grant" else "ambiguous"), None
        return "network", None

    def revoke(self, token):
        self.env.post(API + "/oauth/revoke", {"client_id": self.client_id(), "token": token.access})

    def username(self, token):
        status, data = self.env.get(API + "/users/settings", token.access)
        if status == 200 and isinstance(data, dict):
            user = data.get("user") or {}
            return user.get("username") or ""
        return ""

    # ---- flows ---------------------------------------------------------------------------------------------------
    def connect(self, ui):
        """Device-code sign-in. `ui` shows the code and reports cancel; returns a status string."""
        if not self.configured():
            return STATUS_NOT_CONFIGURED
        data, err = self.device_code()
        if err:
            self.env.log("trakt: connect failed: %s" % err, "warning")
            return "error"
        interval = max(MIN_POLL_INTERVAL, int(_f(data.get("interval"), MIN_POLL_INTERVAL)))
        lifetime = max(60.0, _f(data.get("expires_in"), 600.0))
        deadline = self.env.now() + lifetime
        transient = 0
        ui.show_code(data.get("verification_url") or "https://trakt.tv/activate", data.get("user_code") or "")
        self.env.log("trakt: device code shown; waiting for the user to enter it (poll every %d s)" % interval)
        try:
            while True:
                if ui.cancelled() or self.env.aborted():
                    self.env.log("trakt: connect ended: cancelled")
                    return "cancelled"
                if self.env.now() >= deadline:
                    self.env.log("trakt: connect ended: expired", "warning")
                    return "expired"
                ui.progress(min(99, int(100 * (1 - (deadline - self.env.now()) / lifetime))))
                state, tok = self.poll_device_token(data["device_code"])
                if state == "ok":
                    tok.username = self.username(tok) or PLACEHOLDER_USER
                    self.save(tok)
                    self.push(tok)
                    self.env.log("trakt: connected (device flow)")
                    return STATUS_CONNECTED
                if state == "transient":
                    transient += 1
                    if transient > DEVICE_POLL_ERRORS_MAX:
                        self.env.log("trakt: connect ended: Trakt unreachable", "warning")
                        return "error"
                elif state in ("expired", "denied", "invalid", "used", "error"):
                    self.env.log("trakt: connect ended: %s" % state, "warning")
                    return state
                elif state == "slow_down":
                    interval += 1
                self.env.sleep(interval)
        finally:
            ui.close()

    def disconnect(self):
        tok = self.token()
        if tok is not None:
            try:
                self.revoke(tok)
            except Exception as exc:   # revoking is best effort; the local sign-out always happens
                self.env.log("trakt: revoke failed: %s" % type(exc).__name__, "warning")
        self.forget(needs_signin=False)
        self.clear_consumers()
        self.env.log("trakt: disconnected")
        return STATUS_SIGNED_OUT


class TraktSync(object):
    """Service-loop part: start-of-profile publish and push, refresh before expiry, honour a consumer's refresh
    request, keep the consumers holding the token. Bounded: one refresh per MIN_REFRESH_GAP, backoffs on failure."""

    def __init__(self, broker):
        self.b, self.env = broker, broker.env
        self.next_check = 0.0
        self.retry_not_before = 0.0
        self.backoff_refresh = None     # the refresh token the backoff was set for (a new sign-in clears it)
        self.rejections = 0
        self.last_repair = 0.0
        self.repair_gap = CONSUMER_REPAIR_EVERY
        self.started = False

    def begin_profile(self):
        """Profile start: clear every shared token property, then publish THIS profile's state."""
        self.b.clear_shared_props()
        self.b.publish_props()
        tok = self.b.token()
        if tok is not None and not self.b.needs_signin():
            self.b.push(tok)
        self.started = True

    def end_profile(self):
        self.b.clear_shared_props()

    def _in_backoff(self, tok, now):
        if self.backoff_refresh is not None and self.backoff_refresh != tok.refresh:
            self.backoff_refresh, self.retry_not_before, self.rejections = None, 0.0, 0   # signed in again
        return now < self.retry_not_before

    def poll(self):
        now = self.env.now()
        requested = (self.env.get_prop(P_REFRESH_REQUESTED) or "") == "true"
        if now < self.next_check and not requested:
            return
        self.next_check = now + CHECK_EVERY
        if not self.b.configured():
            self.env.clear_prop(P_REFRESH_REQUESTED)
            self.b.publish_props()
            return
        tok = self.b.token()
        if tok is None or self.b.needs_signin():
            self.env.clear_prop(P_REFRESH_REQUESTED)
            return
        backoff = self._in_backoff(tok, now)
        if requested and backoff:
            self.env.clear_prop(P_REFRESH_REQUESTED)   # served when the backoff ends
        if (requested or tok.expires_at - now < REFRESH_AHEAD) and not backoff:
            self._refresh(tok, requested)
            return
        expired = tok.expires_at <= now
        if not backoff and not expired and now - self.last_repair >= self.repair_gap:
            if self.b.consumers_hold(tok):
                self.repair_gap = CONSUMER_REPAIR_EVERY
            else:
                self.last_repair = now
                nxt = min(REPAIR_GAP_MAX, self.repair_gap * 4)
                self.env.log("trakt: a consumer lost the token; pushing again (next check in %d min)" % int(nxt / 60))
                self.b.push(tok)
                self.repair_gap = nxt

    def _refresh(self, tok, requested):
        state, new = self.b.refresh(tok)
        now = self.env.now()
        self.env.clear_prop(P_REFRESH_REQUESTED)
        if state == "ok":
            if tok.username and tok.username != PLACEHOLDER_USER:
                new.username = tok.username
            else:
                new.username = self.b.username(new) or PLACEHOLDER_USER
            self.b.save(new)
            self.b.push(new)
            self.rejections = 0
            self.backoff_refresh, self.retry_not_before = new.refresh, now + MIN_REFRESH_GAP
            self.env.log("trakt: token refreshed%s" % (" (a consumer asked)" if requested else ""))
            return
        if state == "network":
            self.backoff_refresh, self.retry_not_before = tok.refresh, now + RETRY_AFTER_NETWORK
            self.env.log("trakt: refresh failed (network); retrying later", "warning")
            if tok.expires_at <= now:
                self.b.clear_consumers()   # an expired token stays nowhere
            return
        self.rejections += 1
        if state == "ambiguous" and self.rejections < REJECTIONS_BEFORE_SIGNOUT:
            self.backoff_refresh, self.retry_not_before = tok.refresh, now + RETRY_AFTER_NETWORK
            self.env.log("trakt: refresh refused without a verdict; one more try later before signing out", "warning")
            return
        # rejected: this refresh token is no good; the user signs in again from Trakt Account (no nag, one log line)
        self.backoff_refresh, self.retry_not_before = tok.refresh, now + RETRY_AFTER_REJECT
        self.b.forget(needs_signin=True)
        self.b.clear_consumers()
        self.env.log("trakt: Trakt rejected the refresh token; sign in again from Trakt Account", "warning")
        self.env.notify_signin_needed()


class TraktEnv(object):
    """Real Kodi side (Python 3.8): settings through xbmcaddon, Home properties through `kodi`, HTTP with urllib."""

    OWN = "service.nikeflix"
    TIMEOUT = 8   # a refresh runs inside the service loop: short, so a profile switch is never held up (H3)

    def __init__(self, kodi):
        import xbmcaddon
        self.kodi, self.xbmcaddon = kodi, xbmcaddon

    def now(self):
        return self.kodi.now()

    def sleep(self, seconds):
        self.kodi.wait(seconds)

    def aborted(self):
        return self.kodi.aborted()

    def log(self, message, level="info"):
        self.kodi.log(message, level)

    # settings
    def get_own(self, key):
        try:
            return self.xbmcaddon.Addon(self.OWN).getSetting(key)
        except Exception:
            return ""

    def get_own_all(self, keys):
        try:
            a = self.xbmcaddon.Addon(self.OWN)
            return {k: a.getSetting(k) for k in keys}
        except Exception:
            return {}

    def set_own_all(self, values):
        a = self.xbmcaddon.Addon(self.OWN)
        for k, v in values.items():
            a.setSetting(k, v)

    def addon_present(self, addon_id):
        try:
            self.xbmcaddon.Addon(addon_id)
            return True
        except Exception:
            return False

    def get_addon(self, addon_id, key):
        try:
            return self.xbmcaddon.Addon(addon_id).getSetting(key)
        except Exception:
            return None

    def set_addon(self, addon_id, key, value):
        self.xbmcaddon.Addon(addon_id).setSetting(key, value)

    def set_addon_all(self, addon_id, values):
        a = self.xbmcaddon.Addon(addon_id)
        for k, v in values.items():
            a.setSetting(k, v)

    def sync_umbrella(self):
        from resources.lib.umbrellafile import UmbrellaFile, UmbrellaFileEnv
        env = UmbrellaFileEnv(self.kodi)
        if env.installed():
            UmbrellaFile(env, lambda: True).sync_now("Trakt sign-in")

    def umbrella_cache(self, keys):
        raw = self.kodi.get_prop(UMBRELLA_CACHE_PROP)
        if not raw:
            return None
        try:
            d = json.loads(raw)
        except ValueError:
            return None
        return {k: d.get(k) for k in keys} if isinstance(d, dict) else None

    # Home properties
    def get_prop(self, key):
        return self.kodi.get_prop(key)

    def set_prop(self, key, value):
        self.kodi.set_prop(key, value)

    def clear_prop(self, key):
        self.kodi.clear_prop(key)

    # HTTP (stdlib; no requests dependency in service.nikeflix)
    def _headers(self, access=None):
        h = {"Content-Type": "application/json", "trakt-api-version": "2",
             "trakt-api-key": self.get_own(S_CLIENT).strip(), "User-Agent": "NikeFlix service.nikeflix (Kodi)"}
        if access:
            h["Authorization"] = "Bearer " + access
        return h

    def _request(self, url, body=None, access=None):
        import urllib.request
        import urllib.error
        data = json.dumps(body).encode("utf-8") if body is not None else None
        req = urllib.request.Request(url, data=data, headers=self._headers(access), method="POST" if data else "GET")
        try:
            resp = urllib.request.urlopen(req, timeout=self.TIMEOUT)
            raw = resp.read()
            status = resp.status
        except urllib.error.HTTPError as exc:
            status = exc.code
            try:
                raw = exc.read()
            except Exception:
                raw = b""
        except Exception as exc:
            self.log("trakt: request failed: %s" % type(exc).__name__, "warning")
            return 0, None
        try:
            return status, json.loads(raw.decode("utf-8")) if raw else None
        except ValueError:
            return status, None

    def post(self, url, body):
        return self._request(url, body=body)

    def get(self, url, access):
        return self._request(url, access=access)

    def notify_signin_needed(self):
        """One short notice that a new sign-in is needed, unless Quiet Mode is on (then the log line and the
        Trakt Account status carry it)."""
        try:
            if self.get_own("quiet.enabled") == "true":
                return
            import xbmcgui
            addon = self.xbmcaddon.Addon(self.OWN)
            xbmcgui.Dialog().notification(addon.getLocalizedString(32580), addon.getLocalizedString(32588),
                                          sound=False)
        except Exception:
            pass
