# -*- coding: utf-8 -*-
import sys

from resources.lib.sports.plugin import run

run(sys.argv)
