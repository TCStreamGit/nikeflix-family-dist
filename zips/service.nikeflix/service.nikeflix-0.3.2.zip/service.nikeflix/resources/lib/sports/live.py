# -*- coding: utf-8 -*-
"""NikeFlix 4.1 Live sports: keeps the scoreboard cache fresh for the Live page (sports/scoreboard.py).

- About once a minute, only while Settings > Sports > Live sports is On, the profile is settled and nothing is
  playing. One background thread, a short timeout per league, never in the service loop itself.
- After each refresh the Home property nikeflix.sports.updated changes; the Live page's rows carry it in their path,
  so Kodi reloads them with the new scores.
- Live sports Off: no requests at all, and the property nikeflix.sports.off is set so the skin hides every sports
  surface.
"""
import json
import threading

from . import scoreboard as sb

EVERY_S = 60
UPDATED = "nikeflix.sports.updated"
OFF = "nikeflix.sports.off"
CACHE = "special://profile/addon_data/service.nikeflix/sports/scoreboard.json"
SETTINGS = {"enabled": "sports.enabled", "hide": "sports.hide_scores", "source": "sports.source",
            "teams": "sports.fav_teams", "leagues": "sports.fav_leagues", "sports": "sports.fav_sports",
            "channels": "sports.fav_channels"}
SOURCES = ["best", "ca", "us"]


TEAMS = "special://profile/addon_data/service.nikeflix/sports/teams.json"   # sports/teams.py, fetched on the device


def prefs(get_setting, catalogue=None):
    """Settings -> the preference dict scoreboard.py ranks with."""
    def split(v):
        return [x for x in (v or "").split("|") if x]
    try:
        src = SOURCES[int(get_setting(SETTINGS["source"]) or 0)]
    except (ValueError, IndexError):
        src = "best"
    teams = split(get_setting(SETTINGS["teams"]))
    return {"enabled": (get_setting(SETTINGS["enabled"]) or "true") != "false",
            "team_names": sb.team_names(teams, catalogue or {}),
            "hide": get_setting(SETTINGS["hide"]) == "true", "source": src,
            "teams": teams, "leagues": split(get_setting(SETTINGS["leagues"])),
            "sports": split(get_setting(SETTINGS["sports"])), "channels": split(get_setting(SETTINGS["channels"]))}


def http_json(url, timeout=2.5):
    from urllib.request import Request, urlopen
    req = Request(url, headers={"User-Agent": "NikeFlix/4.1 (Kodi)"})
    with urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


class LiveScores(object):
    def __init__(self, kodi, get_setting=None, fetch=None, clock=None):
        self.kodi = kodi
        self.get_setting = get_setting or self._addon_setting
        self.fetch = fetch or http_json
        self.clock = clock or kodi.now
        self.next_at = 0.0
        self.worker = None
        self.path = None

    def _addon_setting(self, sid):
        if getattr(self, "_addon", None) is None:
            import xbmcaddon
            self._addon = xbmcaddon.Addon("service.nikeflix")
        return self._addon.getSetting(sid)

    def cache_path(self):
        if self.path is None:
            self.path = self.kodi.translate(CACHE)
        return self.path

    def poll(self):
        p = prefs(self.get_setting)
        if not p["enabled"] or not self.kodi.cond("Skin.HasSetting(nikeflix.feature.sports)"):   # Family per profile
            if self.kodi.get_prop(OFF) != "1":
                self.kodi.set_prop(OFF, "1")
            return
        if self.kodi.get_prop(OFF):
            self.kodi.clear_prop(OFF)
            self.next_at = 0.0
        now = self.clock()
        if now < self.next_at or (self.worker is not None and self.worker.is_alive()):
            return
        if self.kodi.cond("Player.HasVideo"):
            self.next_at = now + EVERY_S      # nothing while a video plays; try again in a minute
            return
        self.next_at = now + EVERY_S
        self.worker = threading.Thread(target=self._refresh, name="nikeflix-sports")
        self.worker.daemon = True
        self.worker.start()

    def _stop(self):
        return bool(self.kodi.get_prop("nikeflix.quiesce")) or self.kodi.aborted()

    def _refresh(self):
        try:
            def get(url):
                if self._stop():
                    raise RuntimeError("profile switch")
                return self.fetch(url)
            new = sb.fetch_all(get)
            if self._stop():
                return
            path = self.cache_path()
            data = sb.merge(sb.load(path), new, int(self.clock()))
            sb.save(path, data)
            from . import teams      # the favourite-team catalogue, about once a month
            teams.refresh(self.kodi.translate(TEAMS), get, sb.LEAGUES, now=self.clock(), stop=self._stop)
            if not self._stop():
                self.kodi.set_prop(UPDATED, str(data["updated"]))
        except Exception as exc:
            self.kodi.log("sports: scores not refreshed: %s" % type(exc).__name__, "warning")

    def end(self, timeout=3.0):
        w = self.worker
        if w is not None and w.is_alive():
            w.join(timeout)
