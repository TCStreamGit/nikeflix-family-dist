# -*- coding: utf-8 -*-
"""NikeFlix 4.1 Live sports (approved preview, Tanner 2026-11-19): scores, schedules and where to watch.

- Scores come from ESPN's public scoreboard JSON, one request per league. The service refreshes them about once a
  minute, only while Live sports is on and nothing is playing, and keeps them in one cache file, so the Live page
  opens at once.
- Team, league and network logos are the preview's own: ESPN's image server and Wikimedia Commons, loaded by Kodi on
  the device at first use and kept in its texture cache. Nothing is shipped in an archive.
- "Best source" picks the PVR channel a game plays from: a favourite channel first, then the viewer's preference
  (Best available / Canadian channels first / US channels first).
Pure Python (no Kodi) except where a function takes a fetch or file callable.
"""
import json
import time

ESPN = "https://site.api.espn.com/apis/site/v2/sports/%s/scoreboard"
ESPN_IMG = "https://a.espncdn.com"
COMMONS = "https://commons.wikimedia.org/wiki/Special:FilePath/%s?width=240"

SPORTS = ["Hockey", "Basketball", "Football", "Soccer", "Baseball", "Fighting", "Motorsport", "Golf", "Tennis"]

# id, name, sport, ESPN path (None: no public feed), logo (the preview's), tile colour, the off-season note
LEAGUES = [
    {"id": "NHL", "name": "NHL", "sport": "Hockey", "path": "hockey/nhl", "logo": "/i/teamlogos/leagues/500-dark/nhl.png", "col": "FF0D0D0D"},
    {"id": "NBA", "name": "NBA", "sport": "Basketball", "path": "basketball/nba", "logo": "/i/teamlogos/leagues/500-dark/nba.png", "col": "FF1D428A"},
    {"id": "NFL", "name": "NFL", "sport": "Football", "path": "football/nfl", "logo": "/i/teamlogos/leagues/500-dark/nfl.png", "col": "FF013369"},
    {"id": "CFL", "name": "CFL", "sport": "Football", "path": "football/cfl", "logo": "", "col": "FF7A0019", "off": "Off-season · back in June"},
    {"id": "MLB", "name": "MLB", "sport": "Baseball", "path": "baseball/mlb", "logo": "/i/teamlogos/leagues/500-dark/mlb.png", "col": "FF041E42", "off": "Off-season · back in March"},
    {"id": "EPL", "name": "Premier League", "sport": "Soccer", "path": "soccer/eng.1", "logo": "/i/leaguelogos/soccer/500-dark/23.png", "col": "FF38003C"},
    {"id": "MLS", "name": "MLS", "sport": "Soccer", "path": "soccer/usa.1", "logo": "/i/leaguelogos/soccer/500-dark/19.png", "col": "FF22303C"},
    {"id": "UFC", "name": "UFC", "sport": "Fighting", "path": "mma/ufc", "logo": "/i/teamlogos/leagues/500/ufc.png", "col": "FF1A1A1A"},
    {"id": "BOX", "name": "Boxing", "sport": "Fighting", "path": None, "logo": "", "col": "FF5A0F0F", "off": "On your channels when a card is on"},
    {"id": "F1", "name": "Formula 1", "sport": "Motorsport", "path": "racing/f1", "logo": "/i/teamlogos/leagues/500-dark/f1.png", "col": "FFB3000C"},
    {"id": "NASCAR", "name": "NASCAR", "sport": "Motorsport", "path": "racing/nascar-premier", "logo": "", "col": "FF1B3F8F", "off": "Off-season · back in February"},
    {"id": "PGA", "name": "PGA TOUR", "sport": "Golf", "path": "golf/pga", "logo": "", "col": "FF0A2240"},
    {"id": "ATP", "name": "ATP Tennis", "sport": "Tennis", "path": "tennis/atp", "logo": "", "col": "FF0B3D2E"},
]
LEAGUE = {l["id"]: l for l in LEAGUES}

# networks: the preview's order is the default "best available" order; ca = a Canadian network
NETWORKS = [
    {"id": "SN", "name": "Sportsnet", "logo": "Logo Sportsnet 2011.svg", "ca": True,
     "feeds": ["Sportsnet ONE", "Sportsnet Ontario", "Sportsnet East", "Sportsnet West", "Sportsnet Pacific", "Sportsnet 360", "Sportsnet"]},
    {"id": "TSN", "name": "TSN", "logo": "TSN Logo.svg", "ca": True, "feeds": ["TSN 1", "TSN 2", "TSN 3", "TSN 4", "TSN 5", "TSN"]},
    {"id": "ESPN", "name": "ESPN", "logo": "ESPN wordmark.svg", "feeds": ["ESPN", "ESPN2", "ESPNU", "ESPNews", "ESPN+"]},
    {"id": "TNT", "name": "TNT Sports", "logo": "TNT Sports 2021 logo.svg", "feeds": ["TNT", "truTV"]},
    {"id": "NHLN", "name": "NHL Network", "logo": "NHL Network 2012.svg", "feeds": ["NHL Network"]},
    {"id": "NBATV", "name": "NBA TV", "logo": "", "feeds": ["NBA TV", "NBA League Pass"]},
    {"id": "NFLN", "name": "NFL Network", "logo": "", "feeds": ["NFL Network", "NFL RedZone"]},
    {"id": "DAZN", "name": "DAZN", "logo": "", "ca": True, "feeds": ["DAZN 1", "DAZN 2", "DAZN"]},
    {"id": "BEIN", "name": "beIN SPORTS", "logo": "BeIN Sports logo (horizontal version).svg", "feeds": ["beIN SPORTS", "beIN SPORTS 2"]},
    {"id": "CBC", "name": "CBC Sports", "logo": "CBC Sports 2017.svg", "ca": True, "feeds": ["CBC"]},
]


def league_logo(league):
    p = LEAGUE.get(league, {}).get("logo")
    return ESPN_IMG + p if p else ""


def network_logo(net):
    return COMMONS % net["logo"].replace(" ", "_") if net.get("logo") else ""


def _team(c):
    t = c.get("team") or {}
    ath = c.get("athlete") or {}
    name = t.get("shortDisplayName") or t.get("displayName") or ath.get("shortName") or ath.get("displayName") or ""
    logo = t.get("logo") or ""
    if not logo and t.get("logos"):
        logo = t["logos"][0].get("href", "")
    return {"name": name, "full": t.get("displayName") or ath.get("displayName") or name,
            "abbr": t.get("abbreviation") or "", "logo": logo, "score": str(c.get("score") or ""),
            "color": t.get("color") or "", "side": c.get("homeAway") or ""}


def parse(league, data):
    """ESPN scoreboard JSON -> games: id, league, sport, state (pre/in/post), detail, start (epoch), title, short,
    away/home (two-sided events) or None, broadcasts (network names)."""
    out = []
    for ev in (data or {}).get("events") or []:
        try:
            comp = (ev.get("competitions") or [{}])[0]
            st = (ev.get("status") or comp.get("status") or {}).get("type") or {}
            cs = comp.get("competitors") or []
            away = home = None
            if len(cs) == 2:
                sides = {c.get("homeAway"): _team(c) for c in cs}
                away, home = sides.get("away"), sides.get("home")
                if away is None or home is None:            # fights: no home/away, keep ESPN's order
                    away, home = _team(cs[0]), _team(cs[1])
            names = []
            for b in comp.get("broadcasts") or []:
                names += b.get("names") or []
            for g in comp.get("geoBroadcasts") or []:
                n = (g.get("media") or {}).get("shortName")
                if n:
                    names.append(n)
            seen, casts = set(), []
            for n in names:
                if n not in seen:
                    seen.add(n)
                    casts.append(n)
            title = ev.get("name") or ""
            if away and home and league not in ("UFC", "BOX"):
                title = "%s at %s" % (away["name"], home["name"])
            out.append({"id": "%s-%s" % (league, ev.get("id")), "league": league,
                        "sport": LEAGUE.get(league, {}).get("sport", ""),
                        "state": st.get("state") or "pre",
                        "detail": st.get("shortDetail") or st.get("detail") or st.get("description") or "",
                        "start": _epoch(ev.get("date") or ""), "title": title,
                        "short": ev.get("shortName") or title, "away": away, "home": home, "broadcasts": casts})
        except Exception:
            continue
    return out


def _epoch(iso):
    """'2026-11-20T00:00Z' -> seconds since 1970 (UTC). 0 when unreadable."""
    import calendar
    for fmt in ("%Y-%m-%dT%H:%MZ", "%Y-%m-%dT%H:%M:%SZ"):
        try:
            return calendar.timegm(time.strptime(iso, fmt))
        except (ValueError, TypeError):
            pass
    return 0


def fetch_all(get_json, leagues=None):
    """{league id: [games]} for every league with a feed; a league that fails keeps no games (never raises)."""
    out = {}
    for l in LEAGUES:
        if not l["path"] or (leagues and l["id"] not in leagues):
            continue
        try:
            out[l["id"]] = parse(l["id"], get_json(ESPN % l["path"]))
        except Exception:
            out[l["id"]] = None              # None = not fetched this time (the page keeps the last games)
    return out


def merge(old, new, now):
    """New games replace a league's games; a league that failed keeps its last games for up to six hours."""
    games = dict((old or {}).get("leagues") or {})
    fetched = dict((old or {}).get("fetched") or {})
    for lid, g in new.items():
        if g is not None:
            games[lid], fetched[lid] = g, now
        elif now - fetched.get(lid, 0) > 6 * 3600:
            games.pop(lid, None)
    return {"updated": now, "leagues": games, "fetched": fetched}


# --- favourites and preferences --------------------------------------------------------------------------------------
def team_key(game_side, league):
    return "%s:%s" % (league, game_side.get("abbr") or game_side.get("name"))


def is_fav_team(game, prefs):
    """A favourite is stored as "<league>:<abbreviation>" (the team picker). ESPN's scoreboard abbreviation can differ
    from its team list's (CFL), so a team also matches by name (prefs["team_names"]: "<league>:<name>", lower case)."""
    teams = set(prefs.get("teams") or [])
    names = set(prefs.get("team_names") or [])
    for s in (game.get("away"), game.get("home")):
        if s and (team_key(s, game["league"]) in teams or ("%s:%s" % (game["league"], (s.get("name") or "").lower())) in names):
            return True
    return False


def load_teams(path):
    """The team catalogue file (sports/teams.py, fetched on the device): {"updated": {..}, "teams": {league: [..]}}."""
    try:
        with open(path, encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, IOError, ValueError):
        return {}


def team_names(teams, catalogue):
    """"NHL:TOR" keys -> {"nhl:maple leafs"-style "<LEAGUE>:<name lower>"} for is_fav_team."""
    out = set()
    for key in teams or []:
        lg, _, ab = key.partition(":")
        for t in catalogue.get(lg) or []:
            if t["ab"] == ab:
                out.add("%s:%s" % (lg, t["name"].lower()))
    return out


def rank(game, prefs):
    """Order inside a row: favourite teams, then favourite leagues, then favourite sports, then the rest; within each
    group live first, then by start time."""
    if is_fav_team(game, prefs):
        g = 0
    elif game["league"] in (prefs.get("leagues") or []):
        g = 1
    elif game["sport"] in (prefs.get("sports") or []):
        g = 2
    else:
        g = 3
    return (g, {"in": 0, "pre": 1, "post": 2}.get(game["state"], 3), game.get("start") or 0)


def games(cache, state=None, league=None, sport=None, team=None, network=None, prefs=None, now=None, window=None):
    """Games from the cache, filtered and ranked. window = (from, to) epoch seconds for upcoming games."""
    prefs = prefs or {}
    out = []
    for lid, gs in ((cache or {}).get("leagues") or {}).items():
        if league and lid != league:
            continue
        for g in gs or []:
            if state and g["state"] != state:
                continue
            if sport and g["sport"] != sport:
                continue
            if team and team not in (team_key(g["away"], lid) if g.get("away") else "", team_key(g["home"], lid) if g.get("home") else ""):
                continue
            if network and not any(_net_of(b) == network for b in g.get("broadcasts") or []):
                continue
            if window and not (window[0] <= (g.get("start") or 0) <= window[1]):
                continue
            out.append(g)
    return sorted(out, key=lambda g: rank(g, prefs))


def _net_of(name):
    n = (name or "").lower()
    for net in NETWORKS:
        if any(n == f.lower() or n.startswith(f.lower()) for f in net["feeds"]) or n == net["name"].lower():
            return net["id"]
    return ""


# --- best source ----------------------------------------------------------------------------------------------------
# words that name nothing on their own: they must not make a programme "carry" a game (review 2026-11-19: "The RSM
# Classic" matched "The Simpsons"; NY Rangers at NY Islanders matched "New Amsterdam")
STOPWORDS = {"the", "and", "for", "with", "live", "new", "york", "los", "angeles", "san", "las", "city", "united", "real",
             "club", "team", "sports", "sport", "game", "games", "match", "classic", "championship", "cup", "series",
             "night", "fight", "grand", "prix", "tour", "open", "round", "final", "finals", "league", "national",
             "north", "south", "east", "west", "saint", "fort", "bay", "state", "athletic", "athletics"}


def _words(s):
    import re
    return [w for w in re.split(r"[^a-z0-9]+", (s or "").lower()) if len(w) > 2 and w not in STOPWORDS]


def _norm(name):
    """'TSN 1' / 'TSN1' / 'tsn-1' -> 'tsn1': favourite channels compare loosely."""
    import re
    return re.sub(r"[^a-z0-9]+", "", (name or "").lower())


def channel_net(channel_name):
    return _net_of(channel_name)


def _carries(game, now_words):
    """The programme names the game: both teams by their nicknames (two-sided games), or most of the event's own
    words (a tournament, race or fight)."""
    sides = [s for s in (game.get("away"), game.get("home")) if s]
    if len(sides) == 2:
        nicks = [set(_words(s.get("name"))) for s in sides]
        if all(nicks):
            return all(n & now_words for n in nicks)
    words = set(_words(game.get("title")))
    if not words:
        return False
    return len(words & now_words) >= max(2, (len(words) + 1) // 2) if len(words) > 1 else words <= now_words


def sources(game, channels, prefs):
    """PVR channels that carry the game, best first.

    channels: [{"id", "name", "now"}] (now = the channel's current programme title). A channel carries the game when
    its current programme names it (see _carries), or when it is a network ESPN lists for the game and its programme
    is unknown or names the league or the sport (guides often say just "NHL Hockey"). Order: favourite channels, then
    the preference (ca / us / best), then the preview's network order."""
    league = game.get("league") or ""
    generic = {league.lower(), (LEAGUE.get(league, {}).get("name") or "").lower(), (game.get("sport") or "").lower()} - {""}
    cast_nets = set(_net_of(b) for b in game.get("broadcasts") or []) - {""}
    favs = set(_norm(c) for c in prefs.get("channels") or [])
    pref = prefs.get("source") or "best"
    order = {n["id"]: i for i, n in enumerate(NETWORKS)}
    found = []
    for ch in channels or []:
        raw = (ch.get("now") or "").lower()
        on = _carries(game, set(_words(raw)))
        net = _net_of(ch.get("name"))
        listed = bool(net and net in cast_nets and (not raw or any(g in raw for g in generic)))
        if not on and not listed:
            continue
        ca = bool(net and next((n.get("ca") for n in NETWORKS if n["id"] == net), False))
        pref_rank = 0 if pref == "best" else (0 if (ca if pref == "ca" else not ca) else 1)
        found.append(((0 if _norm(ch.get("name")) in favs else 1, 0 if on else 1, pref_rank, order.get(net, 99), ch.get("name") or ""), ch))
    return [ch for _, ch in sorted(found, key=lambda x: x[0])]


# --- the cache file ---------------------------------------------------------------------------------------------------
def load(path):
    try:
        with open(path, encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, IOError, ValueError):
        return {}


def save(path, data):
    import os
    tmp = path + ".tmp"
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(data, fh)
    os.replace(tmp, path)
