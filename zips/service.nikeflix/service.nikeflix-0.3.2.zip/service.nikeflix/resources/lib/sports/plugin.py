# -*- coding: utf-8 -*-
"""plugin://service.nikeflix/ routes for the Sports rows (T41). Quiet: no dialogs or notifications.

  ?mode=live_guide_group&group_key=<key>&page=<n>   one Sports row (the legacy contract, new owner)
  ?mode=live_guide                                  the section/group index
  ?mode=play_channel&channelid=<id>                 play a PVR channel by Kodi id
  ?mode=sports&row=<row>[&filter=..]                 NikeFlix 4.1 Live page rows (sports/hub.py)
  ?mode=sports_play&game=<id>                       play a game from its best source (a favourite channel first)
"""
import json
from urllib.parse import parse_qs, urlencode

from . import rows as _rows
from . import rules

BASE = "plugin://service.nikeflix/"


def url(**q):
    return BASE + "?" + urlencode(q)


def parse(argv):
    q = parse_qs((argv[2] if len(argv) > 2 else "").lstrip("?"))
    return {k: v[0] for k, v in q.items()}


def channels_now(rows):
    """PVR rows -> [{"id", "name", "now"}] for scoreboard.sources()."""
    return [{"id": r["channelid"], "name": rules.clean_display_name(r["name"]), "now": r.get("now_title", "")} for r in rows]


def plan_sports(params, cache, prefs, rows, now=None):
    """("dir", entries) for a Live page row, ("play", channelid) / ("missing", title) for a game."""
    from . import hub, scoreboard as sb
    mode = params.get("mode", "")
    if mode == "sports":
        return "dir", hub.build(params.get("row", ""), cache, prefs, params.get("filter", ""), now, channels_now(rows))
    if mode == "sports_play":
        if not prefs.get("enabled", True):
            return "dir", []
        gid = params.get("game", "")
        for g in sb.games(cache, prefs=prefs):
            if g["id"] == gid:
                src = sb.sources(g, channels_now(rows), prefs)
                return ("play", src[0]["id"]) if src else ("missing", g["title"])
        return "missing", ""
    return "dir", []


def plan(params, source):
    """Pure routing: returns ("dir", [entry...]) or ("play", channelid) or ("dir", []) for unknown routes.

    entry = {"label", "label2", "path", "folder", "icon", "plot"}"""
    mode = params.get("mode", "")
    if mode == "play_channel":
        try:
            return "play", int(params.get("channelid", ""))
        except ValueError:
            return "dir", []
    if mode == "live_guide":
        sec = params.get("section", "")
        if not sec:
            return "dir", [{"label": s["label"], "label2": "", "path": url(mode="live_guide", section=s["key"]),
                            "folder": True, "icon": "", "plot": s.get("description", "")} for s in rules.sections()]
        return "dir", [{"label": g["label"], "label2": "", "path": url(mode="live_guide_group", group_key=g["key"], page=1),
                        "folder": True, "icon": "", "plot": ""} for g in rules.groups_for_section(sec)]
    if mode == "live_guide_group":
        key = params.get("group_key", "")
        try:
            page = int(params.get("page", "1") or 1)
        except ValueError:
            page = 1
        items, has_next, page = _rows.group_page(source.rows(), key, page)
        out = [{"label": rules.clean_display_name(r["name"]), "label2": r.get("now_title", ""),
                "path": url(mode="play_channel", channelid=r["channelid"]), "folder": False,
                "icon": r.get("icon", ""), "plot": rules.clean_description(r.get("now_description", "")) or r.get("now_title", "")}
               for r in items]
        if has_next:
            out.append({"label": "Next page", "label2": "", "path": url(mode="live_guide_group", group_key=key, page=page + 1),
                        "folder": True, "icon": "", "plot": ""})
        return "dir", out
    return "dir", []


def run(argv):  # pragma: no cover - Kodi runtime
    import xbmc
    import xbmcgui
    import xbmcplugin

    def rpc(method, params=None):
        req = {"jsonrpc": "2.0", "id": 1, "method": method}
        if params is not None:
            req["params"] = params
        res = json.loads(xbmc.executeJSONRPC(json.dumps(req)))
        return res.get("result") if "error" not in res else None

    handle = int(argv[1]) if len(argv) > 1 and argv[1].lstrip("-").isdigit() else -1
    params = parse(argv)
    if params.get("mode") in ("sports", "sports_play"):
        import xbmcaddon
        import xbmcvfs
        from . import live, scoreboard as sb
        import xbmc
        prefs = live.prefs(xbmcaddon.Addon("service.nikeflix").getSetting, sb.load_teams(xbmcvfs.translatePath(live.TEAMS)).get("teams", {}))
        if not xbmc.getCondVisibility("Skin.HasSetting(nikeflix.feature.sports)"):
            prefs["enabled"] = False          # this profile has Sports off (Family): no rows, no play
        cache = sb.load(xbmcvfs.translatePath(live.CACHE))
        # the channel list is read only where a row shows a channel (review: every row reloads once a minute)
        need = params.get("mode") == "sports_play" or params.get("row") in ("featured", "live", "networks")
        rows = _rows.PvrSource(rpc).rows() if (prefs["enabled"] and need) else []
        kind, payload = plan_sports(params, cache, prefs, rows)
        if kind == "missing":
            xbmcgui.Dialog().notification("NikeFlix", "%s is not on your channels right now" % (payload or "This game"),
                                          xbmcgui.NOTIFICATION_INFO, 5000)
            return
    else:
        kind, payload = plan(params, _rows.PvrSource(rpc))
    if kind == "play":
        rpc("Player.Open", {"item": {"channelid": payload}})
        return
    for e in payload:
        li = xbmcgui.ListItem(label=e["label"], label2=e["label2"])
        if e["icon"]:
            li.setArt({"icon": e["icon"], "thumb": e["icon"]})
        for k, v in (e.get("props") or {}).items():
            li.setProperty(k, v)
        tag = li.getVideoInfoTag()
        tag.setTitle(e["label"])
        tag.setPlot(e["plot"])
        xbmcplugin.addDirectoryItem(handle, e["path"], li, e["folder"])
    xbmcplugin.setContent(handle, "videos")
    xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)
