# -*- coding: utf-8 -*-
"""NikeFlix 4.1 Live page rows (approved preview): the entries plugin://service.nikeflix/?mode=sports&row=<row>
returns. Pure Python; the plugin turns each entry into a ListItem (label, label2, art, properties).

Rows: featured (the billboard game), live (Live Now), teams (Your Teams), upcoming (Coming Up), final (Final Scores),
sports, leagues, networks. A filter narrows the game rows to one sport, league, team or network:
"sport:Hockey", "league:NHL", "team:NHL:TOR", "net:TSN".
"""
import time

from . import scoreboard as sb

ROWS = ("featured", "live", "teams", "upcoming", "final", "sports", "leagues", "networks")
DAY = 86400


def _filter(filt):
    kind, _, value = (filt or "").partition(":")
    return {"sport": value} if kind == "sport" else {"league": value} if kind == "league" else \
        {"team": value} if kind == "team" else {"network": value} if kind == "net" else {}


def when(epoch, now, localtime=time.localtime):
    """'9:30 PM' today, 'Thu 8:15 PM' this week, else 'Nov 27'."""
    if not epoch:
        return ""
    t = localtime(epoch)
    clock = time.strftime("%I:%M %p", t).lstrip("0")
    days = int((epoch - now) // DAY)
    if localtime(now)[:3] == t[:3]:
        return clock
    if 0 <= days < 6:
        return time.strftime("%a ", t) + clock
    return time.strftime("%b ", t) + str(t.tm_mday)


def game_entry(g, prefs, now, channels=None):
    hide = prefs.get("hide") and g["state"] != "pre"
    src = sb.sources(g, channels or [], prefs)
    channel = src[0]["name"] if src else (g["broadcasts"][0] if g.get("broadcasts") else "")
    props = {"kind": "game", "game": g["id"], "league": g["league"], "league_name": sb.LEAGUE.get(g["league"], {}).get("name", g["league"]),
             "league_logo": sb.league_logo(g["league"]), "sport": g["sport"], "state": g["state"],
             "live": "1" if g["state"] == "in" else "", "detail": g["detail"], "channel": channel,
             "when": when(g.get("start"), now) if g["state"] == "pre" else "",
             "sources": str(len(src)), "fav": "1" if sb.is_fav_team(g, prefs) else ""}
    for side in ("away", "home"):
        t = g.get(side) or {}
        props[side + "_name"] = t.get("name", "")
        props[side + "_logo"] = t.get("logo", "")
        props[side + "_score"] = "" if (hide or g["state"] == "pre") else t.get("score", "")   # no 0-0 before the start
        col = t.get("color", "")
        props[side + "_color"] = col
        # whole AARRGGBB colours: Kodi reads a colour as an info label only when the attribute starts with $INFO
        props[side + "_tint"] = "B3" + col if len(col) == 6 else ""
        props[side + "_bg"] = "66" + col if len(col) == 6 else ""
    if g["state"] == "in":
        status = "" if hide else g["detail"]
    elif g["state"] == "pre":
        # the card shows the start time at the top; the bottom line names the league and the sources (preview)
        status = props["league_name"] + (" · %d sources" % len(src) if len(src) > 1 else "")
    else:
        status = "Final" if hide else g["detail"]
    score = ""
    if g.get("away") and g.get("home") and not hide and g["state"] != "pre":
        score = "%s %s - %s %s" % (g["away"].get("abbr") or g["away"]["name"], g["away"].get("score", ""),
                                   g["home"].get("abbr") or g["home"]["name"], g["home"].get("score", ""))
    props["score_line"] = score
    props["meta"] = "  ·  ".join([props["league_name"]] + (["%d sources" % len(src)] if len(src) > 1 else []) + (["HD"] if src else []))
    props["status"] = status
    return {"label": g["title"], "label2": status, "path": "plugin://service.nikeflix/?mode=sports_play&game=" + g["id"],
            "folder": False, "icon": props["home_logo"] or props["league_logo"], "plot": "", "props": props}


def tile(kind, label, label2, filt, icon="", props=None):
    p = {"kind": kind, "filter": filt}
    p.update(props or {})
    return {"label": label, "label2": label2, "path": "", "folder": False, "icon": icon, "plot": "", "props": p}


def build(row, cache, prefs, filt="", now=None, channels=None):
    now = now or time.time()
    if not prefs.get("enabled", True):
        return []
    f = _filter(filt)
    if row in ("featured", "live"):
        gs = sb.games(cache, state="in", prefs=prefs, **f)
        if row == "featured":
            gs = gs or sb.games(cache, state="pre", prefs=prefs, window=(now, now + DAY), **f)
            gs = gs[:1]
        return [game_entry(g, prefs, now, channels) for g in gs]
    if row == "teams":
        teams = prefs.get("teams") or []
        gs = [g for g in sb.games(cache, prefs=prefs, **f) if sb.is_fav_team(g, prefs)] if teams else []
        return [game_entry(g, prefs, now, channels) for g in gs]
    if row == "upcoming":
        gs = sorted(sb.games(cache, state="pre", prefs=prefs, window=(now, now + 7 * DAY), **f),
                    key=lambda g: (sb.rank(g, prefs)[0], g.get("start") or 0))
        return [game_entry(g, prefs, now, channels) for g in gs[:40]]
    if row == "final":
        gs = sorted(sb.games(cache, state="post", prefs=prefs, **f), key=lambda g: (sb.rank(g, prefs)[0], -(g.get("start") or 0)))
        return [game_entry(g, prefs, now, channels) for g in gs[:40] if now - (g.get("start") or 0) < 2 * DAY]
    if row == "sports":
        out = []
        for sp in sorted(sb.SPORTS, key=lambda s: (s not in (prefs.get("sports") or []), sb.SPORTS.index(s))):
            n = len(sb.games(cache, state="in", sport=sp))
            out.append(tile("sport", sp, "%d live" % n if n else "", "sport:" + sp, "",
                            {"icon_name": sp.lower(), "live_count": str(n)}))
        return out
    if row == "leagues":
        out = []
        for l in sorted(sb.LEAGUES, key=lambda l: (l["id"] not in (prefs.get("leagues") or []), sb.LEAGUES.index(l))):
            live = len(sb.games(cache, state="in", league=l["id"]))
            soon = len(sb.games(cache, state="pre", league=l["id"], window=(now, now + 7 * DAY)))
            note = "%d live" % live if live else ("Upcoming games" if soon else l.get("off", "No games this week"))
            out.append(tile("league", l["name"], note, "league:" + l["id"], sb.league_logo(l["id"]),
                            {"color": l["col"], "live_count": str(live)}))
        return out
    if row == "networks":
        out = []
        favs = set(prefs.get("channels") or [])
        nets = sorted(sb.NETWORKS, key=lambda n: (not any(c in favs for c in n["feeds"]), sb.NETWORKS.index(n)))
        for n in nets:
            on = ""
            for ch in channels or []:
                if sb.channel_net(ch.get("name")) == n["id"] and ch.get("now"):
                    on = "On now: " + ch["now"]
                    break
            out.append(tile("network", n["name"], on, "net:" + n["id"], sb.network_logo(n)))
        return out
    return []
