# -*- coding: utf-8 -*-
"""NikeFlix 4.1 favourite-team catalogue: every team in each league, read from ESPN's public teams list on the device
and kept in the profile (like the logos, nothing is shipped). The Live sports service refreshes it about once a month;
the team picker reads it, and fetches a league that is still missing when it opens.
"""
import json
import os
import time

TEAMS_URL = "https://site.api.espn.com/apis/site/v2/sports/%s/teams"
MAX_AGE = 30 * 86400


def parse(data):
    out = []
    try:
        teams = data["sports"][0]["leagues"][0]["teams"]
    except (KeyError, IndexError, TypeError):
        return out
    for t in teams:
        t = t.get("team") or {}
        if t.get("abbreviation") and t.get("displayName"):
            out.append({"ab": t["abbreviation"], "name": t.get("shortDisplayName") or t.get("name") or t["displayName"],
                        "full": t["displayName"], "city": t.get("location") or ""})
    return sorted(out, key=lambda x: x["full"])


def load(path):
    try:
        with open(path, encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, IOError, ValueError):
        return {}


def save(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(data, fh)
    os.replace(tmp, path)


def refresh(path, get_json, leagues, now=None, only_missing=False, stop=lambda: False):
    """Fetch the leagues whose list is missing (or older than a month unless only_missing); returns the catalogue
    {"updated": {league: epoch}, "teams": {league: [...]}}. A league that fails keeps its last list."""
    now = now or time.time()
    cat = load(path) or {}
    cat.setdefault("teams", {})
    cat.setdefault("updated", {})
    changed = False
    for lg in leagues:
        if stop():
            break
        if lg["id"] in cat["teams"] and (only_missing or now - cat["updated"].get(lg["id"], 0) < MAX_AGE):
            continue
        if not lg.get("path"):
            continue
        try:
            got = parse(get_json(TEAMS_URL % lg["path"]))
        except Exception:
            continue
        if got:
            cat["teams"][lg["id"]], cat["updated"][lg["id"]] = got, now
            changed = True
    if changed:
        save(path, cat)
    return cat
