# -*- coding: utf-8 -*-
"""NikeFlix 4.1 rows for Home, Shows and Movies (catalog.py: what; rotate.py: writing and rotation)."""
