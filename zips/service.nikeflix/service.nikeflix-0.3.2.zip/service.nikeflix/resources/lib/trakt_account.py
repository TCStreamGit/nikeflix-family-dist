# -*- coding: utf-8 -*-
"""Power-menu "Trakt Account" (plan section C; I9-R MD-18 keeps it in place of the legacy "Trakt Setup").

The one Trakt sign-in of this profile (T30/T31/T33, traktbroker.py): a small menu with the status line, Connect /
Sign in again (Trakt's device code: go to trakt.tv/activate and enter the code), Disconnect. Every Trakt add-on in the
build then uses this sign-in; none asks for its own. Without a client id on this device the menu only says so."""
from resources.lib import traktbroker as tb

HEADING = 32580
MSG = {"not_configured": 32581, "signed_out": 32582, "connected": 32583, "needs_signin": 32584}
BTN_CONNECT, BTN_RECONNECT, BTN_DISCONNECT, BTN_CLOSE = 32585, 32586, 32587, 32589
CODE_HEADING, CODE_TEXT = 32590, 32591
RESULT = {"connected": 32592, "cancelled": 32593, "expired": 32594, "denied": 32595, "error": 32596,
          "signed_out": 32597, "not_configured": 32581, "invalid": 32596, "used": 32596}


class KodiUI(object):
    """Dialogs for the device flow (progress box with the code; never logged)."""

    def __init__(self, strings):
        import xbmcgui
        self.xbmcgui, self.s = xbmcgui, strings
        self.dlg = None

    def show_code(self, url, code):
        self.dlg = self.xbmcgui.DialogProgress()
        self.dlg.create(self.s(CODE_HEADING), self.s(CODE_TEXT) % (url, code))
        self.dlg.update(0)

    def progress(self, percent):
        if self.dlg is not None:
            self.dlg.update(int(percent))

    def cancelled(self):
        return bool(self.dlg is not None and self.dlg.iscanceled())

    def close(self):
        if self.dlg is not None:
            self.dlg.close()
            self.dlg = None


def menu(status, username, strings):
    """-> (lines for the select dialog, [action per line]); pure, unit-tested."""
    line = strings(MSG[status])
    if status == "connected" and "%s" in line:
        line = line % (username or "Trakt")
    items, actions = [line], ["none"]
    if status in ("signed_out", "needs_signin"):
        items.append(strings(BTN_CONNECT if status == "signed_out" else BTN_RECONNECT))
        actions.append("connect")
    if status in ("connected", "needs_signin"):
        items.append(strings(BTN_DISCONNECT))
        actions.append("disconnect")
    items.append(strings(BTN_CLOSE))
    actions.append("close")
    return items, actions


def run(broker, strings, select, ok, ui):
    """One pass of the menu. `select(heading, items) -> index or -1`, `ok(heading, text)`. Returns the action taken."""
    status = broker.status()
    tok = broker.token()
    items, actions = menu(status, tok.username if tok else "", strings)
    if status == "not_configured":
        ok(strings(HEADING), items[0])
        return "none"
    idx = select(strings(HEADING), items)
    action = actions[idx] if 0 <= idx < len(actions) else "close"
    if action == "connect":
        result = broker.connect(ui)
        text = strings(RESULT.get(result, 32596))
        if result == "connected" and "%s" in text:
            tok = broker.token()
            text = text % (tok.username if tok and tok.username else "Trakt")
        ok(strings(HEADING), text)
        return "connect:" + result
    if action == "disconnect":
        broker.disconnect()
        ok(strings(HEADING), strings(RESULT["signed_out"]))
        return "disconnect"
    return action


def show(kodi):
    import xbmcaddon
    import xbmcgui
    addon = xbmcaddon.Addon("service.nikeflix")
    strings = addon.getLocalizedString
    broker = tb.Broker(tb.TraktEnv(kodi))
    dialog = xbmcgui.Dialog()
    try:
        return run(broker, strings, dialog.select, dialog.ok, KodiUI(strings))
    except Exception as exc:   # never leave a half-open dialog or a traceback toast
        kodi.log("trakt_account failed: %s" % type(exc).__name__, "warning")
        return "error"
