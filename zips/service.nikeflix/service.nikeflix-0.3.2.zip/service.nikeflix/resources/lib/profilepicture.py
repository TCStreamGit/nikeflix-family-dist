# -*- coding: utf-8 -*-
"""NikeFlix 4.1: change a profile's picture from the gate (Tanner 2026-11-19: "have the profile picture change with
the images built into the thing ... rather the profile pictures be already able to be changed").

RunScript(service.nikeflix,action=profile_picture,target=<that profile's thumbnail>,picture=<a shipped picture>)
from the skin's picker (Custom_1122).

Every NikeFlix profile has its own picture file under special://home/media/userpictures/ (the build gives each
profile a different file: defaultuser_4/5/35/7/53.png). Changing a picture copies the chosen shipped picture
(special://skin/extras/userpicture/) over that profile's own file. Kodi's profiles.xml is never edited: Kodi
rewrites that file from memory, so an edit would be lost. Kodi's cached copy of the old picture is then dropped
and the gate opens again; for the rest of this session it draws that profile from the shipped picture.

Both paths are checked first. The target must be a plain image file directly inside the profile-pictures folder.
The picture must be one of the shipped pictures. Nothing else is ever written.
"""
import json
import os
import re
import shutil

TARGET_DIR = "special://home/media/userpictures/"
SOURCE_DIR = "special://skin/extras/userpicture/"
NAME_RE = re.compile(r"^[A-Za-z0-9_.-]+\.(png|jpg|jpeg)$", re.I)


def _norm(p):
    return os.path.normcase(os.path.normpath(p))


def resolve(kodi, target, picture):
    """-> (target_file, picture_file) on disk, or raises ValueError with the reason (no write happens)."""
    tdir, sdir = _norm(kodi.translate(TARGET_DIR)), _norm(kodi.translate(SOURCE_DIR))
    t = _norm(kodi.translate(target or ""))
    s = _norm(kodi.translate(picture or ""))
    if not target or os.path.dirname(t) != tdir or not NAME_RE.match(os.path.basename(t)):
        raise ValueError("target is not a picture file in the profile-pictures folder")
    if not picture or os.path.dirname(s) != sdir or not NAME_RE.match(os.path.basename(s)):
        raise ValueError("picture is not one of the pictures NikeFlix ships")
    if not os.path.isfile(s):
        raise ValueError("picture file is missing")
    if os.path.islink(t) or os.path.islink(s):
        raise ValueError("a picture file is a link")
    return t, s


def drop_cached(rpc, target_url_parts):
    """Remove Kodi's cached textures whose url contains the target's file name (JSON-RPC Textures.*)."""
    removed = 0
    for part in target_url_parts:
        res = rpc("Textures.GetTextures", {"properties": ["url"], "filter": {"field": "url", "operator": "contains", "value": part}})
        for t in (res or {}).get("textures") or []:
            rpc("Textures.RemoveTexture", {"textureid": t["textureid"]})
            removed += 1
    return removed


def _rpc(method, params):
    import xbmc
    out = json.loads(xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": method, "params": params})))
    return out.get("result")


SLOTS = 6


def remember(kodi, slot, picture):
    """Home property nikeflix.pic.p<slot> = the shipped picture, for the profile at that position in the gate's row
    (1..6, from the skin). Anything else is ignored: the gate then simply shows the file from the next start."""
    try:
        n = int(slot)
    except (TypeError, ValueError):
        return False
    if not 1 <= n <= SLOTS:
        return False
    kodi.set_prop("nikeflix.pic.p%d" % n, picture)
    return True


def change(kodi, target, picture, rpc=None, copy=shutil.copyfile, slot=None):
    rpc = rpc or _rpc
    try:
        t, s = resolve(kodi, target, picture)
    except ValueError as e:
        kodi.log("profile_picture refused: %s" % e, "warning")
        kodi.builtin("Notification(NikeFlix,This profile's picture can't be changed here,4000)")
        return False
    try:
        copy(s, t)
    except OSError as e:
        kodi.log("profile_picture failed: %s" % e.__class__.__name__, "error")
        kodi.builtin("Notification(NikeFlix,The picture could not be saved,4000)")
        return False
    removed = drop_cached(rpc, [os.path.basename(t)])
    kodi.log("profile_picture: %s <- %s (cache entries dropped: %d)" % (os.path.basename(t), os.path.basename(s), removed))
    # Kodi keeps a picture it has drawn in texture memory under its path for the rest of the session (the gate's
    # pictures never pass through Textures13; a dialog, hiding, closing the gate, an instant reload, ReloadSkin() and
    # a "|v=" suffix all left the old picture on screen in the lab, 2026-11-19). So for this session the gate draws
    # that profile from the shipped picture's own path (nikeflix.pic.p<position>, read by $VAR[NikeFlixGatePic]);
    # from the next start Kodi reads the profile's file, which already holds the new picture. Set before the gate
    # reopens: it reads the slots when it opens.
    remember(kodi, slot, picture)
    kodi.builtin("ReplaceWindow(loginscreen)")
    return True
