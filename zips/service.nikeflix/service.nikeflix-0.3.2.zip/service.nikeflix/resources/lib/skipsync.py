# -*- coding: utf-8 -*-
"""Skip Intro / Skip Recap: the NikeFlix settings page drives Umbrella's own Skip Intro.

NikeFlix plays every episode through Umbrella, and Umbrella 6.7.92 already has a maintained Skip Intro and Skip
Recap: while an episode plays it looks the times up in the free community databases IntroDB and TheIntroDB (by the
show's IMDb/TMDb id, season and episode; no account or key) and either shows a "Skip Intro" / "Skip Recap?" box in the
Play Next style NikeFlix uses (Netflix) or jumps over the segment by itself. NikeFlix does not add a second skipper
(two boxes, two seeks); it gives the choice one plain place, the NikeFlix settings page:

  Intro / Recap:  Ask (show the button)      ->  Umbrella skip.<kind>.enable = true,  skip.<kind>.auto = false
                  Always skip automatically  ->  enable = true,  auto = true
                  Off                        ->  enable = false, auto = false

Rules (per profile; Kodi stops and starts this service on every profile load):
  * a NikeFlix choice that changed since it was last applied (hidden setting `skip.applied`) is applied to Umbrella;
  * a change made in Umbrella's own settings while the NikeFlix choice did not change is adopted back into the NikeFlix
    page (Umbrella treats auto as enabled), so the two pages never disagree and the user's last change wins;
  * after a write, Umbrella's settings cache (Home property `umbrella_settings`, rebuilt by Umbrella's service on a
    settings change) is checked a few ticks later; if Umbrella's service missed the change (it starts after this one
    on a fresh profile), the key is written once more (bounded).
Never while a profile switch is pending (H3) - the caller gates on the quiesce marker and the guard state.
"""
import json

UMBRELLA = "plugin.video.umbrella"
ASK, AUTO, OFF = 0, 1, 2
KINDS = (("skip.intro", "skip.intro.enable", "skip.intro.auto"),
         ("skip.recap", "skip.recap.enable", "skip.recap.auto"))
APPLIED = "skip.applied"
DEFAULT = ASK
VERIFY_AFTER = 20.0       # seconds after a write before the Umbrella cache is checked
VERIFY_RETRIES = 3
RECHECK_UMBRELLA = 30.0   # Umbrella missing or disabled: look again this often


def mode_of(value):
    try:
        v = int(str(value).strip())
    except (TypeError, ValueError):
        return DEFAULT
    return v if v in (ASK, AUTO, OFF) else DEFAULT


def umbrella_values(mode):
    """(enable, auto) strings for Umbrella's two booleans."""
    return {ASK: ("true", "false"), AUTO: ("true", "true"), OFF: ("false", "false")}[mode]


def mode_from_umbrella(enable, auto):
    if str(auto).lower() == "true":
        return AUTO                       # Umbrella skips automatically whenever auto is on
    return ASK if str(enable).lower() == "true" else OFF


def encode(choices):
    return ",".join(str(c) for c in choices)


class SkipSync(object):
    """Decisions only; settings reads and writes go through `env` (unit-tested with a fake)."""

    def __init__(self, env):
        self.env = env
        self.seen = None           # NikeFlix choices last handled in this session
        self.verify_at = None
        self.retries = 0
        self.umbrella_retry_at = 0.0

    def _want(self, choices):
        out = {}
        for (_, enable_key, auto_key), mode in zip(KINDS, choices):
            out[enable_key], out[auto_key] = umbrella_values(mode)
        return out

    def poll(self):
        now = self.env.now()
        own = self.env.get_own_all([k for k, _, _ in KINDS] + [APPLIED])
        choices = tuple(mode_of(own.get(k)) for k, _, _ in KINDS)
        if self.verify_at is not None and now >= self.verify_at:
            self._verify(choices, now)
        if choices == self.seen:
            return
        if now < self.umbrella_retry_at:
            return
        umb = self.env.get_umbrella_all([k for _, e, a in KINDS for k in (e, a)])
        if umb is None:                                   # Umbrella missing or disabled: try again later
            self.umbrella_retry_at = now + RECHECK_UMBRELLA
            return
        names = ("ask", "always", "off")
        current = tuple(mode_from_umbrella(umb.get(e), umb.get(a)) for _, e, a in KINDS)
        applied = own.get(APPLIED) or ""
        if applied == encode(choices) and current != choices:
            # the NikeFlix choice did not change since it was applied, Umbrella's did: the user changed it there
            for (k, _, _), mode in zip(KINDS, current):
                self.env.set_own(k, str(mode))
            self.env.set_own(APPLIED, encode(current))
            self.seen = current
            self.env.log("skip intro: adopted the choice made in Umbrella's settings (intro=%s, recap=%s)" % (
                names[current[0]], names[current[1]]))
            return
        want = self._want(choices)
        changed = [k for k, v in sorted(want.items()) if umb.get(k) != v]
        for k in changed:
            self.env.set_umbrella(k, want[k])
        if applied != encode(choices):
            self.env.set_own(APPLIED, encode(choices))
        self.seen = choices
        if changed:
            self.verify_at, self.retries = now + VERIFY_AFTER, 0
            self.env.log("skip intro: Umbrella %s set from the NikeFlix setting (intro=%s, recap=%s)" % (
                ", ".join(changed), names[choices[0]], names[choices[1]]))

    def _verify(self, choices, now):
        """Umbrella's own settings cache must show the values; if its service missed the change, write once more."""
        want = self._want(choices)
        cache = self.env.umbrella_cache(list(want))
        if cache is None:                                 # no cache yet: Umbrella reads the file on its next start
            self.verify_at = None
            return
        stale = [k for k, v in sorted(want.items()) if cache.get(k) not in (None, v)]
        if not stale or self.retries >= VERIFY_RETRIES:
            if stale:
                self.env.log("skip intro: Umbrella's settings cache still differs (%s)" % ", ".join(stale), "warning")
            self.verify_at = None
            return
        self.retries += 1
        self.env.set_umbrella(stale[0], want[stale[0]])   # every write saves the file and fires Umbrella's event
        self.verify_at = now + VERIFY_AFTER
        self.env.log("skip intro: Umbrella's settings cache missed the change; written again (%d)" % self.retries)


class SkipSyncEnv(object):
    """Real Kodi side (Python 3.8). No GUI-lock calls: settings through xbmcaddon, the cache via a Home property."""

    def __init__(self, kodi):
        import xbmcaddon
        self.kodi, self.xbmcaddon = kodi, xbmcaddon

    def now(self):
        return self.kodi.now()

    def log(self, message, level="info"):
        self.kodi.log(message, level)

    def get_own_all(self, keys):
        try:
            a = self.xbmcaddon.Addon("service.nikeflix")
            return {k: a.getSetting(k) for k in keys}
        except Exception:
            return {}

    def set_own(self, key, value):
        self.xbmcaddon.Addon("service.nikeflix").setSetting(key, value)

    def get_umbrella_all(self, keys):
        try:
            a = self.xbmcaddon.Addon(UMBRELLA)            # raises when Umbrella is not installed or disabled
        except Exception:
            return None
        return {k: a.getSetting(k) for k in keys}

    def set_umbrella(self, key, value):
        self.xbmcaddon.Addon(UMBRELLA).setSetting(key, value)

    def umbrella_cache(self, keys):
        raw = self.kodi.get_prop("umbrella_settings")
        if not raw:
            return None
        try:
            d = json.loads(raw)
        except ValueError:
            return None
        return {k: d.get(k) for k in keys} if isinstance(d, dict) else None
