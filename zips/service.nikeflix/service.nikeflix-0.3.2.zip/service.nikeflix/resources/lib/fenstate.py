# -*- coding: utf-8 -*-
"""Fen 4 (plugin.video.fen, CX-LIC external) per-profile state hygiene.

Fen is never modified by NikeFlix. Fen caches per-profile state in Home-window properties, which survive
Kodi profile switches (proven in the lab, T05/I10):
  * every setting as `fen.<setting_id>` (+ `fen.<setting_id>_name`) - read BEFORE Fen's own database by
    `get_setting()`, including debrid tokens and the TMDb key;
  * `fen.addon_profile` - the profile data path Fen uses for all of its databases;
  * scrape results `fen.internal_results.<provider>` (may list personal cloud files);
  * navigation list caches `fen_<list>_{default,edited,shortcut_folder}`;
  * assorted runtime keys.
This module enumerates all of those keys, invalidates them, and validates that whatever Fen has cached
matches the ACTIVE profile's own settings database. Secret values are compared in memory only and are
never logged or returned.
"""
import os
import sqlite3

FEN_ID = "plugin.video.fen"
RUNTIME_KEYS = (
    "addon_profile", "addon_path", "addon_version", "addon_icon", "addon_fanart", "default_addon_fanart",
    "current_skin", "current_font", "window_stack", "window_loaded", "exit_params", "random_episode_history",
    "fen_online.last_sync", "active_downloads", "queued_downloads", "speed_limit", "use_viewtypes",
    "external_scraper.module", "firstrun_update", "playback.volumecheck_enabled", "playback.volumecheck_percent",
)
INTERNAL_PROVIDERS = ("easynews", "pm_cloud", "oc_cloud", "tb_cloud", "folders",
                      "folder1", "folder2", "folder3", "folder4", "folder5")
LIST_SUFFIXES = ("default", "edited", "shortcut_folder")


def fen_dir(kodi, profile_path=None):
    base = profile_path if profile_path else kodi.translate("special://profile/")
    return os.path.join(base, "addon_data", FEN_ID) + os.sep


def _ro(db_path):
    return sqlite3.connect("file:%s?mode=ro" % db_path.replace("\\", "/"), uri=True, timeout=2)


def settings_values(fen_data_dir):
    """{setting_id: value} from a profile's Fen settings DB (empty dict if Fen never ran there)."""
    db = os.path.join(fen_data_dir, "databases", "settings.db")
    if not os.path.exists(db):
        return {}
    con = _ro(db)
    try:
        return {str(k): ("" if v is None else str(v))
                for k, v in con.execute("select setting_id, setting_value from settings")}
    except sqlite3.Error:
        return {}
    finally:
        con.close()


def list_names(fen_data_dir):
    db = os.path.join(fen_data_dir, "databases", "navigator.db")
    if not os.path.exists(db):
        return set()
    con = _ro(db)
    try:
        names = set()
        for (table,) in con.execute("select name from sqlite_master where type='table'"):
            cols = [r[1] for r in con.execute("pragma table_info('%s')" % table.replace("'", "''"))]
            if "list_name" in cols:
                names.update(str(r[0]) for r in con.execute("select list_name from '%s'" % table.replace("'", "''")))
        return names
    except sqlite3.Error:
        return set()
    finally:
        con.close()


def all_keys(setting_ids, nav_lists):
    keys = set()
    for sid in setting_ids:
        keys.add("fen.%s" % sid)
        keys.add("fen.%s_name" % sid)
    keys.update("fen.%s" % k for k in RUNTIME_KEYS)
    keys.update("fen.internal_results.%s" % p for p in INTERNAL_PROVIDERS)
    for name in nav_lists:
        keys.update("fen_%s_%s" % (name, s) for s in LIST_SUFFIXES)
    return keys


def invalidate(kodi, profile_dirs):
    """Clear every Fen Home-window key derivable from the given profiles' Fen databases.

    `profile_dirs` should include the previous and the new profile, so keys that exist in only one of them
    are cleared too. Returns the number of keys cleared (no names or values are logged)."""
    setting_ids, nav = set(), set()
    for d in profile_dirs:
        if not d:
            continue
        setting_ids.update(settings_values(d).keys())
        nav.update(list_names(d))
    keys = all_keys(setting_ids, nav)
    for k in keys:
        kodi.clear_prop(k)
    return len(keys)


def validate(kodi, active_profile_path=None):
    """Fail-closed check that Fen's cached state belongs to the active profile.

    Returns (ok, reason, mismatches). `ok` is True only when:
      * `fen.addon_profile` is empty (Fen will fall back to its own profile path) or equals the active
        profile's Fen directory, and
      * no cached `fen.<setting_id>` value differs from the active profile's settings database
        (a non-empty cached value for a setting the active profile does not have also counts).
    """
    expected = fen_dir(kodi, active_profile_path)
    cached_path = kodi.get_prop("fen.addon_profile")
    if cached_path and os.path.normcase(os.path.normpath(cached_path)) != os.path.normcase(os.path.normpath(expected)):
        return False, "fen.addon_profile points at another profile", 1
    db_values = settings_values(expected)
    mismatches = 0
    for sid, value in db_values.items():
        cached = kodi.get_prop("fen.%s" % sid)
        if cached and cached != value:
            mismatches += 1
    for k in ("fen.pm.token", "fen.tb.token", "fen.oc.token", "fen.tmdb_api", "fen.easynews_password"):
        sid = k[4:]
        if sid not in db_values and kodi.get_prop(k):
            mismatches += 1
    if mismatches:
        return False, "cached Fen settings differ from the active profile", mismatches
    return True, "ok", 0
