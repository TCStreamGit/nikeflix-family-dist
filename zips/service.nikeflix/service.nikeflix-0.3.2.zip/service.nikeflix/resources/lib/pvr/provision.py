# -*- coding: utf-8 -*-
"""Deterministic, single-instance IPTV Simple settings for ONE Kodi profile (T41). Kodi-free and file-only.

Every NikeFlix profile has exactly one IPTV Simple instance, ``instance-settings-1.xml``, named "NikeFlix":

  * the build writes it DISABLED with no playlist or guide (no credentials ever ship);
  * on-device provisioning ("Accounts & Keys") rewrites the same file for the ACTIVE profile only, enabled
    only when that profile's PVR feature is on and an account was supplied for it;
  * any other instance file (Kodi's auto-created empty default, a GIPTV bridge instance) is set aside as
    ``*.nikeflix-disabled`` so there is never a duplicate or empty instance, and can be restored by hand.

The account is passed in by the caller; this module never reads a vault, another profile, or the network.
Backend choice (direct M3U vs a bridge/generated playlist, ``output`` ts/m3u8) stays open at T40: callers pass it.
"""
import os
import re
from urllib.parse import urlencode
from xml.sax.saxutils import escape

ADDON_ID = "pvr.iptvsimple"
INSTANCE_FILE = "instance-settings-1.xml"
INSTANCE_NAME = "NikeFlix"
INSTANCE_RE = re.compile(r"^instance-settings-(\d+)\.xml$")
SET_ASIDE = ".nikeflix-disabled"

# Stable, credential-free defaults (remote M3U + remote XMLTV, cached; catch-up honoured where the playlist
# declares it; no global catch-up mode, no VOD-specific handling: those are T40/T41 backend decisions).
BASE = (
    ("kodi_addon_instance_name", INSTANCE_NAME),
    ("kodi_addon_instance_enabled", "false"),
    ("m3uPathType", "1"),
    ("m3uUrl", ""),
    ("m3uCache", "true"),
    ("m3uRefreshMode", "2"),
    ("m3uRefreshHour", "4"),
    ("epgPathType", "1"),
    ("epgUrl", ""),
    ("epgCache", "true"),
    ("logoFromEpg", "1"),
    ("catchupEnabled", "true"),
    ("allChannelsCatchupMode", "0"),
    ("catchupDays", "7"),
    ("catchupOnlyOnFinishedProgrammes", "false"),
)
CREDENTIAL_KEYS = ("m3uUrl", "epgUrl")


class ProvisionError(Exception):
    """Messages never contain an account value."""


def instance_settings(pvr_on, account=None, output=None):
    """Ordered [(id, value)] for this profile's single instance.

    account: None, or {"server": "https://host[:port]", "username": ..., "password": ...} for THIS profile.
    output: required with an account ("ts" or "m3u8"; see DESIGN-PVR S8)."""
    s = dict(BASE)
    if account is not None:
        if not pvr_on:
            raise ProvisionError("PVR is OFF for this profile; refusing to store an account in it")
        for k in ("server", "username", "password"):
            if not account.get(k):
                raise ProvisionError("account is missing %s" % k)
        if output not in ("ts", "m3u8"):
            raise ProvisionError("output must be 'ts' or 'm3u8' (a T40 backend decision)")
        server = account["server"].rstrip("/")
        if not re.match(r"^https?://[^/\s?#]+$", server):
            raise ProvisionError("server must be scheme://host[:port]")
        q = urlencode({"username": account["username"], "password": account["password"]})
        s["m3uUrl"] = "%s/get.php?%s&type=m3u_plus&output=%s" % (server, q, output)
        s["epgUrl"] = "%s/xmltv.php?%s" % (server, q)
        s["kodi_addon_instance_enabled"] = "true"
    return [(k, s[k]) for k, _ in BASE]


def render(settings):
    body = "".join('    <setting id="%s">%s</setting>\n' % (k, escape(v)) for k, v in settings)
    return '<settings version="2">\n%s</settings>\n' % body


def _atomic(path, text):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8", newline="\n") as f:
        f.write(text)
    os.replace(tmp, path)


def apply(profile_addon_data, pvr_on, account=None, output=None):
    """Write the one instance for this profile; set aside every other instance file. Returns a report (no values)."""
    d = os.path.join(profile_addon_data, ADDON_ID)
    os.makedirs(d, exist_ok=True)
    text = render(instance_settings(pvr_on, account, output))
    set_aside = []
    for name in sorted(os.listdir(d)):
        m = INSTANCE_RE.match(name)
        if m and name != INSTANCE_FILE:
            target = os.path.join(d, name + SET_ASIDE)
            if os.path.exists(target):
                os.remove(target)
            os.replace(os.path.join(d, name), target)
            set_aside.append(name)
    _atomic(os.path.join(d, INSTANCE_FILE), text)
    return {"instance": INSTANCE_FILE, "enabled": account is not None, "pvr_on": bool(pvr_on), "set_aside": set_aside}


def inspect(profile_addon_data):
    """Credential-free summary of a profile's IPTV Simple instances."""
    d = os.path.join(profile_addon_data, ADDON_ID)
    out = {"instances": [], "set_aside": []}
    if not os.path.isdir(d):
        return out
    for name in sorted(os.listdir(d)):
        if INSTANCE_RE.match(name):
            txt = open(os.path.join(d, name), encoding="utf-8").read()
            vals = dict(re.findall(r'<setting id="([^"]+)"[^>]*>([^<]*)</setting>', txt))
            out["instances"].append({"file": name, "name": vals.get("kodi_addon_instance_name", ""),
                                     "enabled": vals.get("kodi_addon_instance_enabled") == "true",
                                     "has_playlist": bool(vals.get("m3uUrl") or vals.get("m3uPath")),
                                     "has_guide": bool(vals.get("epgUrl") or vals.get("epgPath"))})
        elif name.endswith(SET_ASIDE):
            out["set_aside"].append(name)
    return out
