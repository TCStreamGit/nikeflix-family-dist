# -*- coding: utf-8 -*-
"""The Apple TV interface sounds, installed automatically (NikeFlix 4.1.2, Tanner 2026-11-20: "make sure the apple tv
can be automatic and auto work").

The builds set `lookandfeel.soundskin` to `resource.uisounds.appletv` (the 4.1 preview's sounds). The pack is on
Kodi's official repository but declares no licence, so NikeFlix never ships it (LICENSE-AUDIT.md). Until 4.1.2 Kodi
installed it only after the viewer said yes in Settings > Appearance: Kodi's `InstallAddon` always asks (Kodi 21.3
AddonBuiltins.cpp: InstallModal with a Yes/No prompt; there is no silent switch and no JSON-RPC install).

This module does what Kodi's installer does, without the prompt, on the device:
  1. In a settled profile, DELAY_S after the profile is ready, when the profile's sound skin is the Apple TV pack and
     the pack is not installed.
  2. Kodi's official repository index (the same URL as Kodi's own repository.xbmc.org add-on) gives the version and
     path. The zip and its published sha256 come from the same mirror, and the zip must match the sha256.
  3. The zip must hold only `resource.uisounds.appletv/...`. Its addon.xml must be that id, require nothing but
     `kodi.resource`, and declare only the uisounds and metadata extension points (a sound pack carries no code).
     The size is capped at MAX_BYTES.
  4. It is extracted into special://home/addons (shared by every profile), and `UpdateLocalAddons` registers it.
     Then JSON-RPC enables it, and the sound skin is set away and back, so Kodi loads the sounds now.
A failure (no network, a checksum mismatch, a pack that changed shape) leaves everything as it was and logs the
reason. It is tried again after RETRY_S, at most TRIES times per profile session.

Whose choice: Kodi itself rewrites `lookandfeel.soundskin` to its own pack at start-up when the chosen pack is not
installed (lab 2026-11-20: "Unknown sounds addon 'resource.uisounds.appletv'. Setting default sounds."), so that
setting cannot tell a viewer's choice from Kodi's fallback. NikeFlix keeps the profile's choice in
Skin.String(nikeflix.sounds): empty (the build's default) or "appletv" means the Apple TV sounds, "kodi" means Kodi's
own, written by NikeFlix Settings > Appearance > Interface sounds. With Apple TV chosen, the pack is installed when
missing, and the sound skin is set back to it when Kodi had fallen back.
"""
import gzip
import hashlib
import io
import json
import os
import shutil
import threading
import time
import xml.etree.ElementTree as ET
import zipfile

PACK = "resource.uisounds.appletv"
SOUND_SETTING = "lookandfeel.soundskin"
KODI_PACK = "resource.uisounds.kodi"
CHOICE = "nikeflix.sounds"          # Skin.String: "" / "appletv" -> Apple TV, "kodi" -> Kodi's own
# Kodi 21.3's repository.xbmc.org add-on (special://xbmc/addons/repository.xbmc.org/addon.xml)
INDEX_URL = "https://mirrors.kodi.tv/addons/omega/addons.xml.gz"
DATADIR = "https://mirrors.kodi.tv/addons/omega"
MAX_BYTES = 5 * 1024 * 1024
DELAY_S = 30.0
RETRY_S = 3600.0
TRIES = 3
ALLOWED_POINTS = {"kodi.resource.uisounds", "kodi.addon.metadata", "xbmc.addon.metadata"}


class PackError(Exception):
    """A reason the pack was not installed (message: a short code, never a URL with secrets - there are none)."""


def parse_index(gz_bytes, aid=PACK):
    """(version, relative zip path) of `aid` in a Kodi repository addons.xml.gz."""
    try:
        root = ET.fromstring(gzip.decompress(gz_bytes))
    except Exception:
        raise PackError("index_unreadable")
    for a in root.findall("addon"):
        if a.get("id") != aid:
            continue
        version = a.get("version") or ""
        path = None
        for ext in a.findall("extension"):
            p = ext.find("path")
            if p is not None and (p.text or "").strip():
                path = p.text.strip()
        if not version or not path:
            raise PackError("index_entry_incomplete")
        if path != "%s/%s-%s.zip" % (aid, aid, version):
            raise PackError("index_path_unexpected")
        return version, path
    raise PackError("not_in_index")


def check_sha256(data, published):
    """The repository's `<zip>.sha256` holds the hex digest, optionally followed by the file name."""
    want = (published or "").strip().split()[0].lower() if (published or "").strip() else ""
    if len(want) != 64:
        raise PackError("sha256_unreadable")
    if hashlib.sha256(data).hexdigest() != want:
        raise PackError("sha256_mismatch")
    return want


def check_zip(data, aid=PACK):
    """Members and addon.xml of the pack zip; returns the version in its addon.xml."""
    try:
        zf = zipfile.ZipFile(io.BytesIO(data))
    except Exception:
        raise PackError("zip_unreadable")
    total = 0
    for info in zf.infolist():
        name = info.filename.replace("\\", "/")
        if not name.startswith(aid + "/") or ".." in name.split("/") or name.startswith("/"):
            raise PackError("zip_member_outside_pack")
        if name.lower().endswith((".py", ".pyc", ".so", ".dll", ".dylib", ".exe", ".sh")):
            raise PackError("zip_member_not_a_sound_pack")
        total += info.file_size
    if total > MAX_BYTES:
        raise PackError("zip_too_large")
    try:
        root = ET.fromstring(zf.read(aid + "/addon.xml"))
    except KeyError:
        raise PackError("addon_xml_missing")
    except Exception:
        raise PackError("addon_xml_unreadable")
    if root.get("id") != aid:
        raise PackError("addon_id_mismatch")
    imports = {i.get("addon") for i in root.findall("requires/import")}
    if not imports <= {"kodi.resource"}:
        raise PackError("addon_requires_more")
    points = {e.get("point") for e in root.findall("extension")}
    if "kodi.resource.uisounds" not in points or not points <= ALLOWED_POINTS:
        raise PackError("addon_not_a_sound_pack")
    return root.get("version") or ""


def install(env, aid=PACK):
    """Download, verify, extract, register, enable and load the pack. Raises PackError with the reason."""
    version, path = parse_index(env.http_get(INDEX_URL, 20 * 1024 * 1024), aid)
    url = "%s/%s" % (DATADIR, path)
    data = env.http_get(url, MAX_BYTES)
    check_sha256(data, env.http_get(url + ".sha256", 4096).decode("ascii", "replace"))
    if check_zip(data, aid) != version:
        raise PackError("zip_version_mismatch")
    addons = env.addons_dir()
    stage = os.path.join(addons, ".%s.nikeflix-tmp" % aid)
    dest = os.path.join(addons, aid)
    shutil.rmtree(stage, ignore_errors=True)
    zipfile.ZipFile(io.BytesIO(data)).extractall(stage)
    if os.path.isdir(dest):
        shutil.rmtree(dest, ignore_errors=True)
    os.replace(os.path.join(stage, aid), dest)
    shutil.rmtree(stage, ignore_errors=True)
    env.update_local_addons()
    for _ in range(60):
        if env.known(aid):
            break
        if env.wait(0.5):
            raise PackError("aborted")
    else:
        raise PackError("not_registered")
    env.enable(aid)
    if not env.installed(aid):
        raise PackError("not_enabled")
    use_pack(env, aid)
    return version


def use_pack(env, aid=PACK):
    """Make Kodi load `aid` now. Kodi loads a sound skin when the setting changes, so a setting that already names it
    (but was loaded as Kodi's default while the pack was missing) goes away and back."""
    if env.get_setting(SOUND_SETTING) == aid:
        env.set_setting(SOUND_SETTING, KODI_PACK)
        env.wait(0.5)
    env.set_setting(SOUND_SETTING, aid)


def wants_apple_tv(choice):
    return (choice or "").strip().lower() in ("", "appletv")


class SoundPack(object):
    """Polled by service.py in a settled profile. The network work runs on its own thread."""

    def __init__(self, env, guard_ready):
        self.env, self.guard_ready = env, guard_ready
        self.ready_since = None
        self.next_try = 0.0
        self.tries = 0
        self.thread = None
        self.result = None
        self.done = False

    def due(self):
        if self.done or (self.thread is not None and self.thread.is_alive()):
            return False
        now = self.env.clock()
        if not self.guard_ready():
            self.ready_since = None
            return False
        if self.ready_since is None:
            self.ready_since = now
        return now - self.ready_since >= DELAY_S and now >= self.next_try

    def poll(self):
        if self.thread is not None and not self.thread.is_alive():
            self.thread = None
            self._finish()
        if not self.due():
            return None
        if not wants_apple_tv(self.env.choice()):
            self.done = True          # Kodi's own sounds chosen in NikeFlix Settings
            return None
        if self.env.installed(PACK):
            self.done = True
            if self.env.get_setting(SOUND_SETTING) != PACK:
                use_pack(self.env)    # Kodi fell back to its own sounds while the pack was missing
                self.env.log("Apple TV sounds set again (Kodi had fallen back to its own)")
                return "restored"
            return None
        self.tries += 1
        self.thread = threading.Thread(target=self._work, name="nikeflix-soundpack")
        self.thread.daemon = True
        self.thread.start()
        return "started"

    def _work(self):
        try:
            self.result = ("ok", install(self.env))
        except PackError as exc:
            self.result = ("failed", str(exc))
        except Exception as exc:     # network or file errors: retried later
            self.result = ("failed", type(exc).__name__)

    def _finish(self):
        state, detail = self.result or ("failed", "no_result")
        if state == "ok":
            self.env.log("Apple TV sounds installed from Kodi's repository (version %s)" % detail)
            self.done = True
        else:
            self.env.log("Apple TV sounds not installed: %s (try %d of %d)" % (detail, self.tries, TRIES), "warning")
            self.next_try = self.env.clock() + RETRY_S
            if self.tries >= TRIES:
                self.done = True

    def end(self):
        if self.thread is not None:
            self.thread.join(2.0)


class SoundPackEnv(object):
    def __init__(self, kodi):
        self.kodi = kodi

    def clock(self):
        return time.time()

    def wait(self, seconds):
        return self.kodi.wait(seconds)

    def log(self, msg, level="info"):
        self.kodi.log(msg, level)

    def addons_dir(self):
        return self.kodi.translate("special://home/addons")

    def http_get(self, url, limit):
        try:
            from urllib.request import Request, urlopen
        except ImportError:  # pragma: no cover
            from urllib2 import Request, urlopen
        req = Request(url, headers={"User-Agent": "Kodi NikeFlix service.nikeflix"})
        with urlopen(req, timeout=20) as r:
            data = r.read(limit + 1)
        if len(data) > limit:
            raise PackError("download_too_large")
        return data

    def _rpc(self, method, params):
        import xbmc
        out = json.loads(xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": method, "params": params})) or "{}")
        return out.get("result"), out.get("error")

    def known(self, aid):
        res, err = self._rpc("Addons.GetAddonDetails", {"addonid": aid, "properties": ["enabled"]})
        return err is None and bool(res and res.get("addon"))

    def installed(self, aid):
        res, err = self._rpc("Addons.GetAddonDetails", {"addonid": aid, "properties": ["enabled"]})
        return err is None and bool(res and (res.get("addon") or {}).get("enabled"))

    def enable(self, aid):
        self._rpc("Addons.SetAddonEnabled", {"addonid": aid, "enabled": True})

    def update_local_addons(self):
        self.kodi.builtin("UpdateLocalAddons")

    def get_setting(self, key):
        res, _ = self._rpc("Settings.GetSettingValue", {"setting": key})
        return (res or {}).get("value")

    def choice(self):
        import xbmc
        return xbmc.getInfoLabel("Skin.String(%s)" % CHOICE)

    def set_setting(self, key, value):
        self._rpc("Settings.SetSettingValue", {"setting": key, "value": value})
