# -*- coding: utf-8 -*-
"""Origin watchdog: compare the installed add-ons with the shipped expectation file and report drift.

Inputs (all read-only):
  * Addons33.db (`installed` origin/enabled, `update_rules`), opened with a read-only sqlite URI;
  * addon.xml of every add-on folder in special://home/addons and special://xbmc/addons (versions, repositories);
  * Fen 4 (CX-LIC): its addon.xml version, the zip sha256 recorded by the NikeFlix Fen installer receipt (or the
    zip in Kodi's packages cache), and `update.action` in every profile's Fen settings database;
  * the Kodi settings addons.updatemode / general.addonupdates of the active profile.

`collect()` gathers a snapshot, `evaluate()` is pure and returns drift records. Records hold codes, add-on ids,
versions, origins and profile *indexes* only: never setting values other than Fen's `update.action`, never
profile names or paths, never tokens.
"""
import hashlib
import json
import os
import sqlite3
import xml.etree.ElementTree as ET

try:
    from urllib.parse import quote
except ImportError:  # pragma: no cover
    from urllib import quote

from resources.lib.origin import versions

SCHEMA_EXPECT = "nikeflix.origin-expectations/1"
SCHEMA_REPORT = "nikeflix.origin-report/1"
PLATFORMS = ("windows", "android", "tvos")
TBD = "TBD (I5)"
FEN_ID = "plugin.video.fen"
OFFICIAL = "repository.xbmc.org"
SEVERITIES = ("error", "warning", "info")
FEN_RECEIPT = "special://masterprofile/addon_data/service.nikeflix/fen-install.json"
UPDATER_RECEIPTS = "special://masterprofile/addon_data/service.nikeflix/origin-updater-receipts.json"

# Drift codes (docs/design/ORIGIN-WATCHDOG.md section 3)
ORIGIN_WRONG = "origin_wrong"
RULE_MISSING = "rule_missing"
RULE_UNEXPECTED = "rule_unexpected"
VERSION_UNEXPECTED = "version_unexpected"
NOT_INSTALLED = "not_installed"
DISABLED_UNEXPECTED = "disabled_unexpected"
SHOULD_BE_DISABLED = "should_be_disabled"
THIRD_PARTY_REPOSITORY = "third_party_repository"
KODI_SETTING = "kodi_setting"
FEN_VERSION = "fen_version"
FEN_SHA256 = "fen_sha256"
FEN_UNVERIFIED = "fen_unverified"
FEN_UPDATE_ACTION = "fen_update_action"
FEN_NOT_INSTALLED = "fen_not_installed"
CERTIFICATION_PENDING = "certification_pending"
ADDONS_DB_UNREADABLE = "addons_db_unreadable"
EXPECTATIONS_INVALID = "expectations_invalid"


# ------------------------------------------------------------------ expectation file
def expectations_path(edition):
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "expectations.%s.json" % edition)


def load_expectations(path):
    with open(path, encoding="utf-8") as fh:
        exp = json.load(fh)
    if exp.get("schema") != SCHEMA_EXPECT:
        raise ValueError("unsupported expectation schema")
    return exp


def detect_edition(addon_versions):
    return "family" if "repository.NikeFlixFamily" in addon_versions else "regular"


# ------------------------------------------------------------------ readers (read-only)
def ro_connect(path):
    uri = "file:%s?mode=ro" % quote(path.replace("\\", "/"), safe="/:")
    return sqlite3.connect(uri, uri=True, timeout=2)


def read_addons_db(path):
    """{"installed": {id: {"enabled": bool, "origin": str}}, "rules": {id: [int]}} or None if unreadable."""
    if not path or not os.path.isfile(path):
        return None
    try:
        con = ro_connect(path)
    except sqlite3.Error:
        return None
    try:
        inst = {str(a): {"enabled": bool(e), "origin": o or ""} for a, e, o in con.execute(
            "SELECT addonID, enabled, origin FROM installed")}
        rules = {}
        for a, r in con.execute("SELECT addonID, updateRule FROM update_rules ORDER BY addonID, updateRule"):
            rules.setdefault(str(a), []).append(int(r))
        return {"installed": inst, "rules": rules}
    except sqlite3.Error:
        return None
    finally:
        con.close()


def read_addon_xml(path):
    """(id, version, extension points) of an addon.xml, or None."""
    try:
        root = ET.parse(path).getroot()
    except (ET.ParseError, OSError):
        return None
    if root.tag != "addon" or not root.get("id"):
        return None
    points = sorted({e.get("point") for e in root.findall("extension") if e.get("point")})
    return root.get("id"), root.get("version") or "", points


def scan_addons(dirs):
    """{id: {"version", "points", "home"}} from addon folders; the first directory (home) wins over bundled."""
    out = {}
    for n, base in enumerate(dirs):
        if not base or not os.path.isdir(base):
            continue
        for name in sorted(os.listdir(base)):
            if name.startswith("."):
                continue
            meta = read_addon_xml(os.path.join(base, name, "addon.xml"))
            if not meta or meta[0] != name or name in out:
                continue
            out[name] = {"version": meta[1], "points": meta[2], "home": n == 0}
    return out


def profile_dirs(env):
    """Translated profile folders: index 0 is the master profile, then profiles.xml order."""
    master = env.translate("special://masterprofile/")
    dirs = [master]
    try:
        root = ET.parse(os.path.join(master, "profiles.xml")).getroot()
    except (ET.ParseError, OSError):
        return dirs
    for p in root.findall("profile"):
        d = (p.findtext("directory") or "").strip()
        if not d:
            continue
        path = env.translate(d)
        if not os.path.isabs(path):  # profiles.xml stores "profiles/<name>/" relative to the master profile
            path = os.path.join(master, path)
        if os.path.normcase(os.path.normpath(path)) != os.path.normcase(os.path.normpath(master)):
            dirs.append(path)
    return dirs


def fen_update_action(profile_dir):
    """Fen's stored update.action in one profile, or None when Fen has no settings database there."""
    db = os.path.join(profile_dir, "addon_data", FEN_ID, "databases", "settings.db")
    if not os.path.isfile(db):
        return None
    try:
        con = ro_connect(db)
    except sqlite3.Error:
        return None
    try:
        row = con.execute("SELECT setting_value FROM settings WHERE setting_id=?", ("update.action",)).fetchone()
        return None if row is None or row[0] is None else str(row[0])
    except sqlite3.Error:
        return None
    finally:
        con.close()


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def read_json(path, default):
    try:
        with open(path, encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return default


def fen_zip_sha256(env, version):
    """(sha256, source) of the installed Fen zip: the NikeFlix installer receipt, else Kodi's packages cache."""
    rec = read_json(env.translate(FEN_RECEIPT), {})
    if isinstance(rec, dict) and rec.get("id") == FEN_ID and rec.get("version") == version and rec.get("sha256"):
        return str(rec["sha256"]).lower(), "receipt"
    pkg = os.path.join(env.translate("special://home/addons/packages/"), "%s-%s.zip" % (FEN_ID, version))
    if os.path.isfile(pkg):
        return sha256_file(pkg), "packages"
    return None, None


def collect(env, exp):
    """Snapshot of the device state relevant to `exp` (read-only)."""
    addons = scan_addons([env.translate("special://home/addons/"), env.translate("special://xbmc/addons/")])
    db_path = env.translate("special://database/" + exp["kodi"]["db"])
    if not os.path.isfile(db_path):
        db_path = os.path.join(env.translate("special://masterprofile/"), "Database", exp["kodi"]["db"])
    snap = {
        "platform": env.platform(),
        "addons": addons,
        "db": read_addons_db(db_path),
        "settings": {k: env.kodi_setting(k) for k in sorted(exp.get("settings") or {})},
        "receipts": read_json(env.translate(UPDATER_RECEIPTS), {}),
        "fen": None,
    }
    if exp.get("fen") and FEN_ID in addons:
        ver = addons[FEN_ID]["version"]
        sha, src = fen_zip_sha256(env, ver)
        snap["fen"] = {"version": ver, "sha256": sha, "sha256_source": src,
                       "profiles": [fen_update_action(d) for d in profile_dirs(env)]}
    return snap


# ------------------------------------------------------------------ evaluation (pure)
def _drift(out, code, severity, addon=None, **detail):
    rec = {"code": code, "severity": severity}
    if addon:
        rec["id"] = addon
    if detail:
        rec["detail"] = detail
    out.append(rec)


def _origin_label(origin, exp):
    if origin == exp["kodi"]["origin_system"]:
        return "system"
    return origin if origin else "(empty)"


def _is_repository(aid, meta):
    return aid.startswith("repository.") or "xbmc.addon.repository" in ((meta or {}).get("points") or [])


def evaluate(exp, snap):
    """Drift records for a snapshot. No false positives on a device that matches the seed exactly."""
    out = []
    addons, db = snap.get("addons") or {}, snap.get("db")
    inst = (db or {}).get("installed") or {}
    rules = (db or {}).get("rules") or {}
    receipts = snap.get("receipts") if isinstance(snap.get("receipts"), dict) else {}
    plat = snap.get("platform")
    if db is None:
        _drift(out, ADDONS_DB_UNREADABLE, "error", db=exp["kodi"]["db"])

    for m in exp.get("managed") or []:
        aid = m["id"]
        meta, row = addons.get(aid), inst.get(aid)
        if not meta and not row:
            _drift(out, NOT_INSTALLED, "warning", aid, cls="M")
            continue
        origin = (row or {}).get("origin", "")
        if db is not None:
            if origin != m["origin"]:
                _drift(out, ORIGIN_WRONG, "error", aid, expected=m["origin"], found=_origin_label(origin, exp))
            elif row is not None and not row["enabled"]:
                _drift(out, DISABLED_UNEXPECTED, "warning", aid)
            have = rules.get(aid, [])
            if m.get("rule") == 1 and 1 not in have:
                _drift(out, RULE_MISSING, "warning", aid, policy=m.get("policy"))
            elif m.get("rule") is None and have:
                _drift(out, RULE_UNEXPECTED, "warning", aid, rules=have)
        if meta and m.get("version"):
            want = m["version"]
            rec = receipts.get(aid) if isinstance(receipts.get(aid), dict) else None
            if rec and rec.get("version") and versions.compare(rec["version"], want) > 0:
                want = rec["version"]  # applied by the NikeFlix pinned updater
            found = meta["version"]
            if found != want:
                newer = versions.compare(found, want) > 0
                ours = origin == m["origin"]
                if newer and ours and m.get("policy") == "nikeflix-auto":
                    continue  # a later NikeFlix release from the NikeFlix repository
                upstream = newer and not ours
                _drift(out, VERSION_UNEXPECTED, "error" if upstream else "warning", aid, expected=want,
                       found=found, direction="newer" if newer else "older",
                       cause="upstream_install" if upstream else "unknown")

    pending = []
    for e in exp.get("exceptions") or []:
        aid = e["id"]
        meta, row = addons.get(aid), inst.get(aid)
        if not meta and not row:
            if aid == FEN_ID:
                _drift(out, FEN_NOT_INSTALLED, "info", aid)
            elif not e.get("optional"):
                _drift(out, NOT_INSTALLED, "warning", aid, cls=e["class"])
            continue
        if db is not None:
            if row is not None and row["origin"] not in e["origins"]:
                _drift(out, ORIGIN_WRONG, "error", aid, cls=e["class"],
                       expected=[_origin_label(o, exp) for o in e["origins"]],
                       found=_origin_label(row["origin"], exp))
            if "rule1" in e["control"] and 1 not in rules.get(aid, []):
                _drift(out, RULE_MISSING, "warning", aid, cls=e["class"])
            if e.get("disabled") and row is not None and row["enabled"]:
                _drift(out, SHOULD_BE_DISABLED, "warning", aid, cls=e["class"])
        if not meta or aid == FEN_ID:
            continue
        cert = (e.get("certified") or {}).get(plat)
        if plat not in PLATFORMS or not cert or cert == TBD:
            pending.append(aid)
            continue
        ok = [cert] + list((e.get("accepted") or {}).get(plat) or [])
        if meta["version"] not in ok:
            newer = versions.compare(meta["version"], cert) > 0
            _drift(out, VERSION_UNEXPECTED, "info" if e["class"] == "CX-CORE" else "warning", aid, cls=e["class"],
                   expected=cert, found=meta["version"], direction="newer" if newer else "older")
    if pending:
        _drift(out, CERTIFICATION_PENDING, "info", platform=plat or "unknown", count=len(pending))

    fen, fs = exp.get("fen"), snap.get("fen")
    if fen and fs:
        if fs.get("version") != fen["version"]:
            _drift(out, FEN_VERSION, "error", FEN_ID, expected=fen["version"], found=fs.get("version"))
        elif not fs.get("sha256"):
            _drift(out, FEN_UNVERIFIED, "warning", FEN_ID)
        elif fs["sha256"].lower() != fen["sha256"].lower():
            _drift(out, FEN_SHA256, "error", FEN_ID, source=fs.get("sha256_source"))
        want = (fen.get("required_settings") or {}).get("update.action")
        if want is not None:
            for idx, val in enumerate(fs.get("profiles") or []):
                if val is None:
                    _drift(out, FEN_UPDATE_ACTION, "warning", FEN_ID, profile=idx, found="unset", expected=want)
                elif val != want:
                    _drift(out, FEN_UPDATE_ACTION, "error", FEN_ID, profile=idx, found=val, expected=want)

    allowed = set(exp.get("allowed_repositories") or [])
    for aid in sorted(set(addons) | set(inst)):
        if aid in allowed or not _is_repository(aid, addons.get(aid)):
            continue
        enabled = bool((inst.get(aid) or {}).get("enabled"))
        _drift(out, THIRD_PARTY_REPOSITORY, "error" if enabled else "warning", aid, enabled=enabled)

    for key, want in sorted((exp.get("settings") or {}).items()):
        found = (snap.get("settings") or {}).get(key)
        if found is None:
            continue
        try:
            found_i = int(found)
        except (TypeError, ValueError):
            found_i = None
        if found_i != want:
            _drift(out, KODI_SETTING, "error" if key == "addons.updatemode" else "warning",
                   setting=key, expected=want, found=found_i)
    return out


def summarize(drift):
    counts = {s: 0 for s in SEVERITIES}
    for d in drift:
        counts[d["severity"]] = counts.get(d["severity"], 0) + 1
    return counts


def fingerprint(drift):
    """Stable digest of the actionable drift (error + warning), used to report changes only once."""
    keys = sorted(json.dumps(d, sort_keys=True) for d in drift if d["severity"] != "info")
    return hashlib.sha256("\n".join(keys).encode("utf-8")).hexdigest()[:16]


def report(exp, snap, drift, checked):
    return {
        "schema": SCHEMA_REPORT,
        "checked": round(checked, 1),
        "edition": exp.get("edition"),
        "platform": snap.get("platform"),
        "summary": summarize(drift),
        "fingerprint": fingerprint(drift),
        "drift": drift,
    }
