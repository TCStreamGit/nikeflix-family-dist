# -*- coding: utf-8 -*-
"""Kodi add-on version ordering (same semantics as tools/nfmanage/kodiver.py, a port of AddonVersion.cpp).

Format ``[epoch:]upstream[~revision]``; ``~revision`` is a pre-release; digit runs compare numerically.
Kept as a copy because add-on code cannot import host tooling (Kodi Python 3.8).
"""


def _split(v):
    v = (v or "").strip() or "0.0.0"
    epoch = 0
    if ":" in v:
        e, v = v.split(":", 1)
        try:
            epoch = int(e)
        except ValueError:
            epoch = 0
    rev = ""
    if "~" in v:
        v, rev = v.split("~", 1)
    return epoch, v, rev


def _num(s, i):
    j = i
    while j < len(s) and s[j].isdigit():
        j += 1
    return int(s[i:j]), j


def _component(a, b):
    i = j = 0
    while i < len(a) and j < len(b):
        while i < len(a) and j < len(b) and not a[i].isdigit() and not b[j].isdigit():
            if a[i] != b[j]:
                if a[i] == "~":
                    return -1
                if b[j] == "~":
                    return 1
                return -1 if a[i] < b[j] else 1
            i += 1
            j += 1
        if i < len(a) and j < len(b) and (not a[i].isdigit() or not b[j].isdigit()):
            if a[i] == "~":
                return -1
            if b[j] == "~":
                return 1
            return -1 if a[i].isdigit() else 1
        if i < len(a) and j < len(b):
            na, i = _num(a, i)
            nb, j = _num(b, j)
            if na != nb:
                return -1 if na < nb else 1
    if i >= len(a) and j >= len(b):
        return 0
    if i >= len(a):
        return 1 if b[j] == "~" else -1
    return -1 if a[i] == "~" else 1


def compare(a, b):
    """-1, 0 or 1 like Kodi's AddonVersion ordering."""
    ea, ua, ra = _split(a)
    eb, ub, rb = _split(b)
    if ea != eb:
        return -1 if ea < eb else 1
    c = _component(ua, ub)
    if c:
        return c
    if not ra and rb:
        return 1
    if ra and not rb:
        return -1
    return _component(ra, rb)
