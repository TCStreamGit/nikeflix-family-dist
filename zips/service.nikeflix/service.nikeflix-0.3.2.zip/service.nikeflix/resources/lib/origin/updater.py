# -*- coding: utf-8 -*-
"""NikeFlix pinned-add-on updater (policy `pin`, docs/design/UPDATE-ORIGIN.md 2.2; T25 skeleton).

The 40 M add-ons that repository.xbmc.org also serves carry update rule 1, so Kodi never auto-installs them
from any source. NikeFlix updates them itself:

  1. read the NikeFlix-published manifest (`pinned-updates.json` in the edition dist repo);
  2. for each eligible, installed add-on with a newer manifest version: download the ZIP into
     special://temp, check its size and sha256;
  3. validate the archive (single root `<id>/`, no absolute or parent paths, no links, `addon.xml` id and
     version match the manifest, bounded uncompressed size);
  4. extract into a work folder beside the add-on (same volume), then swap folders with two renames
     (old -> work/old/<id>, new -> <id>); roll back on any error; delete the work folder;
  5. run `UpdateLocalAddons`. Kodi keeps the NikeFlix origin and update rule 1 (T24 lab check 20). The updater
     never writes Addons33.db;
  6. record a receipt (id, version, sha256) for the watchdog; skins and services need a Kodi restart, which is
     reported to Diagnostics (and notified only when the user turned notifications on).

Hard gates: the add-on setting `origin.updater.enabled` (default OFF) AND `updater.channel_published` in the
shipped expectation file (false until T63/T72). Fen 4 (`plugin.video.fen`, CX-LIC), every certified exception
and service.nikeflix itself are never touched.
"""
import hashlib
import json
import os
import re
import shutil
import stat
import uuid
import zipfile
import xml.etree.ElementTree as ET

from resources.lib.origin import versions

MANIFEST_SCHEMA = "nikeflix.pinned-updates/1"
SETTING_ENABLED = "origin.updater.enabled"
ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]*$")
SHA_RE = re.compile(r"^[0-9a-f]{64}$")
VER_RE = re.compile(r"^[A-Za-z0-9.+~:_-]{1,64}$")
WORK_PREFIX = ".nikeflix-update-"
RESTART_POINTS = ("xbmc.gui.skin", "xbmc.service")
MAX_UNPACKED = 512 * 1024 * 1024
MAX_MEMBERS = 20000
RECEIPTS = "special://masterprofile/addon_data/service.nikeflix/origin-updater-receipts.json"
BUSY_PROP = "nikeflix.origin.updater.busy"


class UpdateError(Exception):
    pass


def enabled(env, exp):
    """(allowed, reason). Both gates must be open; any doubt keeps the updater off."""
    if str(env.setting(SETTING_ENABLED)).lower() != "true":
        return False, "disabled by setting (default)"
    up = (exp or {}).get("updater") or {}
    if up.get("channel_published") is not True:
        return False, "NikeFlix update channel not published"
    if not str(up.get("manifest_url", "")).startswith("https://"):
        return False, "no https manifest url"
    return True, "ok"


def validate_manifest(man, exp):
    """List of acceptable entries [{id, version, sha256, url, size}] and a list of rejection reasons."""
    up = exp["updater"]
    errs, ok = [], []
    if not isinstance(man, dict) or man.get("schema") != MANIFEST_SCHEMA:
        return [], ["manifest schema"]
    if man.get("edition") != exp.get("edition"):
        return [], ["manifest edition"]
    eligible, never = set(up.get("eligible") or []), set(up.get("never_touch") or [])
    prefix, cap = up["allowed_url_prefix"], int(up.get("max_zip_bytes") or 0)
    seen = set()
    for e in man.get("addons") or []:
        if not isinstance(e, dict):
            errs.append("entry is not an object")
            continue
        aid, ver = str(e.get("id", "")), str(e.get("version", ""))
        sha, url = str(e.get("sha256", "")).lower(), str(e.get("url", ""))
        if not ID_RE.match(aid) or aid in seen:
            errs.append("bad or duplicate id")
            continue
        seen.add(aid)
        if aid in never or aid not in eligible:
            errs.append("%s: not eligible for the pinned updater" % aid)
            continue
        if not VER_RE.match(ver) or not SHA_RE.match(sha):
            errs.append("%s: bad version or sha256" % aid)
            continue
        if url != "%s%s/%s-%s.zip" % (prefix, aid, aid, ver) or not prefix.startswith("https://"):
            errs.append("%s: url outside the NikeFlix dist channel" % aid)
            continue
        size = e.get("size")
        if size is not None and (not isinstance(size, int) or size <= 0 or (cap and size > cap)):
            errs.append("%s: bad size" % aid)
            continue
        ok.append({"id": aid, "version": ver, "sha256": sha, "url": url, "size": size})
    return ok, errs


def _sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def _inside(base, path):
    base = os.path.normcase(os.path.realpath(base))
    path = os.path.normcase(os.path.realpath(path))
    return path == base or path.startswith(base.rstrip(os.sep) + os.sep)


def check_archive(zip_path, aid, version):
    """Validate the ZIP before anything is written next to the add-on. Returns the extension points."""
    try:
        zf = zipfile.ZipFile(zip_path)
    except (zipfile.BadZipfile, OSError):
        raise UpdateError("not a zip archive")
    with zf:
        infos = zf.infolist()
        if not infos or len(infos) > MAX_MEMBERS:
            raise UpdateError("empty or oversized archive")
        total = 0
        for i in infos:
            name = i.filename
            parts = name.split("/")
            if "\\" in name or ":" in name or name.startswith("/") or ".." in parts or parts[0] != aid:
                raise UpdateError("unsafe member path")
            if stat.S_ISLNK(i.external_attr >> 16):
                raise UpdateError("links are not allowed")
            total += i.file_size
            if total > MAX_UNPACKED:
                raise UpdateError("archive expands too much")
        try:
            root = ET.fromstring(zf.read(aid + "/addon.xml"))
        except (KeyError, ET.ParseError):
            raise UpdateError("addon.xml missing or invalid")
        if root.get("id") != aid or root.get("version") != version:
            raise UpdateError("addon.xml id/version differ from the manifest")
        return sorted({e.get("point") for e in root.findall("extension") if e.get("point")})


def _extract(zip_path, dest_root):
    """Extract a validated archive below dest_root, re-checking every resolved path."""
    with zipfile.ZipFile(zip_path) as zf:
        for i in zf.infolist():
            target = os.path.join(dest_root, *i.filename.split("/"))
            if not _inside(dest_root, target):
                raise UpdateError("unsafe member path")
            if i.filename.endswith("/"):
                if not os.path.isdir(target):
                    os.makedirs(target)
                continue
            parent = os.path.dirname(target)
            if not os.path.isdir(parent):
                os.makedirs(parent)
            with zf.open(i) as src, open(target, "wb") as dst:
                shutil.copyfileobj(src, dst)


def swap_in(addons_root, aid, zip_path):
    """Atomically replace addons_root/<aid> with the archive content (two renames on one volume)."""
    if not ID_RE.match(aid):
        raise UpdateError("bad id")
    target = os.path.join(addons_root, aid)
    if not os.path.isdir(target) or not _inside(addons_root, target):
        raise UpdateError("add-on is not installed in the home add-ons folder")
    work = os.path.join(addons_root, WORK_PREFIX + aid + "-" + uuid.uuid4().hex[:8])
    new_root, old_root = os.path.join(work, "new"), os.path.join(work, "old")
    os.makedirs(new_root)
    os.makedirs(old_root)
    try:
        _extract(zip_path, new_root)
        staged = os.path.join(new_root, aid)
        if not os.path.isfile(os.path.join(staged, "addon.xml")):
            raise UpdateError("staged add-on has no addon.xml")
        backup = os.path.join(old_root, aid)
        os.rename(target, backup)
        try:
            os.rename(staged, target)
        except OSError:
            os.rename(backup, target)
            raise
    finally:
        if os.path.basename(work).startswith(WORK_PREFIX) and _inside(addons_root, work):
            shutil.rmtree(work, ignore_errors=True)


def _write_json(path, data):
    d = os.path.dirname(path)
    if not os.path.isdir(d):
        os.makedirs(d)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=1, sort_keys=True)
    os.replace(tmp, path)


class Updater(object):
    def __init__(self, env, exp, installed_versions, diag=None):
        self.env, self.exp = env, exp
        self.installed = installed_versions  # {id: version} from the home add-ons folder
        self.diag = diag or (lambda event, **kw: None)

    def _fetch_manifest(self, tmp):
        path = os.path.join(tmp, "pinned-updates.json")
        self.env.http_get(self.exp["updater"]["manifest_url"], path, 1024 * 1024)
        with open(path, encoding="utf-8") as fh:
            return json.load(fh)

    def plan(self, manifest):
        entries, errs = validate_manifest(manifest, self.exp)
        todo = []
        for e in entries:
            cur = self.installed.get(e["id"])
            if cur and versions.compare(e["version"], cur) > 0:
                todo.append(e)
        return todo, errs

    def run(self, manifest=None):
        ok, reason = enabled(self.env, self.exp)
        if not ok:
            return {"ran": False, "reason": reason, "updated": [], "rejected": [], "restart_required": []}
        if self.env.get_prop(BUSY_PROP):
            return {"ran": False, "reason": "already running", "updated": [], "rejected": [],
                    "restart_required": []}
        self.env.set_prop(BUSY_PROP, "1")
        tmp = os.path.join(self.env.translate("special://temp/"), "nikeflix-origin-" + uuid.uuid4().hex[:8])
        result = {"ran": True, "reason": "ok", "updated": [], "rejected": [], "restart_required": []}
        try:
            os.makedirs(tmp)
            if manifest is None:
                manifest = self._fetch_manifest(tmp)
            todo, errs = self.plan(manifest)
            result["rejected"].extend(errs)
            addons_root = self.env.translate("special://home/addons/")
            receipts_path = self.env.translate(RECEIPTS)
            for e in todo:
                if self.env.aborted():
                    break
                try:
                    points = self._apply(e, tmp, addons_root)
                except (UpdateError, OSError, ValueError) as exc:
                    result["rejected"].append("%s: %s" % (e["id"], exc))
                    self.diag("updater_rejected", id=e["id"], version=e["version"], reason=str(exc))
                    continue
                result["updated"].append({"id": e["id"], "version": e["version"]})
                rec = _read_receipts(receipts_path)
                rec[e["id"]] = {"version": e["version"], "sha256": e["sha256"], "t": round(self.env.now(), 1)}
                _write_json(receipts_path, rec)
                if any(p in RESTART_POINTS for p in points):
                    result["restart_required"].append(e["id"])
                self.diag("updater_applied", id=e["id"], version=e["version"])
            if result["updated"]:
                self.env.builtin("UpdateLocalAddons")
            if result["restart_required"]:
                self.env.set_prop("nikeflix.origin.restart_required", "1")
                self.diag("restart_required", ids=result["restart_required"])
        finally:
            shutil.rmtree(tmp, ignore_errors=True)
            self.env.set_prop(BUSY_PROP, "")
        return result

    def _apply(self, e, tmp, addons_root):
        aid = e["id"]
        if aid in set(self.exp["updater"].get("never_touch") or []):
            raise UpdateError("never touched by the updater")
        zpath = os.path.join(tmp, "%s-%s.zip" % (aid, e["version"]))
        cap = int(self.exp["updater"].get("max_zip_bytes") or 0) or (64 * 1024 * 1024)
        size = self.env.http_get(e["url"], zpath, cap)
        if e.get("size") is not None and size != e["size"]:
            raise UpdateError("size mismatch")
        if _sha256(zpath) != e["sha256"]:
            raise UpdateError("sha256 mismatch")
        points = check_archive(zpath, aid, e["version"])
        swap_in(addons_root, aid, zpath)
        return points


def _read_receipts(path):
    try:
        with open(path, encoding="utf-8") as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}
