# -*- coding: utf-8 -*-
"""Scheduling and Diagnostics output for the origin watchdog (called from the service dispatcher).

* First check: `start_delay` seconds after the service starts AND once the profile guard reports `ready`
  (Kodi has finished its add-on startup sync by then). Then every `origin.watchdog.interval` hours.
* Output goes to Diagnostics only: the active profile's `addon_data/service.nikeflix/origin-watchdog.json`
  (latest report), `origin-diagnostics.jsonl` (changes only, size-capped) and Home-window properties
  `nikeflix.origin.*` for the skin's Diagnostics page. Quiet Mode default: no popup. A notification is shown
  only when the user turned `origin.watchdog.notify` on, and only when the actionable drift changes.
* Every failure is contained: the watchdog must never break the service loop.
"""
import json
import os

from resources.lib.origin import updater as updater_mod
from resources.lib.origin import watchdog

S_ENABLED = "origin.watchdog.enabled"
S_INTERVAL = "origin.watchdog.interval"
S_NOTIFY = "origin.watchdog.notify"
P_STATUS = "nikeflix.origin.status"         # ok | drift | error | disabled
P_COUNT = "nikeflix.origin.drift"           # errors + warnings
P_CHECKED = "nikeflix.origin.checked"       # epoch seconds of the last check
P_SUMMARY = "nikeflix.origin.summary"       # e.g. "origin_wrong:1, rule_missing:2"
DIAG_DIR = "special://profile/addon_data/service.nikeflix/"
DIAG_MAX = 256 * 1024


def _bool(value, default):
    v = str(value or "").strip().lower()
    if v in ("true", "1"):
        return True
    if v in ("false", "0"):
        return False
    return default


def _hours(value, default=6, lo=1, hi=168):
    try:
        h = int(float(value))
    except (TypeError, ValueError):
        return default
    return max(lo, min(hi, h))


class OriginModule(object):
    SETTINGS = (S_ENABLED, S_INTERVAL, S_NOTIFY)

    def __init__(self, env, guard_ready, start_delay=20.0, expectations=None):
        self.env = env
        self.guard_ready = guard_ready
        self.next_due = env.now() + start_delay
        self._exp = expectations
        self._last_fp = None

    # ---- scheduling -----------------------------------------------------------------------------------
    def is_due(self):
        """Cheap check the service loop uses before starting a background tick."""
        return self.env.now() >= self.next_due and self.guard_ready()

    def tick(self):
        """Call about once a second (the service runs it in a background thread when `is_due()`)."""
        if not self.is_due():
            return None
        interval = _hours(self.env.setting(S_INTERVAL)) * 3600.0
        self.next_due = self.env.now() + interval
        try:
            return self.run_once()
        except Exception as exc:  # never break the service
            self.env.set_prop(P_STATUS, "error")
            self.env.log("watchdog failed: %s" % type(exc).__name__, "warning")
            return None

    def schedule_next(self, env):
        """Service thread: book the next check before a background run starts."""
        self.next_due = env.now() + _hours(env.setting(S_INTERVAL)) * 3600.0

    # ---- background path (see worker.py): compute is pure, publish runs on the service thread -----------
    def compute(self, fenv):
        """Worker thread. `fenv` is a FrozenEnv: no Kodi API, no writes. Returns a result dict."""
        if not _bool(fenv.setting(S_ENABLED), True):
            return {"disabled": True}
        exp = self.expectations(fenv)
        fenv.check()
        snap = watchdog.collect(fenv, exp)
        fenv.check()
        drift = watchdog.evaluate(exp, snap)
        rep = watchdog.report(exp, snap, drift, fenv.now())
        rep["updater"] = {"ran": False, "reason": "updater is not run on the background path (T63)"}
        return {"report": rep, "notify": _bool(fenv.setting(S_NOTIFY), False)}

    def publish(self, env, result):
        """Service thread; the runner has already validated the profile identity."""
        if result.get("disabled"):
            env.set_prop(P_STATUS, "disabled")
            return
        self._publish(result["report"], env=env, notify=result.get("notify", False))

    def publish_error(self, env, error_name):
        env.set_prop(P_STATUS, "error")
        env.log("watchdog failed: %s" % error_name, "warning")

    # ---- one check --------------------------------------------------------------------------------------
    def expectations(self, env=None):
        env = env or self.env
        if self._exp is None:
            home = env.translate("special://home/addons/")
            family = os.path.isdir(os.path.join(home, "repository.NikeFlixFamily"))
            self._exp = watchdog.load_expectations(watchdog.expectations_path("family" if family else "regular"))
        return self._exp

    def run_once(self):
        if not _bool(self.env.setting(S_ENABLED), True):
            self.env.set_prop(P_STATUS, "disabled")
            return None
        exp = self.expectations()
        snap = watchdog.collect(self.env, exp)
        drift = watchdog.evaluate(exp, snap)
        rep = watchdog.report(exp, snap, drift, self.env.now())
        self._publish(rep)
        up = self.run_updater(exp, snap)
        if up is not None:
            rep["updater"] = up
        return rep

    def run_updater(self, exp, snap):
        ok, reason = updater_mod.enabled(self.env, exp)
        if not ok:
            return {"ran": False, "reason": reason}
        installed = {i: m["version"] for i, m in (snap.get("addons") or {}).items() if m.get("home")}
        res = updater_mod.Updater(self.env, exp, installed, diag=self._diag).run()
        if res.get("restart_required") and _bool(self.env.setting(S_NOTIFY), False):
            self.env.notify("NikeFlix", "Restart Kodi to finish add-on updates")
        return res

    # ---- Diagnostics ----------------------------------------------------------------------------------
    def _publish(self, rep, env=None, notify=None):
        env = env or self.env
        counts = rep["summary"]
        actionable = counts.get("error", 0) + counts.get("warning", 0)
        codes = {}
        for d in rep["drift"]:
            if d["severity"] != "info":
                codes[d["code"]] = codes.get(d["code"], 0) + 1
        env.set_prop(P_STATUS, "drift" if actionable else "ok")
        env.set_prop(P_COUNT, str(actionable))
        env.set_prop(P_CHECKED, str(int(rep["checked"])))
        env.set_prop(P_SUMMARY, ", ".join("%s:%d" % kv for kv in sorted(codes.items())))
        self._write_report(rep, env)
        if rep["fingerprint"] != self._last_fp:
            self._last_fp = rep["fingerprint"]
            self._diag("watchdog_drift" if actionable else "watchdog_clean", env=env, summary=counts,
                       codes=codes, fingerprint=rep["fingerprint"])
            env.log("watchdog %s %s" % ("drift" if actionable else "clean", json.dumps(codes, sort_keys=True)),
                    "warning" if actionable else "info")
            do_notify = _bool(env.setting(S_NOTIFY), False) if notify is None else notify
            if actionable and do_notify:
                env.notify("NikeFlix", "Add-on update control drift: see Diagnostics")

    def _dir(self, env=None):
        d = (env or self.env).translate(DIAG_DIR)
        if not os.path.isdir(d):
            os.makedirs(d)
        return d

    def _write_report(self, rep, env=None):
        try:
            path = os.path.join(self._dir(env), "origin-watchdog.json")
            tmp = path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump(rep, fh, indent=1, sort_keys=True)
            os.replace(tmp, path)
        except Exception:
            pass

    def _diag(self, event, env=None, **kw):
        env = env or self.env
        try:
            path = os.path.join(self._dir(env), "origin-diagnostics.jsonl")
            if os.path.isfile(path) and os.path.getsize(path) > DIAG_MAX:
                with open(path, encoding="utf-8") as fh:
                    keep = fh.readlines()[-200:]
                with open(path, "w", encoding="utf-8") as fh:
                    fh.writelines(keep)
            rec = {"t": round(env.now(), 1), "event": event}
            rec.update(kw)
            with open(path, "a", encoding="utf-8") as fh:
                fh.write(json.dumps(rec, sort_keys=True) + "\n")
        except Exception:
            pass
