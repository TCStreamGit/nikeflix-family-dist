# -*- coding: utf-8 -*-
"""Origin watchdog and NikeFlix pinned-add-on updater (plan task T25; module reserved by T31).

Read-only towards Kodi's databases. Reports drift to Diagnostics only. The updater is off by default and never
touches Fen 4 (CX-LIC). Design: docs/design/ORIGIN-WATCHDOG.md.
"""
