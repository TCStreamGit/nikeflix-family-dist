# -*- coding: utf-8 -*-
"""Profile-safe background execution of the origin watchdog (2026-10-18 lifecycle review, Finding 1).

Contract
  * CAPTURE (service thread): profile identity (guard epoch, profile token, profile path), every translated
    `special://` prefix the check needs, and the add-on settings it reads. This is the only place Kodi APIs
    are touched for a check.
  * COMPUTE (worker thread): pure Python on the captured data via `FrozenEnv`. No Kodi API (no xbmc,
    xbmcgui, xbmcaddon, xbmcvfs), no writes of any kind, cooperative cancellation and a hard deadline.
  * PUBLISH (service thread): a result is applied (Home-window properties, Diagnostics files in the active
    profile, optional notification, buffered log lines) only if the identity captured at launch still matches
    the active profile. Stale results are dropped, never applied to another profile.
  * END (service thread): cancel, bounded join, drop anything still pending.
The updater (network download + add-on swap) is NOT run on this background path; T63 reuses this
capture/compute/publish pattern for it before it can be enabled.
"""
import os
import queue
import threading
import time

from resources.lib.origin.env import detect_platform, read_guisetting

PREFIXES = ("special://home/", "special://xbmc/", "special://masterprofile/", "special://profile/",
            "special://database/", "special://temp/")


class NotOnWorker(RuntimeError):
    """Raised when worker code tries an operation reserved for the service thread."""


class FrozenEnv(object):
    """Worker-side environment built from captured values. Makes no Kodi API call."""

    def __init__(self, paths, settings, deadline, cancel):
        self._paths = dict(paths)
        self._settings = dict(settings)
        self._deadline = deadline
        self._cancel = cancel
        self.logs = []

    def translate(self, path):
        for pre in sorted(self._paths, key=len, reverse=True):
            if path.startswith(pre):
                rest = path[len(pre):]
                return os.path.join(self._paths[pre], rest) if rest else self._paths[pre]
        return path

    def platform(self):
        return detect_platform()

    def setting(self, key):
        return self._settings.get(key, "")

    def kodi_setting(self, key):
        return read_guisetting(self.translate("special://profile/guisettings.xml"), key)

    def now(self):
        return time.time()

    def log(self, message, level="info"):
        self.logs.append((message, level))

    def check(self):
        """Cooperative cancellation point for long work."""
        if self._cancel.is_set() or time.time() > self._deadline:
            raise Cancelled()

    # Service-thread-only operations: refuse loudly so a regression is caught by tests.
    def set_prop(self, key, value):
        raise NotOnWorker("set_prop")

    def get_prop(self, key):
        raise NotOnWorker("get_prop")

    def notify(self, heading, message):
        raise NotOnWorker("notify")

    def builtin(self, command):
        raise NotOnWorker("builtin")


class Cancelled(Exception):
    pass


class Job(object):
    def __init__(self, identity, env, cancel):
        self.identity = identity
        self.env = env
        self.cancel = cancel


class OriginRunner(object):
    """Owns the watchdog worker for one service (= one profile) lifetime. All methods run on the service thread."""

    def __init__(self, module, kodi_env, identity_fn, deadline_s=60.0, join_s=0.5, name="nikeflix-origin"):
        self.name = name
        self.m = module                 # runner.OriginModule (or any module with the same interface)
        self.env = kodi_env             # real OriginEnv (service thread only)
        self.identity_fn = identity_fn  # () -> (epoch, token, profile_path)
        self.deadline_s = deadline_s
        self.join_s = join_s
        self._q = queue.Queue(maxsize=1)
        self._thread = None
        self._job = None
        self.stats = {"started": 0, "published": 0, "dropped_stale": 0, "timeouts": 0, "errors": 0}

    def _capture(self):
        identity = self.identity_fn()
        paths = {p: self.env.translate(p) for p in PREFIXES}
        settings = {k: self.env.setting(k) for k in self.m.SETTINGS}
        cancel = threading.Event()
        fe = FrozenEnv(paths, settings, time.time() + self.deadline_s, cancel)
        return Job(identity, fe, cancel)

    def _run(self, job):
        try:
            result = self.m.compute(job.env)
            payload = ("ok", result)
        except Cancelled:
            payload = ("cancelled", None)
        except Exception as exc:
            payload = ("error", type(exc).__name__)
        try:
            self._q.put_nowait((job, payload))
        except queue.Full:
            pass

    def poll(self):
        """Call once per service-loop iteration."""
        self._drain()
        if self._thread is not None and self._thread.is_alive():
            if self._job is not None and time.time() > self._job.env._deadline and not self._job.cancel.is_set():
                self._job.cancel.set()
                self.stats["timeouts"] += 1
            return
        if self.m.is_due():
            self.m.schedule_next(self.env)
            self._job = self._capture()
            self._thread = threading.Thread(target=self._run, args=(self._job,), name=self.name)
            self._thread.daemon = True
            self._thread.start()
            self.stats["started"] += 1

    def _drain(self):
        try:
            job, (status, value) = self._q.get_nowait()
        except queue.Empty:
            return
        if job.identity != self.identity_fn():
            self.stats["dropped_stale"] += 1
            return
        for message, level in job.env.logs:
            self.env.log(message, level)
        if status == "ok" and value is not None:
            self.m.publish(self.env, value)
            self.stats["published"] += 1
        elif status == "error":
            self.stats["errors"] += 1
            self.m.publish_error(self.env, value)

    def end(self):
        """Profile is ending: cancel, bounded join, and never apply anything that arrives afterwards."""
        if self._job is not None:
            self._job.cancel.set()
        if self._thread is not None:
            self._thread.join(self.join_s)
        try:
            while True:
                self._q.get_nowait()
                self.stats["dropped_stale"] += 1
        except queue.Empty:
            pass
        return not (self._thread is not None and self._thread.is_alive())
