# -*- coding: utf-8 -*-
"""RunScript(service.nikeflix,action=play,media_type=<movie|episode>,tmdb_id=..,[imdb,title,year,
tvshowtitle,season,episode,premiered]) - the route TMDb Helper's NikeFlix player calls.

RunScript(service.nikeflix,action=intro_check) - Skin NikeFlix `Startup.xml` on every profile load (T51).

RunScript(service.nikeflix,action=trakt_account) - power-menu "Trakt Account" (T12 spec; broker screen is T33)."""
from resources.lib.kodi import Kodi
from resources.lib.playback import DEFAULTS, Wrapper, diag_writer, parse_args
from resources.lib.profileguard import Guard


def main(argv):
    args = parse_args(argv)
    kodi = Kodi()
    action = args.pop("action", "")
    if action == "intro_check":  # T51: intro once per Kodi process
        from resources.lib.session import intro_check
        intro_check(kodi)
        return
    if action == "trakt_account":
        from resources.lib.trakt_account import show
        show(kodi)
        return
    if action == "play":
        tuning = {}
        for key in DEFAULTS:  # optional numeric tuning (used by lab tests); never credentials
            if key in args:
                try:
                    tuning[key] = float(args.pop(key))
                except ValueError:
                    args.pop(key, None)
        guard = Guard(kodi)
        Wrapper(kodi, guard, settings=tuning, diag=diag_writer(kodi, guard.active_path())).run(args)
