"""Christmas Edition add-on artwork (P05 decision 9, Tanner 2026-11-17).

The skin switches its own look by date (Includes.xml NikeFlixChristmas). Kodi shows the wizard's and the
repository's icon and fanart from the files in their add-on folders, so this module keeps those files on the right
variant: each of those add-ons ships both, `resources/media/christmas/` and `resources/media/usual/`. From December 1
through December 26 the Christmas pair is copied over `icon.png` / `fanart.jpg`, from December 27 the usual pair, and
Kodi's cached thumbnails of the swapped files are dropped so the new art shows at once. No device has to update.

Checked every 10 minutes in a settled profile (an add-on update mid-season puts its usual art back; the next check
fixes it). A file that cannot be replaced now (locked) is skipped and tried again at the next check.
"""
import datetime
import os
import time

TARGETS = ("plugin.program.nikeflixwizard", "repository.NikeFlix",
           "plugin.program.NikeFlixFamilyWizard", "repository.NikeFlixFamily")
FILES = ("icon.png", "fanart.jpg")
CHECK_EVERY_S = 600


def season(today):
    return "christmas" if today.month == 12 and 1 <= today.day <= 26 else "usual"


def _same(a, b):
    if os.path.getsize(a) != os.path.getsize(b):
        return False
    with open(a, "rb") as fa, open(b, "rb") as fb:
        return fa.read() == fb.read()


def apply(addons_dir, today, errors=None):
    """Copy the season's variant over each target's icon/fanart where it differs. Returns the replaced paths;
    files that could not be replaced are appended to `errors` (path, exception name) and left as they were."""
    which = season(today)
    changed = []
    for aid in TARGETS:
        base = os.path.join(addons_dir, aid)
        for name in FILES:
            src = os.path.join(base, "resources", "media", which, name)
            dst = os.path.join(base, name)
            tmp = dst + ".nikeflix-tmp"
            try:
                if not (os.path.isfile(src) and os.path.isfile(dst)) or _same(src, dst):
                    continue
                with open(src, "rb") as fs, open(tmp, "wb") as ft:
                    ft.write(fs.read())
                os.replace(tmp, dst)
                changed.append(dst)
            except (OSError, IOError) as exc:
                if errors is not None:
                    errors.append((dst, type(exc).__name__))
                try:
                    if os.path.exists(tmp):
                        os.remove(tmp)
                except OSError:
                    pass
    return changed


def cached_matches(url, aid, name):
    """True when a texture-cache URL is exactly <...>/addons/<aid>/<name> (not a longer add-on id)."""
    u = (url or "").replace("\\", "/")
    return u.endswith("/%s/%s" % (aid, name))


class SeasonalArt(object):
    def __init__(self, env):
        self.env = env
        self.next_check = 0.0

    def poll(self):
        now = self.env.clock()
        if now < self.next_check:
            return None
        self.next_check = now + CHECK_EVERY_S
        today = self.env.today()
        errors = []
        changed = apply(self.env.addons_dir(), today, errors)
        removed = 0
        if changed:
            try:
                removed = self.env.drop_cached(changed)
            except Exception as exc:   # the files are right; Kodi re-checks changed local images by itself
                self.env.log("seasonal art: cached thumbnails not dropped (%s)" % type(exc).__name__)
            self.env.log("seasonal art: %s look for %d file(s), %d cached thumbnail(s) dropped" % (
                season(today), len(changed), removed))
        if errors:
            self.env.log("seasonal art: %d file(s) busy, retried at the next check" % len(errors))
        return changed


class SeasonalArtEnv(object):
    def __init__(self, kodi):
        self.kodi = kodi

    def clock(self):
        return time.time()

    def today(self):
        return datetime.date.today()

    def addons_dir(self):
        return self.kodi.translate("special://home/addons")

    def log(self, msg):
        self.kodi.log(msg)

    def drop_cached(self, paths):
        """Textures.GetTextures / Textures.RemoveTexture for the swapped files (Kodi re-reads them on next view)."""
        import json
        import xbmc
        removed = 0
        for path in paths:
            aid, name = os.path.basename(os.path.dirname(path)), os.path.basename(path)
            q = {"jsonrpc": "2.0", "id": 1, "method": "Textures.GetTextures", "params": {
                "properties": ["url"], "filter": {"field": "url", "operator": "contains", "value": aid}}}
            res = json.loads(xbmc.executeJSONRPC(json.dumps(q)) or "{}")
            for tex in (res.get("result") or {}).get("textures") or []:
                if cached_matches(tex.get("url"), aid, name):
                    xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 2, "method": "Textures.RemoveTexture",
                                                    "params": {"textureid": tex["textureid"]}}))
                    removed += 1
        return removed
