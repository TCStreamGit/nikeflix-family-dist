# -*- coding: utf-8 -*-
"""service.nikeflix entry: owns the per-profile guard lifecycle.

Kodi stops every add-on service of the outgoing profile and starts them again in the incoming profile, so
`begin_profile()` runs on each profile load and `end_profile()` on each unload or shutdown."""
from resources.lib.kodi import Kodi
from resources.lib.profileguard import P_STATE, P_TOKEN, Guard


def _origin_runner(kodi, guard):
    """T25 origin watchdog behind the profile-safe runner (capture/compute/publish). Failures leave it out."""
    try:
        from resources.lib.origin.env import OriginEnv
        from resources.lib.origin.runner import OriginModule
        from resources.lib.origin.worker import OriginRunner
        env = OriginEnv(kodi)
        module = OriginModule(env, lambda: kodi.get_prop(P_STATE) == "ready")

        def identity():
            return (guard.epoch(), kodi.get_prop(P_TOKEN), guard.active_path())
        return OriginRunner(module, env, identity)
    except Exception:
        return None


def _weather_runner(kodi, guard):
    """T44 Open-Meteo self-repair behind the same profile-safe runner. Network lookups use 2 s timeouts, so the
    2.5 s join at profile end covers one in-flight request (Kodi kills a service after 5 s)."""
    try:
        from resources.lib.origin.worker import OriginRunner
        from resources.lib.weather.repair import WeatherEnv, WeatherModule
        env = WeatherEnv(kodi)
        module = WeatherModule(env, lambda: kodi.get_prop(P_STATE) == "ready")

        def identity():
            return (guard.epoch(), kodi.get_prop(P_TOKEN), guard.active_path())
        return OriginRunner(module, env, identity, deadline_s=20.0, join_s=2.5, name="nikeflix-weather")
    except Exception:
        return None


def _repo_update(kodi):
    """Deferred repository check (general.addonupdates = 2 shipped; see repoupdate.py). Failures leave it out."""
    try:
        from resources.lib.repoupdate import RepoUpdate, RepoUpdateEnv
        return RepoUpdate(RepoUpdateEnv(kodi), lambda: kodi.get_prop(P_STATE) == "ready")
    except Exception:
        return None


def _skip_sync(kodi):
    """Skip Intro / Recap: the NikeFlix setting drives Umbrella's own Skip Intro (skipsync.py). Failures leave it out."""
    try:
        from resources.lib.skipsync import SkipSync, SkipSyncEnv
        return SkipSync(SkipSyncEnv(kodi))
    except Exception:
        return None


def _trakt_sync(kodi):
    """Trakt Hub (traktbroker.py): publish, push, refresh and repair the profile's one Trakt sign-in. Failures leave it out."""
    try:
        from resources.lib.traktbroker import Broker, TraktEnv, TraktSync
        return TraktSync(Broker(TraktEnv(kodi)))
    except Exception as exc:
        kodi.log("trakt sync not started: %s" % type(exc).__name__, "warning")
        return None


def _seasonal(kodi):
    """Christmas Edition add-on artwork by date (seasonal.py). Failures leave it out."""
    try:
        from resources.lib.seasonal import SeasonalArt, SeasonalArtEnv
        return SeasonalArt(SeasonalArtEnv(kodi))
    except Exception:
        return None


def _soundpack(kodi):
    """NikeFlix 4.1.2: the Apple TV sounds installed from Kodi's repository without a prompt (soundpack.py)."""
    try:
        from resources.lib.soundpack import SoundPack, SoundPackEnv
        return SoundPack(SoundPackEnv(kodi), lambda: kodi.get_prop(P_STATE) == "ready")
    except Exception:
        return None


def _ytkeys(kodi):
    """NikeFlix 4.1.3: YouTube keys from the household's NikeFlix PC, applied to every profile (ytkeys.py)."""
    try:
        from resources.lib.ytkeys import YtKeys, YtKeysEnv
        return YtKeys(YtKeysEnv(kodi), lambda: kodi.get_prop(P_STATE) == "ready")
    except Exception:
        return None


def _rows(kodi):
    """NikeFlix 4.1 rows on Home, Shows and Movies (rows/rotate.py). Failures leave it out."""
    try:
        from resources.lib.rows.rotate import Rows, RowsEnv
        return Rows(RowsEnv(kodi), kodi)
    except Exception:
        return None


def _live(kodi):
    """NikeFlix 4.1 Live sports scores (sports/live.py). Failures leave it out."""
    try:
        from resources.lib.sports.live import LiveScores
        return LiveScores(kodi)
    except Exception:
        return None


def run():
    kodi = Kodi()
    requests = None
    try:   # H3: drop a leftover request; listen for the skin's NotifyAll(service.nikeflix,profile_switch)
        from resources.lib.session.quiesce import SwitchRequests, clear_stale
        clear_stale(kodi)
        requests = SwitchRequests(started_at=kodi.now())
    except Exception:
        pass
    guard = Guard(kodi)
    guard.begin_profile()
    trakt = _trakt_sync(kodi)
    if trakt is not None:
        try:   # first thing in the profile: shared token properties cleared, this profile's broker state published
            trakt.begin_profile()
        except Exception as exc:
            kodi.log("trakt sync disabled at start: %s" % type(exc).__name__, "warning")
            trakt = None
    runners = [(n, r) for n, r in (("origin", _origin_runner(kodi, guard)), ("weather", _weather_runner(kodi, guard)))
               if r is not None]
    repo = _repo_update(kodi)
    skip = _skip_sync(kodi)
    seasonal = _seasonal(kodi)
    rows = _rows(kodi)
    live = _live(kodi)
    sounds = _soundpack(kodi)
    ytkeys = _ytkeys(kodi)
    try:
        while not kodi.wait(1.0):
            if requests is not None:
                try:
                    report = requests.serve(kodi, hold=repo.switch_hold if repo is not None else None)
                    if report and (report.get("aborted") or report.get("outcome") == "aborted"):
                        # H3: Kodi is stopping this service mid-switch - start no background work now
                        # (lab: workers first polled after the stop request were still joining at the 5-s kill)
                        continue
                except Exception as exc:  # never break the guard lifecycle
                    kodi.log("profile switch request failed: %s" % type(exc).__name__, "warning")
            if repo is not None and kodi.get_prop("nikeflix.quiesce"):
                repo.pause()   # H3: a switch is pending or the login screen is up - no GUI call, no window
            elif repo is not None:
                try:
                    repo.poll()
                except Exception as exc:
                    kodi.log("repository check disabled after error: %s" % type(exc).__name__, "warning")
                    try:
                        repo.end()
                    except Exception:
                        pass
                    repo = None
            if skip is not None and not kodi.get_prop("nikeflix.quiesce") and kodi.get_prop(P_STATE) == "ready":
                try:   # only in a settled profile, never while a switch is pending (H3)
                    skip.poll()
                except Exception as exc:  # never break the guard lifecycle
                    kodi.log("skip intro sync disabled after error: %s" % type(exc).__name__, "warning")
                    skip = None
            if trakt is not None and not kodi.get_prop("nikeflix.quiesce") and kodi.get_prop(P_STATE) == "ready":
                try:   # Trakt refresh/repair only in a settled profile (H3: no network work while a switch is pending)
                    trakt.poll()
                except Exception as exc:  # never break the guard lifecycle
                    kodi.log("trakt sync disabled after error: %s" % type(exc).__name__, "warning")
                    trakt = None
            if seasonal is not None and not kodi.get_prop("nikeflix.quiesce") and kodi.get_prop(P_STATE) == "ready":
                try:   # once a day, only in a settled profile (H3)
                    seasonal.poll()
                except Exception as exc:  # never break the guard lifecycle
                    kodi.log("seasonal art disabled after error: %s" % type(exc).__name__, "warning")
                    seasonal = None
            if rows is not None and not kodi.get_prop("nikeflix.quiesce") and kodi.get_prop(P_STATE) == "ready":
                try:   # writes the rows' skin strings on its own thread; only in a settled profile (H3)
                    rows.poll()
                except Exception as exc:  # never break the guard lifecycle
                    kodi.log("rows disabled after error: %s" % type(exc).__name__, "warning")
                    rows = None
            if live is not None and not kodi.get_prop("nikeflix.quiesce") and kodi.get_prop(P_STATE) == "ready":
                try:   # scores on their own thread, about once a minute, only in a settled profile (H3)
                    live.poll()
                except Exception as exc:  # never break the guard lifecycle
                    kodi.log("live sports disabled after error: %s" % type(exc).__name__, "warning")
                    live = None
            if sounds is not None and not kodi.get_prop("nikeflix.quiesce") and kodi.get_prop(P_STATE) == "ready":
                try:   # downloads on its own thread, only in a settled profile (H3)
                    sounds.poll()
                except Exception as exc:  # never break the guard lifecycle
                    kodi.log("sound pack install disabled after error: %s" % type(exc).__name__, "warning")
                    sounds = None
            if ytkeys is not None and not kodi.get_prop("nikeflix.quiesce") and kodi.get_prop(P_STATE) == "ready":
                try:   # listens on its own thread; applies stored keys only in a settled profile (H3)
                    ytkeys.poll()
                except Exception as exc:  # never break the guard lifecycle
                    kodi.log("youtube keys disabled after error: %s" % type(exc).__name__, "warning")
                    ytkeys = None
            for item in list(runners):
                name, runner = item
                try:
                    runner.poll()
                except Exception as exc:  # a background module must never break the guard lifecycle
                    kodi.log("%s worker disabled after error: %s" % (name, type(exc).__name__), "warning")
                    runners.remove(item)
    finally:
        if ytkeys is not None:
            try:
                ytkeys.end()
            except Exception:
                pass
        if sounds is not None:
            try:
                sounds.end()
            except Exception:
                pass
        if rows is not None:
            try:
                rows.end()
            except Exception:
                pass
        if live is not None:
            try:
                live.end()
            except Exception:
                pass
        if trakt is not None:
            try:
                trakt.end_profile()   # no shared token property survives into the next profile
            except Exception:
                pass
        if repo is not None:
            try:
                repo.end()
            except Exception:
                pass
        for name, runner in runners:
            try:
                drained = runner.end()
                kodi.log("%s worker %s at profile end %s" % (
                    name, "stopped" if drained else "still finishing (results dropped)", runner.stats))
            except Exception:
                pass
        guard.end_profile()
