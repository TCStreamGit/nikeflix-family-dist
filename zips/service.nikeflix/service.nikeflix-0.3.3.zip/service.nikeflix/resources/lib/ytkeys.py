# -*- coding: utf-8 -*-
"""YouTube keys from the household's NikeFlix PC (NikeFlix 4.1.3, Tanner 2026-11-20: "Yes, build 4.1.3" - automatic
YouTube key delivery).

The YouTube add-on needs its own API key and OAuth client. Without them, any call it makes to YouTube's Data API
stops on its "key.requirement" dialog. NikeFlix keeps the keys in the PC's vault (`household.youtube.youtube.api.*`)
and never in a build: the dist repositories are public.

Delivery is a two-message exchange on the home network, started by the PC (`tools/nfprovision youtube`):
  PC -> device  "NIKEFLIX-KEYS/1 HELLO <nonce>"            to UDP PORT, unicast, from a private address
  device -> PC  "NIKEFLIX-KEYS/1 NEED youtube <fp> <nonce>"  the device's key fingerprint, or "none"
  PC -> device  "NIKEFLIX-KEYS/1 KEYS <json>"               only when the fingerprints differ
  device -> PC  "NIKEFLIX-KEYS/1 OK <fp>"
The device answers only private (RFC 1918 / loopback) addresses. It accepts KEYS only from an address that sent a
HELLO in the last HELLO_TTL_S, and it never sends a key. Keys are stored once per device
(special://masterprofile/addon_data/service.nikeflix/household-keys.json). They are applied to the YouTube add-on of
whichever profile is in use: Kodi keeps add-on settings per profile, so each profile gets them when it next starts.
Nothing here logs a key.
"""
import hashlib
import ipaddress
import json
import os
import socket
import threading
import time

PORT = 50181
MAGIC = "NIKEFLIX-KEYS/1"
HELLO_TTL_S = 60.0
DELAY_S = 15.0
CHECK_EVERY_S = 600.0
YT = "plugin.video.youtube"
FIELDS = (("api_key", "youtube.api.key"), ("api_id", "youtube.api.id"), ("api_secret", "youtube.api.secret"))
STORE = "special://masterprofile/addon_data/service.nikeflix/household-keys.json"


def fingerprint(keys):
    if not keys or not all(keys.get(f) for f, _ in FIELDS):
        return "none"
    return hashlib.sha256("|".join(keys[f] for f, _ in FIELDS).encode("utf-8")).hexdigest()[:16]


def valid_keys(keys):
    if not isinstance(keys, dict):
        return None
    out = {}
    for f, _ in FIELDS:
        v = keys.get(f)
        if not isinstance(v, str) or not v or len(v) > 256 or any(c.isspace() for c in v):
            return None
        out[f] = v
    return out


def is_private(ip):
    try:
        a = ipaddress.ip_address(ip)
    except ValueError:
        return False
    return a.is_private or a.is_loopback


class KeyStore(object):
    def __init__(self, path):
        self.path = path

    def load(self):
        try:
            with open(self.path, encoding="utf-8") as fh:
                return valid_keys((json.load(fh) or {}).get("youtube"))
        except (OSError, ValueError, AttributeError):
            return None

    def save(self, keys):
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        tmp = self.path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump({"youtube": keys, "received_at": int(time.time())}, fh)
        os.replace(tmp, self.path)


class Responder(object):
    """The device side of the exchange (pure: `handle` takes a datagram and returns the reply, if any)."""

    def __init__(self, store, clock=time.time):
        self.store, self.clock = store, clock
        self.hellos = {}            # ip -> time of its last HELLO
        self.received = threading.Event()

    def handle(self, data, ip):
        if not is_private(ip):
            return None
        try:
            text = data.decode("utf-8")
        except UnicodeDecodeError:
            return None
        if not text.startswith(MAGIC + " "):
            return None
        verb, _, rest = text[len(MAGIC) + 1:].partition(" ")
        now = self.clock()
        if verb == "HELLO":
            nonce = rest.strip()[:64]
            self.hellos[ip] = now
            return ("%s NEED youtube %s %s" % (MAGIC, fingerprint(self.store.load()), nonce)).encode("utf-8")
        if verb == "KEYS":
            if now - self.hellos.get(ip, -1e9) > HELLO_TTL_S:
                return None
            try:
                keys = valid_keys((json.loads(rest) or {}).get("youtube"))
            except ValueError:
                keys = None
            if keys is None:
                return ("%s BAD" % MAGIC).encode("utf-8")
            self.store.save(keys)
            self.received.set()
            return ("%s OK %s" % (MAGIC, fingerprint(keys))).encode("utf-8")
        return None


def apply_youtube(env, keys):
    """Write the keys into this profile's YouTube add-on where they differ. Returns the number of settings changed."""
    changed = 0
    for f, sid in FIELDS:
        if env.yt_get(sid) != keys[f]:
            env.yt_set(sid, keys[f])
            changed += 1
    return changed


class YtKeys(object):
    """Polled by service.py in a settled profile: listens for the PC and applies the stored keys to this profile."""

    def __init__(self, env, guard_ready):
        self.env, self.guard_ready = env, guard_ready
        self.store = KeyStore(env.store_path())
        self.responder = Responder(self.store)
        self.ready_since = None
        self.next_apply = 0.0
        self.stop = threading.Event()
        self.thread = None
        self.port = PORT

    def poll(self):
        now = self.env.clock()
        if not self.guard_ready():
            self.ready_since = None
            return None
        if self.ready_since is None:
            self.ready_since = now
        if now - self.ready_since < DELAY_S:
            return None
        if self.thread is None and self.env.youtube_installed():
            self.thread = threading.Thread(target=self._listen, name="nikeflix-ytkeys")
            self.thread.daemon = True
            self.thread.start()
        if self.responder.received.is_set() or now >= self.next_apply:
            self.responder.received.clear()
            self.next_apply = now + CHECK_EVERY_S
            keys = self.store.load()
            if keys and self.env.youtube_installed():
                n = apply_youtube(self.env, keys)
                if n:
                    self.env.log("YouTube keys applied to this profile (%d setting(s))" % n)
                    return "applied"
        return None

    def _listen(self):
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            sock.bind(("", self.port))
            sock.settimeout(1.0)
        except OSError as exc:
            self.env.log("YouTube keys: cannot listen on UDP %d (%s)" % (self.port, type(exc).__name__), "warning")
            return
        try:
            while not self.stop.is_set():
                try:
                    data, addr = sock.recvfrom(4096)
                except socket.timeout:
                    continue
                except OSError:
                    break
                try:
                    reply = self.responder.handle(data, addr[0])
                    if reply:
                        sock.sendto(reply, addr)
                except Exception as exc:   # one bad datagram never stops the listener
                    self.env.log("YouTube keys: datagram ignored (%s)" % type(exc).__name__, "warning")
        finally:
            sock.close()

    def end(self):
        self.stop.set()
        if self.thread is not None:
            self.thread.join(2.0)


class YtKeysEnv(object):
    def __init__(self, kodi):
        self.kodi = kodi

    def clock(self):
        return time.time()

    def log(self, msg, level="info"):
        self.kodi.log(msg, level)

    def store_path(self):
        return self.kodi.translate(STORE)

    def youtube_installed(self):
        import xbmc
        return bool(xbmc.getCondVisibility("System.HasAddon(%s)" % YT))

    def yt_get(self, sid):
        import xbmcaddon
        try:
            return xbmcaddon.Addon(YT).getSetting(sid)
        except RuntimeError:
            return None

    def yt_set(self, sid, value):
        import xbmcaddon
        xbmcaddon.Addon(YT).setSetting(sid, value)
