# -*- coding: utf-8 -*-
"""NikeFlix 4.1.5 loading screen (Tanner 2026-11-21, approved preview v19): when a title starts, NikeFlix's own loading
screen replaces Umbrella's and Fen's "finding sources" windows - the title's art dimmed behind, a red ring filling with
the percent, the logo (or the title) and "S1:E5 · Episode" under it, fading out as playback starts.

How it is drawn (no Python window: nothing here may count as a modal dialog, or the NikeFlix player would read a
cancelled or failed Umbrella as still working):
- the skin's Custom_1127_NikeFlixLoading.xml is a dialog with a <visible> condition on the Home property
  nikeflix.loading, so Kodi opens it by itself (not modal: the remote still talks to Umbrella's or Fen's window under
  it, so Back still cancels the search) and fades it out when the property is cleared;
- the NikeFlix player (playback.Wrapper) drives it through LoadingCover: it sets the title, episode and art, copies
  the percent from the source window that is searching (Umbrella's source_progress.xml, Fen's sources_playback.xml,
  both keep it in their window property "percent"), and clears it when playback starts or the request ends.
- Umbrella's own window: progress.dialog 4 (Hidden; Umbrella's settings.xml option 40396) while NikeFlix's screen is
  in use, 2 (Full Screen, Umbrella's default) with Settings > Playback > Show source details while loading.
  UmbrellaWindowSync keeps it in step on every profile; Fen's window is covered by the NikeFlix screen, and shows
  itself with that setting on.
- The cover steps aside (nikeflix.loading.hide) for anything that asks the viewer something: a source list, a
  yes/no, the keyboard, the backup player's countdown, Fen's Resume question.
"""
P_ON = "nikeflix.loading"                 # "1" while the screen is wanted
P_HIDE = "nikeflix.loading.hide"          # "1" while something else asks the viewer a question
P_TITLE = "nikeflix.loading.title"
P_EP = "nikeflix.loading.ep"              # "S1:E5 · Episode name" (episodes only)
P_FANART = "nikeflix.loading.fanart"
P_LOGO = "nikeflix.loading.clearlogo"
P_PCT = "nikeflix.loading.percent"        # "0".."100"
P_RING = "nikeflix.loading.ring"          # the ring texture step, "000".."100" in steps of 2
PROPS = (P_ON, P_HIDE, P_TITLE, P_EP, P_FANART, P_LOGO, P_PCT, P_RING)
P_ACTIVE = "nikeflix.playback.active"     # playback.P_ACTIVE: a NikeFlix play request is running

UMBRELLA = "plugin.video.umbrella"
OWN = "service.nikeflix"
DETAILS = "loading.details"
UMB_HIDDEN, UMB_FULLSCREEN = "4", "2"

# source windows (their XML file names, as Window.IsActive() takes them) and what each keeps in "percent"
SOURCES = (("umbrella", "source_progress.xml"), ("fen", "sources_playback.xml"))
# dialogs that ask the viewer something: the cover steps aside
ASKING = ("Window.IsActive(selectdialog)", "Window.IsActive(yesnodialog)", "Window.IsActive(okdialog)",
          "Window.IsActive(virtualkeyboard)", "Window.IsActive(numericinput)", "Window.IsActive(progressdialog)",
          "Window.IsActive(contextmenu)", "Window.IsActive(source_results.xml)", "Window.IsActive(uncached_results.xml)",
          "Window.IsActive(confirm.xml)", "Window.IsActive(select.xml)")
CREEP_UNTIL = 12.0   # before a source window reports a percent, the ring creeps to this over CREEP_SECONDS
CREEP_SECONDS = 8.0
ARRIVE_AT = 96       # after the search, while the stream opens


def details_on(value):
    return str(value).strip().lower() == "true"


def umbrella_mode(details, current):
    """Umbrella progress.dialog for the NikeFlix setting: Hidden under the NikeFlix screen; with source details,
    Umbrella's own window (Full Screen, its default) unless the viewer chose another visible one there."""
    if not details:
        return UMB_HIDDEN
    return UMB_FULLSCREEN if str(current) in (UMB_HIDDEN, "") else str(current)


def apply_umbrella(addon_get, addon_set):
    """-> the value written, or None when Umbrella already matches (or is not installed)."""
    current = str(addon_get(UMBRELLA, "progress.dialog") or "")
    want = umbrella_mode(details_on(addon_get(OWN, DETAILS)), current)
    if current == want:
        return None
    addon_set(UMBRELLA, "progress.dialog", want)
    return want


def ep_label(params):
    if params.get("media_type") != "episode":
        return ""
    s, e = str(params.get("season") or "").strip(), str(params.get("episode") or "").strip()
    if not (s and e):
        return ""
    name = (params.get("title") or "").strip()
    show = (params.get("tvshowtitle") or "").strip()
    return "S%s:E%s" % (s, e) + (" · %s" % name if name and name != show else "")


def same_title(params, info):
    """Is the focused list item (info: an infolabel reader) the title this request plays? By TMDb id, else by name."""
    want = str(params.get("tmdb_id") or "").strip()
    ids = [info("ListItem.UniqueID(tmdb)"), info("ListItem.Property(tmdb_id)"), info("ListItem.Property(tvshow.tmdb_id)")]
    if want and want in [str(i).strip() for i in ids if i]:
        return True
    names = [str(params.get(k) or "").strip().lower() for k in ("tvshowtitle", "title")]
    shown = [str(info(k) or "").strip().lower() for k in ("ListItem.TVShowTitle", "ListItem.Title", "ListItem.Label")]
    return bool(names[0] or names[1]) and any(n and n in shown for n in names)


def addon_art(path):
    """Umbrella's / Fen's own background (used when the title has none) is not the title's art."""
    p = str(path or "").replace("\\", "/").lower()
    return any("/%s/" % a in p for a in ("plugin.video.umbrella", "plugin.video.fen"))


def ring_step(percent):
    p = max(0, min(100, int(percent)))
    return "%03d" % (p - p % 2)


class LoadingCover(object):
    """The NikeFlix loading screen for one play request. All Kodi access goes through `env`:
    env.set_prop / clear_prop / get_prop (Home window), env.cond(condition), env.source() -> (kind, props) of the
    source window searching now (props: dict of its window properties) or None, env.art() -> (fanart, clearlogo) of
    the title being played, env.now()."""

    def __init__(self, env, enabled=True):
        self.env, self.enabled = env, enabled
        self.started = None
        self.best = 0
        self.seen_source = False
        self.shown = False

    def start(self, params):
        if not self.enabled:
            return
        e = self.env
        title = (params.get("tvshowtitle") or params.get("title") or "").strip()
        fanart, logo = e.art(params)
        for key, value in ((P_TITLE, title), (P_EP, ep_label(params)), (P_FANART, fanart), (P_LOGO, logo)):
            if value:
                e.set_prop(key, value)
            else:
                e.clear_prop(key)
        self.started, self.best = e.now(), 0
        self._percent(0)
        e.clear_prop(P_HIDE)
        e.set_prop(P_ON, "1")
        self.shown = True

    def _percent(self, value):
        value = max(self.best, min(100, int(value)))
        self.best = value
        self.env.set_prop(P_PCT, str(value))
        self.env.set_prop(P_RING, ring_step(value))

    def tick(self):
        """Once per poll of the NikeFlix player while it waits for playback."""
        if not self.shown:
            return
        e = self.env
        src = e.source()
        asking = any(e.cond(c) for c in ASKING)
        if src is not None:
            kind, props = src
            self.seen_source = True
            if kind == "fen" and props.get("window_mode") == "resume":
                asking = True          # Fen asks Resume / Start over (only when auto resume is off)
            for key, prop in ((P_FANART, "fanart"), (P_LOGO, "clearlogo")):
                if props.get(prop) and not e.get_prop(key) and not addon_art(props[prop]):
                    e.set_prop(key, props[prop])
            try:
                pct = int(float(props.get("percent") or 0))
            except ValueError:
                pct = 0
            self._percent(pct)
        elif self.seen_source:
            self._percent(max(self.best, ARRIVE_AT))      # the search is over; the stream is opening
        else:
            ran = e.now() - (self.started or e.now())
            self._percent(min(CREEP_UNTIL, CREEP_UNTIL * ran / CREEP_SECONDS))
        if asking:
            e.set_prop(P_HIDE, "1")
        else:
            e.clear_prop(P_HIDE)

    def finish(self, started):
        """Playback started (the ring completes and the screen fades out) or the request ended without it."""
        if not self.shown:
            return
        if started:
            self._percent(100)
        for key in PROPS:
            self.env.clear_prop(key)
        self.shown = False


P_BY = "nikeflix.loading.by"             # 4.1.7: "umbrella|<time>" while Umbrella (patch 0014) shows it between episodes
UMBRELLA_COVER_S = 90.0                  # Umbrella's own screen is left alone this long (it clears it at the next start)


def clear_stale(get_prop, clear_prop, now=None):
    """The service's watchdog: a loading screen with no NikeFlix play request behind it is taken down. NikeFlix 4.1.7:
    except the one Umbrella shows while the next episode opens (patch 0014), unless it is older than UMBRELLA_COVER_S."""
    if get_prop(P_ON) and not get_prop(P_ACTIVE):
        by = get_prop(P_BY) or ""
        if by.startswith("umbrella|"):
            import time
            try:
                if (now if now is not None else time.time()) - float(by.split("|", 1)[1]) < UMBRELLA_COVER_S:
                    return False
            except ValueError:
                pass
        for key in PROPS + (P_BY,):
            clear_prop(key)
        return True
    return False


class CoverEnv(object):
    """Kodi side of LoadingCover (Python 3.8). Properties on the Home window; the source window's properties read
    through its window id (Kodi gives an add-on's dialog an id of 13000 and up)."""

    def __init__(self, kodi):
        import xbmc
        import xbmcgui
        self.kodi, self.xbmc, self.xbmcgui = kodi, xbmc, xbmcgui

    def set_prop(self, key, value):
        self.kodi.set_prop(key, value)

    def clear_prop(self, key):
        self.kodi.clear_prop(key)

    def get_prop(self, key):
        return self.kodi.get_prop(key)

    def cond(self, condition):
        return self.kodi.cond(condition)

    def now(self):
        return self.kodi.now()

    def art(self, params):
        """The focused item's art, only when it is the title being played (the title page, a row card); else nothing
        yet, and the source window's art (Umbrella's / Fen's, from the title's own metadata) fills it in."""
        info = self.xbmc.getInfoLabel
        if not same_title(params, info):
            return "", ""
        fanart = info("ListItem.Art(fanart)") or info("ListItem.Art(tvshow.fanart)")
        logo = info("ListItem.Art(clearlogo)") or info("ListItem.Art(tvshow.clearlogo)")
        return fanart, logo

    def source(self):
        for kind, xml in SOURCES:
            if self.kodi.cond("Window.IsActive(%s)" % xml):
                wid = self.xbmcgui.getCurrentWindowDialogId()
                try:
                    win = self.xbmcgui.Window(wid)
                    props = dict((k, win.getProperty(k)) for k in ("percent", "fanart", "clearlogo", "window_mode",
                                                                    "umbrella.fanart", "umbrella.clearlogo"))
                except Exception:
                    props = {}
                props["fanart"] = props.get("fanart") or props.get("umbrella.fanart") or ""
                props["clearlogo"] = props.get("clearlogo") or props.get("umbrella.clearlogo") or ""
                return kind, props
        return None


def cover_for(kodi):
    """The loading screen for this request: on with NikeFlix's skin and Show source details while loading Off."""
    try:
        import xbmc
        import xbmcaddon
        skin = xbmc.getSkinDir() == "skin.nikeflix"
        details = details_on(xbmcaddon.Addon(OWN).getSetting(DETAILS))
        return LoadingCover(CoverEnv(kodi), enabled=skin and not details)
    except Exception as exc:
        kodi.log("loading screen off for this play: %s" % type(exc).__name__, "warning")
        return None


P_POSTPLAY_CLOSED = "nikeflix.postplay.closed"   # Umbrella patch 0010: when the post-play window closed (seconds)
RETURN_WINDOW = 20.0


def back_to_full_screen(kodi):
    """After post-play: the next episode can start while Kodi has fallen back to the menu (the episode ended under the
    post-play window). Within RETURN_WINDOW seconds of it closing, put playing video back up full screen once.
    -> True when it did."""
    raw = kodi.get_prop(P_POSTPLAY_CLOSED)
    if not raw:
        return False
    try:
        age = kodi.now() - float(raw)
    except ValueError:
        age = RETURN_WINDOW + 1
    if age > RETURN_WINDOW or age < -5:
        kodi.clear_prop(P_POSTPLAY_CLOSED)
        return False
    if kodi.cond("Window.IsActive(fullscreenvideo)"):
        kodi.clear_prop(P_POSTPLAY_CLOSED)
        return False
    if kodi.cond("Player.HasVideo") and not kodi.cond("System.HasActiveModalDialog"):
        kodi.builtin("ActivateWindow(fullscreenvideo)")
        kodi.clear_prop(P_POSTPLAY_CLOSED)
        kodi.log("post-play: the next episode brought up full screen")
        return True
    return False


POSTPLAY_MARK = "special://profile/addon_data/service.nikeflix/postplay-416.done"
POSTPLAY_WANT = (("playnext.method", ("2",), "3"), ("playnext.segment.fallback", ("", "60"), "25"))


def apply_postplay(addon_get, addon_set):
    """NikeFlix 4.1.6 (Tanner on the Apple TV, 2026-11-22: "The next episode started too early"): post-play comes up
    when the credits start, like Netflix. Umbrella's method 3 uses the credits time from its IntroDB / TheIntroDB
    lookup (the same lookup as Skip Intro) and, when none is known, comes up `playnext.segment.fallback` seconds
    before the end: 25 s instead of Umbrella's 60. Before 4.1.6 NikeFlix seeded method 2 (the end of the subtitles,
    often minutes early). Only NikeFlix's old values are changed: 2 -> 3 and the untouched 60 -> 25.
    -> the settings written."""
    wrote = []
    for sid, old, want in POSTPLAY_WANT:
        cur = addon_get(UMBRELLA, sid)
        if cur is None:
            continue
        if str(cur) in old:
            addon_set(UMBRELLA, sid, want)
            wrote.append("%s=%s" % (sid, want))
    return wrote


class UmbrellaWindowSync(object):
    """Every profile, about every 30 s: Umbrella's progress.dialog follows Show source details while loading, and a
    loading screen left without a play request behind it is taken down."""

    def __init__(self, kodi, every=30.0):
        self.kodi, self.every, self.next_at = kodi, every, 0.0

    def poll(self):
        clear_stale(self.kodi.get_prop, self.kodi.clear_prop)
        back_to_full_screen(self.kodi)
        now = self.kodi.now()
        if now < self.next_at:
            return
        self.next_at = now + self.every
        from resources.lib import settings_ui
        env = settings_ui.SettingsEnv(self.kodi)
        if not env.addon_installed(UMBRELLA):
            return
        wrote = apply_umbrella(env.addon_get, env.addon_set)
        if wrote:
            self.kodi.log("loading screen: Umbrella progress.dialog set to %s" % wrote)
        self._postplay(env)

    def _postplay(self, env):
        """Once per profile (a marker in its service.nikeflix folder): a later choice in Umbrella's settings stays."""
        import os
        mark = self.kodi.translate(POSTPLAY_MARK)
        if os.path.exists(mark):
            return
        wrote = apply_postplay(env.addon_get, env.addon_set)
        if wrote:
            self.kodi.log("post-play: Umbrella %s (credits start, else 25 s before the end)" % ", ".join(wrote))
            try:   # Umbrella reads its settings file from disk (umbrellafile.py; tvOS never writes it)
                from resources.lib.umbrellafile import UmbrellaFile, UmbrellaFileEnv
                UmbrellaFile(UmbrellaFileEnv(self.kodi), lambda: True).sync_now("post-play timing")
            except Exception:
                pass
        try:
            os.makedirs(os.path.dirname(mark), exist_ok=True)
            open(mark, "w").close()
        except OSError:
            pass
