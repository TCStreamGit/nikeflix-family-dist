# -*- coding: utf-8 -*-
"""NikeFlix playback wrapper: Umbrella PRIMARY, Fen 4 FALLBACK only after a confirmed Umbrella failure.

TMDb Helper's own fallback cannot see a downstream Umbrella failure (it hands off and exits), and Kodi emits
no player event when Umbrella gives up (lab-verified 2026-10-18). Failure is therefore inferred
conservatively:
  * success  = Kodi `onAVStarted` (or video actually playing) at any time;
  * working  = player has media, or a busy/progress/modal dialog is visible;
  * failure  = after a minimum grace period, Umbrella has been idle (not working, not playing) for an
               uninterrupted idle window;
  * a hard cap ends the wait; if Umbrella still looks busy at the cap the wrapper gives up WITHOUT starting
    Fen (never two players).
Before Fen starts: the profile guard must be ready for the same profile and epoch (fail closed), nothing may
be playing or busy, and the user gets a short cancellable countdown (so deliberately cancelling Umbrella does
not start Fen). Fen is always called with `disable_autoplay_next_episode=true` (Umbrella owns Play Next).

Resume (NikeFlix 4.1.5, Tanner 2026-11-21: "when I select a episode have it auto resume"): like Netflix, a title with a
resume point resumes straight away, and "Play from beginning" on the title page is the one way to start over. Kodi
passes resume:false to every plugin started here (lab), so the wrapper tells Umbrella itself: the Home property
nikeflix.play.resume ("true|<time>", or "false|<time>" after Play from beginning) is set just before Umbrella starts
and read once by Umbrella's patch 0008, which ignores it when it is more than RESUME_TTL seconds old (Umbrella may
still be searching after the wrapper has stopped waiting, so the wrapper does not clear it). The skin's Play from
beginning sets nikeflix.play.fromstart, which the next request consumes; FromStartExpiry (polled by the service) drops
one that no request picked up within FROMSTART_TTL seconds.

Loading screen (NikeFlix 4.1.5, approved preview v19): while the wrapper waits for playback it drives the NikeFlix
loading screen (loading.LoadingCover, drawn by the skin over Umbrella's hidden window or Fen's), and takes it down as
playback starts or when the request ends any other way.
"""
import json
import uuid

try:
    from urllib.parse import quote, unquote, urlencode
except ImportError:  # pragma: no cover
    from urllib import quote, unquote, urlencode

UMBRELLA = "plugin://plugin.video.umbrella/"
FEN = "plugin://plugin.video.fen/"
P_ACTIVE = "nikeflix.playback.active"
P_RESUME = "nikeflix.play.resume"         # for Umbrella (patch 0008): "true" resume, "false" from the beginning
P_FROMSTART = "nikeflix.play.fromstart"   # set by the skin's Play from beginning, consumed by the next request
P_CHOOSE = "nikeflix.play.choose"         # 4.1.6: set by the title page's Choose source, consumed the same way
RESUME_TTL = 300        # Umbrella patch 0008 uses the same limit
FROMSTART_TTL = 60.0

DEFAULTS = {"grace": 8.0, "idle_window": 6.0, "primary_cap": 150.0, "guard_timeout": 15.0,
            "countdown": 3.0, "fallback_cap": 120.0, "poll": 0.25, "settle": 3.0}

WORKING_CONDITIONS = (
    "Player.HasMedia",
    "Window.IsVisible(busydialog)",
    "Window.IsVisible(busydialognocancel)",
    "Window.IsVisible(progressdialog)",
    "Window.IsVisible(extendedprogressdialog)",
    "System.HasActiveModalDialog",
)


def umbrella_url(p, choose=False):
    """`choose` (4.1.6, Tanner 2026-11-22: "Choose source"): Umbrella shows its source list (select=0) instead of
    playing the best source by itself."""
    q = [("action", "play"), ("title", p.get("title", "")), ("year", p.get("year", "")),
         ("imdb", p.get("imdb", "")), ("tmdb", p.get("tmdb_id", ""))]
    if p.get("media_type") == "episode":
        # Umbrella's scrapers need the show's year (and use the tvdb id); without them an episode request found
        # no sources (P05 lab 2026-11-18)
        q += [("tvdb", p.get("tvdb", "")), ("tvshowtitle", p.get("tvshowtitle", "")), ("season", p.get("season", "")),
              ("episode", p.get("episode", "")), ("premiered", p.get("premiered", ""))]
    if choose:
        q.append(("select", "0"))
    return UMBRELLA + "?" + urlencode([(k, v) for k, v in q if v != ""], quote_via=quote)


def fen_url(p):
    q = [("mode", "playback.media"), ("media_type", p.get("media_type", "movie")), ("tmdb_id", p.get("tmdb_id", ""))]
    if p.get("media_type") == "episode":
        q += [("season", p.get("season", "")), ("episode", p.get("episode", ""))]
    q.append(("disable_autoplay_next_episode", "true"))
    return FEN + "?" + urlencode(q, quote_via=quote)


class Result(object):
    PRIMARY_OK = "primary_success"
    FALLBACK_STARTED = "fallback_started"
    FALLBACK_OK = "fallback_success"
    FALLBACK_NO_PLAYBACK = "fallback_no_playback"
    BLOCKED_GUARD = "fallback_blocked_profile_guard"
    BLOCKED_BUSY = "fallback_blocked_primary_still_busy"
    CANCELLED = "fallback_cancelled_by_user"
    ABORTED = "aborted_profile_or_shutdown"
    DUPLICATE = "rejected_duplicate_request"
    BAD_REQUEST = "rejected_bad_request"
    NO_FALLBACK = "fallback_unavailable"


class Wrapper(object):
    def __init__(self, kodi, guard, settings=None, diag=None, cover=None):
        self.k, self.g, self.cover = kodi, guard, cover
        self.s = dict(DEFAULTS)
        self.s.update(settings or {})
        self.diag = diag or (lambda event, **kw: None)
        self._started = False

    def _on_av(self):
        self._started = True

    def _working(self):
        return any(self.k.cond(c) for c in WORKING_CONDITIONS)

    def _playing(self):
        return self._started or self.k.cond("Player.HasVideo")

    def _tick(self):
        if self.cover is not None:
            try:
                self.cover.tick()
            except Exception:   # the loading screen must never break playback
                self.cover = None

    def run(self, params):
        resume = self._resume(params)   # first: every request consumes a Play from beginning
        choose = self.k.get_prop(P_CHOOSE) == "true" or str(params.get("choose", "")).lower() == "true"
        self.k.clear_prop(P_CHOOSE)      # and a Choose source
        if params.get("media_type") not in ("movie", "episode") or not params.get("tmdb_id"):
            return self._done(Result.BAD_REQUEST)
        if params.get("media_type") == "episode" and not (params.get("season") and params.get("episode")):
            return self._done(Result.BAD_REQUEST)
        epoch, path = self.g.epoch(), self.g.active_path()
        if self._active_request(epoch):
            return self._done(Result.DUPLICATE)
        try:   # 4.1.7: back on the title page after Stop when this play came from it (titlereturn.py)
            from resources.lib import titlereturn
            titlereturn.note_request(self.k, params)
        except Exception:
            pass
        req = uuid.uuid4().hex
        token = "%s|%d|%.0f" % (req, epoch, self.k.now())
        self.k.set_prop(P_ACTIVE, token)
        try:
            if choose:   # the source list must not sit under the loading screen
                self.cover = None
            if self.cover is not None:
                self.cover.start(params)
            return self._run(params, req, epoch, path, resume, choose)
        finally:
            if self.cover is not None:
                try:   # the screen never outlives the request; with playback the ring completes and it fades out
                    self.cover.finish(self._playing())
                except Exception:
                    pass
            if self.k.get_prop(P_ACTIVE) == token:
                self.k.clear_prop(P_ACTIVE)

    def _resume(self, params):
        """True unless this request is the title page's Play from beginning (or says resume=false)."""
        from_start = self.k.get_prop(P_FROMSTART) == "true"
        self.k.clear_prop(P_FROMSTART)
        if str(params.get("resume", "")).lower() in ("true", "false"):
            return str(params["resume"]).lower() == "true"
        return not from_start

    def _active_request(self, epoch):
        """True if another request is genuinely in flight (same epoch and not older than the caps)."""
        raw = self.k.get_prop(P_ACTIVE)
        if not raw:
            return False
        try:
            _, e, t = raw.split("|")
            fresh = int(e) == epoch and self.k.now() - float(t) < self.s["primary_cap"] + self.s["fallback_cap"] + 60
        except ValueError:
            fresh = False
        if not fresh:
            self.k.clear_prop(P_ACTIVE)
        return fresh

    def _run(self, params, req, epoch, path, resume=True, choose=False):
        player = self.k.player(self._on_av)
        t0 = self.k.now()
        self.diag("primary_start", request=req, media_type=params.get("media_type"), resume=resume, choose=choose)
        self.k.set_prop(P_RESUME, "%s|%d" % ("true" if resume else "false", int(self.k.now())))
        player.play(umbrella_url(params, choose))
        idle_since = None
        while True:
            if self.k.wait(self.s["poll"]) or self.g.epoch() != epoch:
                return self._done(Result.ABORTED, request=req)
            self._tick()
            elapsed = self.k.now() - t0
            if self._playing():
                return self._done(Result.PRIMARY_OK, request=req, seconds=round(elapsed, 1))
            if self._working():
                idle_since = None
            elif elapsed >= self.s["grace"]:
                idle_since = idle_since if idle_since is not None else self.k.now()
                if self.k.now() - idle_since >= self.s["idle_window"]:
                    break
            if elapsed >= self.s["primary_cap"]:
                if self._working():
                    return self._done(Result.BLOCKED_BUSY, request=req, seconds=round(elapsed, 1))
                break
        self.diag("primary_failed", request=req, seconds=round(self.k.now() - t0, 1))
        if not self.k.cond("System.HasAddon(plugin.video.fen)"):
            return self._done(Result.NO_FALLBACK, request=req)
        ok, reason = self.g.wait_ready(epoch, path, self.s["guard_timeout"])
        if not ok:
            return self._done(Result.BLOCKED_GUARD, request=req, reason=reason)
        if self.k.countdown_cancelled("NikeFlix", "Trying the backup player...", self.s["countdown"]):
            return self._done(Result.CANCELLED, request=req)
        # The countdown dialog itself is modal; give transient dialogs a moment to close before re-checking.
        settle_until = self.k.now() + self.s["settle"]
        while self._working() and self.k.now() < settle_until:
            if self.k.wait(self.s["poll"]) or self.g.epoch() != epoch:
                return self._done(Result.ABORTED, request=req, stage="settle")
        # Re-check everything immediately before handing over (TOCTOU): same profile/epoch, idle, not playing.
        ok, reason = self.g.ready(epoch, path)
        if not ok:
            return self._done(Result.BLOCKED_GUARD, request=req, reason=reason)
        if self._playing() or self._working():
            return self._done(Result.BLOCKED_BUSY, request=req)
        cached = self.k.get_prop("fen.addon_profile")
        self.diag("fallback_start", request=req, guard=reason,
                  fen_cached_path=("empty" if not cached else "active_profile"))
        self.k.builtin("RunPlugin(%s)" % fen_url(params))
        t1 = self.k.now()
        while True:
            if self.k.wait(self.s["poll"]) or self.g.epoch() != epoch:
                return self._done(Result.ABORTED, request=req, stage="fallback")
            self._tick()
            if self._playing():
                return self._done(Result.FALLBACK_OK, request=req, seconds=round(self.k.now() - t1, 1))
            if self.k.now() - t1 >= self.s["fallback_cap"]:
                return self._done(Result.FALLBACK_NO_PLAYBACK, request=req)

    def _done(self, result, **kw):
        self.diag(result, **kw)
        return result


class FromStartExpiry(object):
    """A Play from beginning that never reached the wrapper (a library play, a cancelled player choice) must not
    restart a later play: the service polls this once a second and drops the flag after FROMSTART_TTL seconds."""

    def __init__(self, kodi, ttl=FROMSTART_TTL):
        self.k, self.ttl, self.seen = kodi, ttl, None

    def poll(self):
        if not isinstance(self.seen, dict):
            self.seen = {}
        for prop in (P_FROMSTART, P_CHOOSE):   # 4.1.6: an unused Choose source expires the same way
            if self.k.get_prop(prop) != "true":
                self.seen.pop(prop, None)
                continue
            now = self.k.now()
            if prop not in self.seen:
                self.seen[prop] = now
            elif now - self.seen[prop] >= self.ttl:
                self.k.clear_prop(prop)
                self.seen.pop(prop, None)


def parse_args(argv):
    """RunScript(service.nikeflix,action=play,media_type=movie,tmdb_id=603,...) -> dict.

    TMDb Helper's NikeFlix player sends {title_url} / {showname_url}, i.e. quote()d values (a comma in a title
    would otherwise split the RunScript argument). Each value is decoded once here, so umbrella_url() encodes
    the real title once; without this Umbrella searched for the literal "The%20Matrix" and found nothing
    (P05 lab 2026-11-18). Unencoded values pass through unchanged."""
    out = {}
    for a in argv:
        if "=" in a:
            k, v = a.split("=", 1)
            out[k.strip()] = unquote(v.strip())
    return out


def diag_writer(kodi, profile_path=None):
    """Append-only per-profile diagnostics (no secrets: only event names, ids, timings, reasons).

    The target folder is bound to the profile that made the request (`profile_path`), so events emitted
    after a profile switch (e.g. "aborted") are never written into another profile's data."""
    import os
    base = profile_path or kodi.translate("special://profile/")
    target = os.path.join(base, "addon_data", "service.nikeflix")

    def write(event, **kw):
        try:
            d = target
            if not os.path.isdir(d):
                os.makedirs(d)
            rec = {"t": round(kodi.now(), 2), "event": event}
            rec.update(kw)
            with open(os.path.join(d, "playback-diagnostics.jsonl"), "a") as f:
                f.write(json.dumps(rec) + "\n")
            kodi.log("playback %s" % json.dumps(rec), "info")
        except Exception:  # diagnostics must never break playback
            pass
    return write
