# -*- coding: utf-8 -*-
"""Back on the title page after Stop (NikeFlix 4.1.7, item 14; Tanner 2026-11-22), Netflix-style.

The title page's Play buttons close the page before they start playback (Kodi refuses full-screen video while a
modal dialog is open), so after Stop Kodi showed Home. Now:

  1. the skin's DialogVideoInfo.xml writes the page that just closed into the Home property nikeflix.title.last
     ("tv|<tmdb id>" for a show or an episode, "movie|<tmdb id>"); `TitleReturn.poll` stamps it with the time;
  2. the NikeFlix player wrapper (`note_request`, at the start of every play request) takes that page when the request
     is for the same title and was made within LAST_TTL seconds, and keeps it in nikeflix.title.return;
  3. `TitleReturn.poll` (the service, once a second) waits for that playback to start, and once nothing has played for
     IDLE_S seconds (episodes rolling on through Play Next keep it waiting) and no loading screen, post-play window,
     dialog or play request is up, opens the title page again through TMDb Helper (the same call as the rows use).

A play that never starts drops the return after START_TTL seconds. Only Home properties and GUI conditions; nothing
while a profile switch is pending (the caller checks the guard, H3)."""

P_LAST = "nikeflix.title.last"
P_RETURN = "nikeflix.title.return"
P_ACTIVE = "nikeflix.playback.active"
LAST_TTL = 60.0
START_TTL = 240.0
IDLE_S = 3.0
KINDS = ("tv", "movie")
BUSY = ("Player.HasMedia", "System.HasActiveModalDialog", "Window.IsVisible(1127)",
        "Window.IsVisible(auraplaynext2.xml)", "Window.IsVisible(auraplaynext_stillwatching2.xml)",
        "Window.IsActive(fullscreenvideo)", "Window.IsActive(loginscreen)",
        "String.IsEqual(Window(fullscreenvideo).Property(umbrella.playnext.transition),true)")
ELSEWHERE = "Window.IsVisible(movieinformation)"   # already on a title page: nothing to reopen
OPEN = ("RunScript(plugin.video.themoviedb.helper,add_path=plugin://plugin.video.themoviedb.helper/"
        "?info=details&type={kind}&tmdb_id={tmdb},call_auto=1190)")


def _parse(raw):
    """("tv"|"movie", tmdb id, stamp or None) or None."""
    parts = str(raw or "").split("|")
    if len(parts) not in (2, 3) or parts[0] not in KINDS or not parts[1].isdigit():
        return None
    stamp = None
    if len(parts) == 3:
        try:
            stamp = float(parts[2])
        except ValueError:
            return None
    return parts[0], parts[1], stamp


def note_request(kodi, params):
    """Called by the wrapper for every play request: keep the title page to come back to, or none."""
    last = _parse(kodi.get_prop(P_LAST))
    kodi.clear_prop(P_LAST)
    kind = "movie" if params.get("media_type") == "movie" else "tv"
    tmdb = str(params.get("tmdb_id") or "")
    now = kodi.now()
    if last and last[0] == kind and last[1] == tmdb and (last[2] is None or now - last[2] <= LAST_TTL):
        kodi.set_prop(P_RETURN, "%s|%s|%.0f" % (kind, tmdb, now))
        return True
    kodi.clear_prop(P_RETURN)
    return False


class TitleReturn(object):
    def __init__(self, kodi, idle_s=IDLE_S, start_ttl=START_TTL):
        self.k, self.idle_s, self.start_ttl = kodi, idle_s, start_ttl
        self.key = None          # the return being watched
        self.played = False
        self.idle_since = None

    def _stamp_last(self):
        raw = self.k.get_prop(P_LAST)
        last = _parse(raw) if raw else None
        if raw and last is None:
            self.k.clear_prop(P_LAST)
        elif last and last[2] is None:
            self.k.set_prop(P_LAST, "%s|%s|%.0f" % (last[0], last[1], self.k.now()))

    def poll(self):
        self._stamp_last()
        raw = self.k.get_prop(P_RETURN)
        ret = _parse(raw) if raw else None
        if ret is None:
            if raw:
                self.k.clear_prop(P_RETURN)
            self.key, self.played, self.idle_since = None, False, None
            return None
        if raw != self.key:
            self.key, self.played, self.idle_since = raw, False, None
        now = self.k.now()
        if self.k.cond("Player.HasVideo"):
            self.played, self.idle_since = True, None
            return None
        if not self.played:
            if now - (ret[2] or now) > self.start_ttl:
                self.k.clear_prop(P_RETURN)
                return "expired"
            return None
        if self.k.cond(ELSEWHERE):
            self.k.clear_prop(P_RETURN)
            self.key, self.played, self.idle_since = None, False, None
            return "elsewhere"
        if self.k.get_prop(P_ACTIVE) or any(self.k.cond(c) for c in BUSY):
            self.idle_since = None
            return None
        if self.idle_since is None:
            self.idle_since = now
            return None
        if now - self.idle_since < self.idle_s:
            return None
        self.k.clear_prop(P_RETURN)
        self.key, self.played, self.idle_since = None, False, None
        self.k.builtin(OPEN.format(kind=ret[0], tmdb=ret[1]))
        self.k.log("title page reopened after playback (%s %s)" % (ret[0], ret[1]))
        return "reopened"
