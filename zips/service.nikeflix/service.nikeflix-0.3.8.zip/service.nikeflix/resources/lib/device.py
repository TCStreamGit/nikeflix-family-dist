# -*- coding: utf-8 -*-
"""NikeFlix 4.1.5: settings kept per device, not per profile (Car mode).

Tanner 2026-11-21: "make sure there is a carplay mode as well that makes the search button bigger and not that close to
the left side cause my car its struggles clicking the stuff close to the side and I need a button or something to
scroll and press that instead of scrolling with my hand". The car is an Android "CarPlay AI box" (Kodi for Android on
a touch screen).

Where it is kept: special://masterprofile/addon_data/service.nikeflix/device.json, the master profile's folder, which
every profile of the device reads (the household keys of ytkeys.py live beside it). Kodi keeps skin settings and
add-on settings per profile, so neither could hold it.

How the skin sees it: the Home window property nikeflix.car ("1" when on). The Home window belongs to the Kodi
process, not to a profile; service.nikeflix sets it when each profile starts and Settings > Appearance > Car mode sets
it at once.

Automatic: Kodi 21 has no touch-screen infolabel or condition (GUIInfoManager offers System.Platform.Android and
nothing about touch or Android TV). So Automatic is on only for Kodi on Android where Android itself declares a touch
screen and is not a lean-back (Android TV / Google TV) device. Android declares its hardware features in
<partition>/etc/permissions/*.xml, which apps may read:
  - lean-back: android.software.leanback.xml or tv_core_hardware.xml (every Android TV, Google TV and Fire TV box);
  - touch: android.hardware.touchscreen*.xml, handheld_core_hardware.xml or tablet_core_hardware.xml.
A box that declares neither, or a folder that cannot be read, counts as not a touch device (Automatic stays Off;
On turns it on by hand)."""
import json
import os

STORE = "special://masterprofile/addon_data/service.nikeflix/device.json"
CAR_PROP = "nikeflix.car"          # Home window property: "1" when Car mode is on
CAR_KEY = "carmode"
CHOICES = ("auto", "on", "off")
PERMISSION_DIRS = ("/system/etc/permissions", "/vendor/etc/permissions", "/product/etc/permissions",
                   "/odm/etc/permissions", "/system_ext/etc/permissions")
LEANBACK_FILES = ("android.software.leanback.xml", "android.software.leanback_only.xml", "tv_core_hardware.xml")
TOUCH_PREFIX = "android.hardware.touchscreen"
TOUCH_FILES = ("handheld_core_hardware.xml", "tablet_core_hardware.xml")


class DeviceStore(object):
    """device.json: {"carmode": "auto" | "on" | "off"}. A missing or broken file reads as Automatic."""

    def __init__(self, path):
        self.path = path

    def _raw(self):
        try:
            with open(self.path, encoding="utf-8") as fh:
                d = json.load(fh)
            return d if isinstance(d, dict) else {}
        except (OSError, ValueError):
            return {}

    def get(self, key, default=""):
        v = self._raw().get(key)
        return v if isinstance(v, str) else default

    def set(self, key, value):
        d = self._raw()
        d[key] = value
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        tmp = self.path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(d, fh, sort_keys=True)
        os.replace(tmp, self.path)


def car_choice(store):
    v = store.get(CAR_KEY, "auto")
    return v if v in CHOICES else "auto"


def android_touch(listdir=os.listdir, dirs=PERMISSION_DIRS):
    """(touch, why) from Android's declared features: touch only when a touch screen is declared and lean-back is not."""
    names = set()
    for d in dirs:
        try:
            names.update(n.lower() for n in listdir(d))
        except (OSError, TypeError):
            continue
    if not names:
        return False, "no feature files readable"
    if any(n in names for n in LEANBACK_FILES):
        return False, "lean-back device (Android TV)"
    if any(n.startswith(TOUCH_PREFIX) for n in names) or any(n in names for n in TOUCH_FILES):
        return True, "touch screen, not lean-back"
    return False, "no touch screen declared"


def car_on(choice, is_android, touch):
    if choice == "on":
        return True
    if choice == "off":
        return False
    return bool(is_android and touch)


def resolve(store, is_android, listdir=os.listdir):
    """(on, choice, why): what Car mode is on this device and why."""
    choice = car_choice(store)
    if choice != "auto":
        return choice == "on", choice, "set by hand"
    if not is_android:
        return False, choice, "not Android"
    touch, why = android_touch(listdir)
    return car_on(choice, True, touch), choice, why


UMB = "plugin.video.umbrella"
UMB_QUALITY = "hosts.quality"      # Umbrella's Max Quality: 0 4K, 1 1080p, 2 720p, 3 480p
CAR_QUALITY = "2"                  # 720p in the car (Tanner 2026-11-22)
QUALITY_KEY = "car_quality_before"  # device.json: {profile folder: the profile's Max Quality before Car mode}


def car_quality(store, profile, on, get, put):
    """NikeFlix 4.1.6 (Tanner 2026-11-22: "car mode prefers 720p over 1080p"): while Car mode is on, Umbrella's Max
    Quality in this profile is 720p; the profile's own choice is kept in device.json and comes back when Car mode is
    turned off (unless the viewer changed it meanwhile). `get()`/`put(v)` read and write Umbrella's setting.
    Returns what was done: "set", "restored" or ""."""
    before = store._raw().get(QUALITY_KEY)
    before = dict(before) if isinstance(before, dict) else {}
    cur = get()
    if cur is None:
        return ""
    if on:
        if cur == CAR_QUALITY:
            return ""
        before[profile] = cur
        store.set(QUALITY_KEY, before)
        put(CAR_QUALITY)
        return "set"
    if profile not in before:
        return ""
    old = before.pop(profile)
    store.set(QUALITY_KEY, before)
    if cur == CAR_QUALITY and old in ("0", "1", "2", "3"):
        put(old)
        return "restored"
    return ""


def _umbrella_quality(kodi, store, on):
    if not kodi.cond("System.HasAddon(%s)" % UMB):
        return ""
    import xbmcaddon

    def get():
        try:
            return xbmcaddon.Addon(UMB).getSetting(UMB_QUALITY) or "0"
        except RuntimeError:
            return None

    def put(v):
        xbmcaddon.Addon(UMB).setSetting(UMB_QUALITY, v)
        try:   # Umbrella reads its settings file from disk (umbrellafile.py keeps it in step; tvOS never writes it)
            from resources.lib.umbrellafile import UmbrellaFile, UmbrellaFileEnv
            UmbrellaFile(UmbrellaFileEnv(kodi), lambda: True).sync_now("car mode quality")
        except Exception:
            pass
    return car_quality(store, kodi.translate("special://profile/"), on, get, put)


def publish(kodi, listdir=os.listdir):
    """Set the Home property the skin reads; called when each profile starts. Returns (on, choice, why)."""
    store = DeviceStore(kodi.translate(STORE))
    on, choice, why = resolve(store, kodi.cond("System.Platform.Android"), listdir)
    if on:
        kodi.set_prop(CAR_PROP, "1")
    else:
        kodi.clear_prop(CAR_PROP)
    kodi.log("car mode %s (%s: %s)" % ("on" if on else "off", choice, why))
    try:
        done = _umbrella_quality(kodi, store, on)
        if done:
            kodi.log("car mode: Umbrella Max Quality %s" % ("720p" if done == "set" else "back to the profile's own"))
    except Exception as exc:   # the car quality must never stop the start-up
        kodi.log("car mode quality not applied: %s" % type(exc).__name__, "warning")
    return on, choice, why
