# -*- coding: utf-8 -*-
"""Deferred repository check: keeps NikeFlix auto-updates without the start-up repository-check deadlock.

Kodi 21.3 can deadlock when its repository update job (CRepositoryUpdateJob, scheduled 1 ms after start-up or a
profile load whenever a check is due) meets the profile load that follows the login screen pick
(CAddonMgr::m_critSection vs CProfileManager::m_critical; H3-REPO-UPDATE-LOADPROFILE-DEADLOCK on tag
archive/20261111/h3/repo-update-loadprofile-deadlock). Only general.addonupdates = 2 ("never") stops Kodi from
scheduling that check, so the builds ship 2, and this module runs the check itself at a safe moment:

  1. the profile guard has been `ready` for DELAY_S, and when the window would open nothing plays and the login
     screen is not up (otherwise the wait starts again). No GUI condition is read before that moment, and none
     while a profile switch is pending or the login screen is up (service.py calls `pause()` while the skin's
     `nikeflix.quiesce` marker is set): a getCondVisibility call in flight when a LogOff or profile load starts
     blocks until Kodi kills the service (H3; lab h3c-smoke: service.nikeflix killed at the login-screen pick);
  2. the check is due (at most once per INTERVAL_S per profile, stamp in the add-on's profile folder);
  3. open the window: write the crash marker, general.addonupdates -> 0 (install automatically), then
     `UpdateAddonRepos`. Kodi's own updater then installs NikeFlix-origin updates exactly as with the old setting;
  4. after WINDOW_S, or at profile end / abort, general.addonupdates -> 2 again (read back; the marker stays until
     2 is confirmed). A long session goes back to waiting for the next due check.
  5. a profile switch (session/quiesce.py) asks `switch_hold()`: it waits while the window is younger than
     SWITCH_SETTLE_S, then the window is closed before the switch fires.

A marker file records an open window, so a crash or kill inside it is repaired at the next start (0 -> 2).

NikeFlix 4.1.6 (Tanner's Apple TV, 2026-11-22: 4.1.5 never arrived in his profile): a profile found at 0 (install
automatically) outside a window is adopted, not left alone. 0 is what NikeFlix itself wrote before 2026-11-11 (the
wizard's T24 reset; tvOS keeps it in its stored guisettings) and it means the same to the viewer (updates install by
themselves). Left at 0, the profile had only Kodi's own once-a-day check at profile load (the H3 deadlock path): its
Addons33.db had last checked at 01:07 and planned the next check for 01:07 the next day, so a release at 12:19 waited
13 hours. The profile is now set to 2 and gets this module's window, every INTERVAL_S (6 h). Only 1 (notify, a
viewer's explicit choice) is left alone.
`request_now()` (the skin's Settings > Refresh sets the Home property nikeflix.update.now) makes the next window due
at once, still only when the profile is idle and nothing plays.
"""
import json
import os
import time

SETTING = "general.addonupdates"
MANAGED = 2          # AUTO_UPDATES_NEVER: Kodi schedules no check of its own
AUTO = 0             # AUTO_UPDATES_ON while the window is open
DELAY_S = 90.0
WINDOW_S = 60.0
FORCED_DELAY_S = 3.0   # request_now(): the profile still has to be ready and idle this long
INTERVAL_S = 6 * 3600.0
SWITCH_SETTLE_S = 30.0   # H3: a profile switch waits this long after UpdateAddonRepos (the job takes 5-10 s)
STAMP = "repoupdate.json"
START_RETRIES = 30


class RepoUpdate(object):
    def __init__(self, env, guard_ready, delay_s=DELAY_S, window_s=WINDOW_S, interval_s=INTERVAL_S):
        self.env, self.guard_ready = env, guard_ready
        self.delay_s, self.window_s, self.interval_s = delay_s, window_s, interval_s
        self.path = env.state_path(STAMP)      # resolved once: never another profile's folder at profile end
        self.state = "start"                   # start -> wait -> open -> wait ... | off
        self.ready_since = None
        self.opened_at = None
        self.start_tries = 0
        self.forced = False                    # request_now(): the next window is due at once

    # ---- persisted state -----------------------------------------------------------------------
    def _load(self):
        try:
            with open(self.path, encoding="utf-8") as fh:
                data = json.load(fh)
            return data if isinstance(data, dict) else {}
        except (OSError, ValueError):
            return {}

    def _save(self, data):
        try:
            os.makedirs(os.path.dirname(self.path), exist_ok=True)
            tmp = self.path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump(data, fh, sort_keys=True)
            os.replace(tmp, self.path)
            return True
        except OSError:
            return False

    def _set_and_confirm(self, value):
        try:
            self.env.set_setting(SETTING, value)
        except Exception:
            pass
        return self.env.get_setting(SETTING) == value

    # ---- lifecycle -------------------------------------------------------------------------------
    def poll(self):
        mono = self.env.monotonic()
        if self.state == "start":
            self.state = self._start()
            return
        if self.state == "wait":
            if not self.guard_ready():
                self.ready_since = None
                return
            if self.ready_since is None:
                self.ready_since = mono
                return
            if mono - self.ready_since < (FORCED_DELAY_S if self.forced else self.delay_s):
                return
            last = self._load().get("last_check")
            wall = self.env.now()
            if not self.forced and isinstance(last, (int, float)) and 0 <= wall - last < self.interval_s:
                return                                  # not due yet; re-evaluated while the session lasts
            if self.env.playing() or self.env.login_screen():   # GUI conditions only now (see 1. above)
                self.ready_since = None
                return
            self.forced = False
            self._open(mono, wall)
        elif self.state == "open" and mono - self.opened_at >= self.window_s:
            self._close("window over")

    def request_now(self):
        """Settings > Refresh: the next window is due now (the idle wait and the playback check still apply)."""
        if self.state in ("wait", "start"):
            self.forced = True
            self.env.log("repository check: requested now")

    def pause(self):
        """H3: a profile switch is pending or the login screen is up. No GUI call and no window now; the idle wait
        starts again afterwards. An open window stays under switch_hold() / end()."""
        if self.state == "wait":
            self.ready_since = None

    def end(self):
        """Profile end / shutdown: never leave the window open. The marker is kept even when the read-back says 2:
        while Kodi unloads the profile the write can miss its guisettings (lab control on main 6d3a63f: closed and
        read back 2 at a switch, then that profile read 0 at its next load and was no longer managed), so its next
        start checks the value again."""
        if self.state == "open":
            self._close("profile end", keep_marker=True)

    def switch_hold(self):
        """H3 (session/quiesce.py): a profile switch must not meet the repository job this window started (the same
        LoadProfile deadlock). While the window is younger than SWITCH_SETTLE_S the switch waits; after that the
        window is closed here, while the profile is still loaded, so the switch never leaves it open."""
        if self.state != "open":
            return None
        if self.env.monotonic() - self.opened_at < SWITCH_SETTLE_S:
            return "repository check running"
        self._close("profile switch")
        return None

    def _start(self):
        value = self.env.get_setting(SETTING)
        if value is None:
            self.start_tries += 1
            return "off" if self.start_tries >= START_RETRIES else "start"
        data = self._load()
        if data.get("window_open"):
            if value == AUTO:
                if not self._set_and_confirm(MANAGED):
                    self.env.log("repository check: could not restore general.addonupdates=2; retrying", "warning")
                    return "start"
                self.env.log("repository check: closed a window left open by an earlier session")
                value = MANAGED
            data["window_open"] = False
            self._save(data)
        if value == AUTO:
            if not self._set_and_confirm(MANAGED):
                self.env.log("repository check: could not adopt general.addonupdates=0; retrying", "warning")
                self.start_tries += 1
                return "off" if self.start_tries >= START_RETRIES else "start"
            self.env.log("repository check: general.addonupdates=0 adopted (2, NikeFlix runs the checks)")
            value = MANAGED
        if value != MANAGED:
            self.env.log("repository check: general.addonupdates=%s chosen in this profile; not managed" % value)
            return "off"
        return "wait"

    def _open(self, mono, wall):
        data = self._load()
        data.update({"window_open": True, "last_check": wall})
        if not self._save(data):
            self.env.log("repository check: cannot write %s; skipped" % STAMP, "warning")
            self.state, self.ready_since = "wait", None
            return
        self.state, self.opened_at = "open", mono      # from here on every failure goes through _close
        try:
            self.env.set_setting(SETTING, AUTO)
            self.env.builtin("UpdateAddonRepos")
            self.env.log("repository check: window opened (auto-install on, UpdateAddonRepos)")
        except Exception as exc:
            self._close("error %s" % type(exc).__name__)

    def _close(self, why, keep_marker=False):
        confirmed = self._set_and_confirm(MANAGED)
        if confirmed and not keep_marker:
            data = self._load()
            data["window_open"] = False
            self._save(data)
        self.state, self.ready_since, self.opened_at = "wait", None, None
        self.env.log("repository check: window closed (%s); general.addonupdates back to %d%s" % (
            why, MANAGED, " (marker kept for the next start)" if keep_marker and confirmed else
            "" if confirmed else " NOT confirmed (marker kept for the next start)"),
            "info" if confirmed else "warning")


class RepoUpdateEnv(object):
    """Real Kodi side: settings over JSON-RPC, the add-on's profile folder for the stamp."""

    def __init__(self, kodi):
        self.k = kodi

    def now(self):
        return self.k.now()

    def monotonic(self):
        return time.monotonic()

    def log(self, message, level="info"):
        self.k.log(message, level)

    def builtin(self, command):
        self.k.builtin(command)

    def playing(self):
        return self.k.cond("Player.HasMedia")

    def login_screen(self):
        return self.k.cond("Window.IsActive(loginscreen)")

    def state_path(self, name):
        return os.path.join(self.k.translate("special://profile/addon_data/service.nikeflix/"), name)

    def _rpc(self, method, params):
        import xbmc
        raw = xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": method, "params": params}))
        return json.loads(raw)

    def get_setting(self, key):
        try:
            return int(self._rpc("Settings.GetSettingValue", {"setting": key})["result"]["value"])
        except Exception:
            return None

    def set_setting(self, key, value):
        reply = self._rpc("Settings.SetSettingValue", {"setting": key, "value": value})
        if reply.get("result") is not True:
            raise RuntimeError("Settings.SetSettingValue refused")
