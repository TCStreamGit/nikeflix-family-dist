# NikeFlix changes to script.module.beautifulsoup4

This add-on is redistributed by NikeFlix under its original licence (MIT).

- Upstream: https://code.launchpad.net/beautifulsoup 4.12.2
- Upstream ZIP: https://mirrors.kodi.tv/addons/omega/script.module.beautifulsoup4/script.module.beautifulsoup4-4.12.2.zip
- Upstream sha256: 20e7e56c9f2575bc3977b7d1c875a4a56163b789a4c088a561d988f4c64fd3cd
- NikeFlix version: 4.12.2

No source changes: this is the unmodified upstream release, repackaged with this notice.
