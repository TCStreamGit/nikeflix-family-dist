# NikeFlix changes to script.module.idna

This add-on is redistributed by NikeFlix under its original licence (BSD-3-Clause).

- Upstream: https://github.com/kjd/idna 3.10.0
- Upstream ZIP: https://mirrors.kodi.tv/addons/omega/script.module.idna/script.module.idna-3.10.0.zip
- Upstream sha256: c4ff34dbfab2736e9214a374d331bd6f558d8b3fea8eb7902e210749509242b3
- NikeFlix version: 3.10.0

No source changes: this is the unmodified upstream release, repackaged with this notice.
