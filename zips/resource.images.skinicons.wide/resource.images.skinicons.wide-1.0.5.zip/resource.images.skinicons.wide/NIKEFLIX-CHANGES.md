# NikeFlix changes to resource.images.skinicons.wide

This add-on is redistributed by NikeFlix under its original licence (GPL-3.0-only).

- Upstream: https://github.com/cartmandos/resource.images.skinicons.wide/ 1.0.5
- Upstream ZIP: https://raw.githubusercontent.com/AchillesPunks/repository.titan.bingie.mod/master/omega/resource.images.skinicons.wide/resource.images.skinicons.wide-1.0.5.zip
- Upstream sha256: 1b4469973407cc46eb80d227877cdac5f755fcb562c2b0f9129a149e1d73596d
- NikeFlix version: 1.0.5

No source changes: this is the unmodified upstream release, repackaged with this notice.
