# NikeFlix changes to script.black.bars.never

This add-on is redistributed by NikeFlix under its original licence (MIT).

- Upstream: https://github.com/osumoclement/script.black.bars.never 1.0.11
- Upstream ZIP: https://mirrors.kodi.tv/addons/omega/script.black.bars.never/script.black.bars.never-1.0.11.zip
- Upstream sha256: dc3ad7ac4adbb3e37d0c87965759878ba7bf8c1c8cbb4cd95c8474461ecc22fc
- NikeFlix version: 1.0.11+nikeflix.1

## Patches

- `0001-quiet-mode-automatic-status.patch`: Quiet Mode step 3 (T34 entry BBN-AUTO-STATUS): with service.nikeflix quiet.enabled on, the automatic pass at every playback start (onAVStarted) no longer toasts 'Showing original aspect ratio' (MD-13 ships automatically_execute=false, so it fired on every play) or its zoom/aspect messages, and logs 'NikeFlix Quiet Mode: hid ...' instead; the zoom itself is unchanged, and the toggle the user runs keeps its toast. Quiet Mode off or no service.nikeflix behaves as upstream. Evidence docs/evidence/T34-QUIET-MODE-STEP3.md.
