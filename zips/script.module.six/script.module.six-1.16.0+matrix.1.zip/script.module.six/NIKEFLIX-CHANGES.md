# NikeFlix changes to script.module.six

This add-on is redistributed by NikeFlix under its original licence (MIT).

- Upstream: https://github.com/benjaminp/six 1.16.0+matrix.1
- Upstream ZIP: https://mirrors.kodi.tv/addons/omega/script.module.six/script.module.six-1.16.0+matrix.1.zip
- Upstream sha256: 4197f7773f75ab9f16b3c920195acbb8b8b151b4b3c8c3e14fc4876e764e3860
- NikeFlix version: 1.16.0+matrix.1

No source changes: this is the unmodified upstream release, repackaged with this notice.
