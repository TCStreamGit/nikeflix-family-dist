# NikeFlix changes to weather.openmeteo

This add-on is redistributed by NikeFlix under its original licence (GPL-2.0-or-later).

- Upstream: https://mirrors.kodi.tv/addons/omega/addons.xml.gz 1.0.29
- Upstream ZIP: https://mirrors.kodi.tv/addons/omega/weather.openmeteo/weather.openmeteo-1.0.29.zip
- Upstream sha256: 7c8be370a5ca480a638435daf9e5b455146b2d6c8949222bb4d829bd61d485ab
- NikeFlix version: 1.0.29

No source changes: this is the unmodified upstream release, repackaged with this notice.
