from tmdbhelper.lib.addon.permissions import __access__
from tmdbhelper.lib.api.api_keys.tokenhandler import TokenHandler


def nikeflix_broker_client_id():
    """NikeFlix Trakt Hub (service.nikeflix): the profile's Trakt sign-in is made once, in NikeFlix's Trakt Account,
    with the NikeFlix Trakt app (a public client: client id only, no secret) and pushed into `trakt_token`. While the
    broker is active this returns its client id, so requests carry the client the token belongs to; '' otherwise."""
    try:
        from xbmcgui import Window
        window = Window(10000)
        if window.getProperty('nikeflix.trakt.broker') == 'true':
            return window.getProperty('nikeflix.trakt.client_id') or ''
    except Exception:
        pass
    return ''

if __access__.has_access('internal'):
    CLIENT_ID = 'e6fde6173adf3c6af8fd1b0694b9b84d7c519cefc24482310e1de06c6abe5467'
    CLIENT_SECRET = '15119384341d9a61c751d8d515acbc0dd801001d4ebe85d3eef9885df80ee4d9'
    USER_TOKEN = TokenHandler('trakt_token', store_as='setting')

elif __access__.has_access('trakt'):
    CLIENT_ID = ''
    CLIENT_SECRET = ''
    USER_TOKEN = TokenHandler('trakt_token', store_as='setting')

else:
    CLIENT_ID = ''
    CLIENT_SECRET = ''
    USER_TOKEN = TokenHandler()
