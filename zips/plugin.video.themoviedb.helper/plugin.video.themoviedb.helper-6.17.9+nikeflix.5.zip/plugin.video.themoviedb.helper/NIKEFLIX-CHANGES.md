# NikeFlix changes to plugin.video.themoviedb.helper

This add-on is redistributed by NikeFlix under its original licence (GPL-3.0-or-later).

- Upstream: https://github.com/jurialmunkey/plugin.video.themoviedb.helper 6.17.9
- Upstream ZIP: https://raw.githubusercontent.com/jurialmunkey/repository.jurialmunkey/master/omega/zips/plugin.video.themoviedb.helper/plugin.video.themoviedb.helper-6.17.9.zip
- Upstream sha256: b1023f7fc82b2d3c037758384fcd32ea6b906f2551be674859c0e1deb37f7989
- NikeFlix version: 6.17.9+nikeflix.5

## Patches

- `0001-h3-switch-quiescence.patch`: H3 Option C (DEC-H3-C-STAGING, staged, not released): Poller.poller (ServiceMonitor + ImagesMonitor) and the Cron Thread (1-s waits, no maintenance pass on abort) skips its pass and acknowledges while a NikeFlix profile switch is pending, so Kodi does not have to kill it during LogOff; the added nikeflix_quiesce.py reads one Home window property only (no global getCondVisibility replacement; every pause ends on its own). Evidence docs/evidence/H3-QUIESCE-V5.md.
- `0002-h3-scrobbler-gettime-guard.patch`: H3-TMDB-SCROBBLER-01 (staged, not released; narrowed per DEC-H3-TMDB-GUARD-REVIEW-01): PlayerMonitor.scrobbler_sync()/scrobbler_update() checked isPlayingVideo() and then called Player.getTime(); when playback ends in between, getTime() raises RuntimeError('Kodi is not playing any media file'), which nothing caught, so the ServiceMonitor poll thread died (no widgets/listitem service until restart, and a pending profile switch was never acknowledged). getTime() alone is now called through nikeflix_get_time(), which returns None for exactly that RuntimeError text (one LOGDEBUG line naming H3-TMDB-SCROBBLER-01, the runtime evidence marker); sync then returns and update keeps the last scrobble time. getTotalTime(), the ZeroDivisionError handling, any other RuntimeError and every other exception are unchanged and still raise. Evidence docs/evidence/H3-ROLLBACK-ACCEPTANCE.md.
- `0003-trakt-hub-broker.patch`: NikeFlix Trakt Hub (T30/T31/T33, TRAKT-REGISTER disposition A): while service.nikeflix publishes the broker (Home property nikeflix.trakt.broker=true with nikeflix.trakt.client_id), TraktAPI sends the NikeFlix public client id (no secret) so requests carry the client the pushed trakt_token belongs to; the TMDbHelper login prompt (ask_to_login) is skipped and logged, logout opens NikeFlix's Trakt Account, and a failed refresh sets nikeflix.trakt.refresh_requested so the broker refreshes and pushes again. Without the broker everything is upstream. Evidence docs/evidence/T33-TRAKT-HUB.md.
- `0004-continue-watching-one-per-show.patch`: NikeFlix 4.1.4 (Tanner 2026-11-21): the paused lists behind Continue Watching (trakt_ondeck playback and unwatched playback) keep one entry per show, its most recently paused episode (the list is already sorted by paused time, newest first); movies are unchanged. Before, a show with several paused episodes filled the row with the same show.
