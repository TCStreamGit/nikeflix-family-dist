# -*- coding: utf-8 -*-
"""NikeFlix 4.1.5 (Tanner 2026-11-21): a profile without Trakt (Guest) keeps its own watch history on the device.

Umbrella keeps it in the profile: addon_data/plugin.video.umbrella/watched.db, table "progress" (paused episodes and
films with their resume point) and table "watched" (what was watched to the end), each row with when (last_played,
seconds since 1970). Umbrella patch 0011 makes Umbrella write both for a profile without Trakt (it wrote no resume
points when its resume source was Trakt and nobody was signed in) and records the show's TMDb id on watched episodes.

From that, Continue Watching is made with the same rules as the Trakt one (nikeflix_continue.continue_watching): one
card per show, the paused episode when pausing it was the latest, otherwise the episode after the last one watched
(the next aired one, from TMDb), paused films too; newest first. Recently Watched (Search) is every title by its last
activity. Nothing here talks to Trakt.

local_inputs() is pure (rows in, lists out) and unit-tested; read_rows() and the TMDb lookups are the Kodi side.
"""
import datetime
import os

DB = 'special://profile/addon_data/plugin.video.umbrella/watched.db'
WATCHED = 5   # Umbrella's overlay value for watched


def iso(seconds):
    """Umbrella's last_played (seconds) -> the ISO form nikeflix_continue compares ("2026-11-21T03:12:45")."""
    try:
        return datetime.datetime.fromtimestamp(int(float(seconds)), datetime.timezone.utc).strftime('%Y-%m-%dT%H:%M:%S')
    except (TypeError, ValueError, OverflowError, OSError):
        return ''


def _int(value):
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def next_episode(season, episode, seasons, last_aired=None):
    """The episode after (season, episode): the next in that season, else the first of the next season with episodes.
    seasons: {season number: episode count}; last_aired: (season, episode) of the last aired one (None = all aired).
    -> (season, episode) or None (caught up, or the next one has not aired)."""
    s, e = _int(season), _int(episode)
    if s is None or e is None:
        return None
    if e < (seasons.get(s) or 0):
        nxt = (s, e + 1)
    else:
        later = sorted(n for n, count in seasons.items() if n and n > s and count)
        if not later:
            return None
        nxt = (later[0], 1)
    if last_aired and nxt > tuple(last_aired):
        return None
    return nxt


def local_inputs(progress, watched, tmdb_for, show_info, item_type='both'):
    """Umbrella's rows -> the keyword arguments of nikeflix_continue.continue_watching.

    progress: dicts media_type, imdb_id, tmdb_id, season, episode, title, last_played (Umbrella's progress table)
    watched:  dicts media_type, imdb_id, tmdb_id, season, episode, title, last_played, overlay (its watched table)
    tmdb_for(media_type, imdb_id) -> TMDb id or None, for rows Umbrella stored without one
    show_info(tmdb_id) -> ({season: episode count}, (last aired season, episode) or None) or None"""
    shows = item_type in ('episode', 'show', 'tv', 'both')
    movies = item_type in ('movie', 'both')
    known = {}
    for r in list(progress or ()) + list(watched or ()):
        if r.get('imdb_id') and r.get('tmdb_id'):
            known[(r.get('media_type'), r['imdb_id'])] = str(r['tmdb_id'])

    def tid(r):
        if r.get('tmdb_id'):
            return str(r['tmdb_id'])
        key = (r.get('media_type'), r.get('imdb_id'))
        if key not in known and r.get('imdb_id'):
            known[key] = tmdb_for(r.get('media_type'), r['imdb_id'])
        return known.get(key)

    paused, paused_movies = [], []
    for r in progress or ():
        t = tid(r)
        if not t:
            continue
        row = {'id': t, 'title': r.get('title') or '', 'paused_at': iso(r.get('last_played'))}
        if r.get('media_type') == 'episode':
            row.update(season=_int(r.get('season')), episode=_int(r.get('episode')))
            paused.append(row)
        elif r.get('media_type') == 'movie':
            paused_movies.append(row)
    last = {}
    for r in watched or ():
        if r.get('media_type') != 'episode' or _int(r.get('overlay')) != WATCHED or not _int(r.get('season')):
            continue
        t = tid(r)
        if not t:
            continue
        when = iso(r.get('last_played'))
        if t not in last or (when, _int(r.get('season')), _int(r.get('episode'))) > last[t][:3]:
            last[t] = (when, _int(r.get('season')), _int(r.get('episode')), r.get('title') or '')
    next_up, last_watched = [], {}
    for t, (when, s, e, title) in last.items():
        last_watched[t] = when
        info = show_info(t) if shows else None
        nxt = next_episode(s, e, info[0], info[1]) if info else None
        if nxt:
            next_up.append({'id': t, 'title': title, 'season': nxt[0], 'episode': nxt[1], 'last_watched_at': when})
    return {'paused': paused if shows else (), 'next_up': next_up if shows else (),
            'movies': paused_movies if movies else (), 'hidden': (), 'last_watched': last_watched if shows else None}


def recent(progress, watched, tmdb_for, item_type='both'):
    """Recently Watched for Search: every show and film by its last activity, newest first, one each.
    -> TMDb Helper items {'id', 'mediatype' ('show' or 'movie'), 'title'}."""
    best, memo = {}, {}
    for r in list(progress or ()) + list(watched or ()):
        kind = r.get('media_type')
        if kind not in ('episode', 'movie') or (kind == 'movie' and item_type not in ('movie', 'both'))                 or (kind == 'episode' and item_type not in ('episode', 'show', 'tv', 'both')):
            continue
        t = str(r['tmdb_id']) if r.get('tmdb_id') else None
        if not t and r.get('imdb_id'):
            if (kind, r['imdb_id']) not in memo:
                memo[(kind, r['imdb_id'])] = tmdb_for(kind, r['imdb_id'])
            t = memo[(kind, r['imdb_id'])]
        if not t:
            continue
        mediatype = 'show' if kind == 'episode' else 'movie'
        when = iso(r.get('last_played'))
        if (mediatype, t) not in best or when > best[(mediatype, t)][0]:
            best[(mediatype, t)] = (when, r.get('title') or '')
    items = sorted(best.items(), key=lambda kv: kv[1][0], reverse=True)
    return [{'id': t, 'mediatype': m, 'title': title} for (m, t), (_, title) in items]


def read_rows(path=None):
    """-> (progress rows, watched rows) from this profile's Umbrella watched.db (read only), or ([], [])."""
    import sqlite3
    if path is None:
        from xbmcvfs import translatePath
        path = translatePath(DB)
    if not os.path.isfile(path):
        return [], []
    con = sqlite3.connect('file:%s?mode=ro' % path.replace('\\', '/'), uri=True, timeout=5)
    con.row_factory = sqlite3.Row
    try:
        def rows(sql):
            try:
                return [dict(r) for r in con.execute(sql).fetchall()]
            except sqlite3.Error:
                return []
        return (rows('SELECT media_type, imdb_id, tmdb_id, season, episode, title, last_played FROM progress'),
                rows('SELECT media_type, imdb_id, tmdb_id, season, episode, title, last_played, overlay FROM watched'))
    finally:
        con.close()


class LocalHistory:
    """The Kodi side: this profile's rows and TMDb lookups through TMDb Helper's own (cached) TMDb client."""

    def __init__(self, item_type='both'):
        self.item_type = item_type
        self._tmdb = None

    @property
    def tmdb(self):
        if self._tmdb is None:
            from tmdbhelper.lib.api.tmdb.api import TMDb
            self._tmdb = TMDb()
        return self._tmdb

    def tmdb_for(self, media_type, imdb_id):
        try:
            return self.tmdb.get_tmdb_id(tmdb_type='tv' if media_type == 'episode' else 'movie', imdb_id=imdb_id)
        except Exception:
            return None

    def show_info(self, tmdb_id):
        try:
            data = self.tmdb.get_response_json('tv', tmdb_id) or {}
        except Exception:
            return None
        seasons = {_int(s.get('season_number')): _int(s.get('episode_count')) or 0 for s in data.get('seasons') or []}
        last = data.get('last_episode_to_air') or {}
        aired = (_int(last.get('season_number')), _int(last.get('episode_number')))
        return seasons, (aired if None not in aired else None)

    def continue_items(self):
        from tmdbhelper.lib.sync.nikeflix_continue import continue_watching
        progress, watched = read_rows()
        return continue_watching(**local_inputs(progress, watched, self.tmdb_for, self.show_info, self.item_type))

    def recent_items(self):
        progress, watched = read_rows()
        return recent(progress, watched, self.tmdb_for, self.item_type)
