# -*- coding: utf-8 -*-
"""NikeFlix 4.1.5 (Tanner 2026-11-21): the episode to continue, the way Netflix picks it. Pure Python, no Kodi.

- next_after_last_watched(progress): the next episode after the most recently watched one (Trakt's next_episode).
  Never an earlier unwatched episode: a gap left behind (E3 and E4 skipped, E5 to E15 watched) or an unwatched
  episode one of a show already started is not where the show continues.
- episodes_from(progress, start): Up Next for one show, from that episode on, skipping episodes already watched.
- continue_watching(paused, next_up, movies, hidden): Continue Watching, one card per show. The paused episode with
  its resume point when pausing it was the show's latest activity, otherwise the next episode after the last watched
  one; paused movies by their pause; newest activity first.
- paused_first(items, paused, last_watched_at): the same choice for one show's Up Next (the title page's Resume).

Trakt timestamps are ISO 8601 UTC strings ("2026-11-21T03:12:45.000Z"); their first 19 characters compare in time
order.
"""
import datetime


def _ts(value):
    return str(value or '')[:19]


def _int(value):
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _episodes(progress):
    """[(season, number, watched, last_watched_at)] in airing order, specials left out. With a progress reset
    (Trakt reset_at) only plays after the reset count as watched."""
    reset_at = _ts((progress or {}).get('reset_at'))
    out = []
    for season in (progress or {}).get('seasons') or []:
        s = _int(season.get('number'))
        if not s:
            continue
        for ep in season.get('episodes') or []:
            n = _int(ep.get('number'))
            if n is None:
                continue
            watched_at = _ts(ep.get('last_watched_at'))
            watched = bool(ep.get('completed')) and (not reset_at or watched_at >= reset_at)
            out.append((s, n, watched, watched_at))
    out.sort(key=lambda e: (e[0], e[1]))
    return out


def _is_aired(episode, now=None):
    aired = _ts((episode or {}).get('first_aired'))
    if not aired:
        return False
    now = now or datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%dT%H:%M:%S')
    return aired <= _ts(now)


def next_after_last_watched(progress, now=None):
    """(season, number) of the episode to continue, or None when the show is caught up."""
    eps = _episodes(progress)
    if not eps:
        return None
    watched = [i for i, e in enumerate(eps) if e[2]]
    if not watched:  # started but nothing counts (a progress reset): from the start
        return eps[0][0], eps[0][1]
    last = max(watched, key=lambda i: (eps[i][3], i))
    last_key = (eps[last][0], eps[last][1])
    nxt = (progress or {}).get('next_episode') or {}
    key = (_int(nxt.get('season')), _int(nxt.get('number')))
    if not (progress or {}).get('reset_at') and None not in key and key > last_key and _is_aired(nxt, now):
        return key
    for s, n, is_watched, _ in eps[last + 1:]:
        if not is_watched:
            return s, n
    return None


def episodes_from(progress, start):
    """Up Next for one show: `start`, then every later episode not watched yet."""
    if not start:
        return []
    start = (_int(start[0]), _int(start[1]))
    out = [start]
    for s, n, is_watched, _ in _episodes(progress):
        if (s, n) > start and not is_watched:
            out.append((s, n))
    return out


def _sid(value):
    return str(value) if value not in (None, '') else ''


def continue_watching(paused=(), next_up=(), movies=(), hidden=(), last_watched=None):
    """Continue Watching, newest activity first, one card per show.

    paused:  episodes with a resume point, dicts id (the show's TMDb id), title, season, episode, paused_at
    next_up: one per show, dicts id, title, season, episode (the next after the last watched), last_watched_at
    movies:  paused movies, dicts id, title, paused_at
    hidden:  TMDb ids of shows removed from Continue Watching (Trakt dropped / hidden from progress)
    last_watched: {show TMDb id: last_watched_at}; a paused episode of a show with no next episode (finished or caught
             up) is left out when the show was watched after the pause
    Returns TMDb Helper items: {'id', 'mediatype', 'title'[, 'season', 'episode']}."""
    hidden = {_sid(i) for i in hidden or ()}
    latest = {}
    for p in paused or ():
        sid = _sid(p.get('id'))
        if not sid or sid in hidden:
            continue
        if sid not in latest or _ts(p.get('paused_at')) > _ts(latest[sid].get('paused_at')):
            latest[sid] = p
    cards = []
    seen = set()
    for n in next_up or ():
        sid = _sid(n.get('id'))
        if not sid or sid in hidden or sid in seen:
            continue
        seen.add(sid)
        p = latest.get(sid)
        if p and _ts(p.get('paused_at')) >= _ts(n.get('last_watched_at')):
            cards.append((_ts(p.get('paused_at')), p))
        else:
            cards.append((_ts(n.get('last_watched_at')), n))
    watched = {_sid(k): _ts(v) for k, v in (last_watched or {}).items()}
    for sid, p in latest.items():
        if sid not in seen and _ts(p.get('paused_at')) >= watched.get(sid, ''):
            cards.append((_ts(p.get('paused_at')), p))
    items = [(when, {'id': c.get('id'), 'mediatype': 'episode', 'title': c.get('title'),
                     'season': c.get('season'), 'episode': c.get('episode')}) for when, c in cards]
    for m in movies or ():
        if _sid(m.get('id')):
            items.append((_ts(m.get('paused_at')), {'id': m.get('id'), 'mediatype': 'movie', 'title': m.get('title')}))
    items.sort(key=lambda x: x[0], reverse=True)
    return [i for _, i in items]


def paused_first(items, paused=None, last_watched_at=None):
    """One show's Up Next with its paused episode first when pausing it was the show's latest activity."""
    items = list(items or ())
    if not paused or _ts(paused.get('paused_at')) < _ts(last_watched_at):
        return items
    key = (_int(paused.get('season')), _int(paused.get('episode')))
    same = [i for i in items if (_int(i.get('season')), _int(i.get('episode'))) == key]
    rest = [i for i in items if (_int(i.get('season')), _int(i.get('episode'))) != key]
    first = same[0] if same else {'id': paused.get('id'), 'mediatype': 'episode', 'title': paused.get('title'),
                                  'season': paused.get('season'), 'episode': paused.get('episode')}
    return [first] + rest
