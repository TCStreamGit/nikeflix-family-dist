#!/usr/bin/python
# -*- coding: utf-8 -*-
from jurialmunkey.ftools import cached_property
from collections import namedtuple


class ItemListSyncDataProperties:
    @cached_property
    def items(self):
        if not self.syncdata:
            return
        return self.get_items()

    @cached_property
    def additional_keys(self):
        return self.get_additional_keys()

    @cached_property
    def syncdata_getter(self):
        return self.get_syncdata_getter()

    @cached_property
    def presorted_items(self):
        return self.get_presorted_items()

    @cached_property
    def sort_method(self):
        return self.get_sort_method()

    @cached_property
    def sort_key(self):
        return self.get_sort_key()

    @cached_property
    def nonetype(self):
        return self.get_nonetype()

    @cached_property
    def reverse(self):
        return self.get_reverse()

    @property
    def syncdata(self):
        from tmdbhelper.lib.sync.datasync import SyncDataFactory
        return SyncDataFactory(self)

    @cached_property
    def namedtuple_basic(self):
        BasicTuple = namedtuple("BasicTuple", "item mediatype")
        return BasicTuple

    @cached_property
    def namedtuple_episode(self):
        EpisodeTuple = namedtuple("EpisodeTuple", "item mediatype season_number episode_number")
        return EpisodeTuple

    @property
    def item_types(self):
        if self.item_type == 'both':
            return ('movie', 'show', )
        return (self.item_type, )


def nikeflix_one_per_show(items):
    """NikeFlix: one entry per show in the paused (Continue Watching) lists, the most recently paused episode.
    The list arrives sorted by paused time, newest first, so the first episode of each show is the one to keep;
    movies pass through unchanged."""
    if not items:
        return items
    seen, out = set(), []
    for item in items:
        if item.get('mediatype') == 'episode':
            key = item.get('id')
            if key in seen:
                continue
            seen.add(key)
        out.append(item)
    return out


class ItemListSyncDataMethods:
    def sort_data(self, data):
        if self.sort_by == 'random':
            import random
            random.shuffle(data)
            return data
        if not self.additional_keys:
            return data
        return sorted(data, key=lambda x: x[0][self.sort_key] if x[0][self.sort_key] is not None else self.nonetype, reverse=self.reverse)

    def make_list(self, sd_func):
        data = []
        for item_type in self.item_types:
            sd = sd_func(item_type)
            sd.additional_keys = self.additional_keys
            data += [self.namedtuple_basic(i, item_type, ) for i in sd.items] if sd.items else []

        if not data:
            return

        data = sorted(data, key=lambda x: x.item[sd.clause_keys[0]], reverse=True)
        return [self.make_item(i) for i in self.sort_data(data) if i]

    def make_item(self, i):
        item = {'id': i.item['tmdb_id'], 'mediatype': i.mediatype, 'title': i.item['title']}
        if i.mediatype in ('season', 'episode', ):
            item['season'] = i.season_number if 'season_number' in i._fields else i.item['season_number']
        if i.mediatype == 'episode':
            item['episode'] = i.episode_number if 'episode_number' in i._fields else i.item['episode_number']
        for k in (self.item_keys or ()):
            try:
                item.setdefault('infoproperties', {})[k] = i.item[k]
            except IndexError:
                pass
        return item


class ItemListSyncData(ItemListSyncDataProperties, ItemListSyncDataMethods):

    # Tuple of column_name, reverse_sort, fallback_nonetype
    sort = {
        'year': ('year', True, 0, ),
        'released': ('premiered', True, '', ),
        'title': ('title', True, '', ),
        'watched': ('last_watched_at', True, '', ),
        'paused': ('playback_paused_at', True, '', ),
        'votes': ('trakt_votes', True, 0, ),
        'plays': ('plays', True, 0, ),
        'runtime': ('runtime', True, 0, ),
        'collected': ('collection_last_collected_at', True, '', ),
        'airdate': ('last_watched_at', True, '', ),
        'todays': ('last_watched_at', True, '', ),
        'lastweek': ('last_watched_at', True, '', ),
    }

    def __init__(self, trakt_api, item_type=None, sort_by=None, sort_how=None, item_keys=None, tmdb_id=None):
        self.trakt_api = trakt_api
        self.sort_by, self.sort_how = sort_by, sort_how
        self.item_keys = item_keys or ()
        self.item_type = item_type
        self.tmdb_id = tmdb_id

    def get_sort_method(self):
        try:
            return self.sort[self.sort_by]
        except KeyError:
            return

    def get_sort_key(self):
        try:
            return self.sort_method[0]
        except TypeError:  # No sort method
            return

    def get_additional_keys(self):
        try:
            return (self.sort_method[0], *self.item_keys)
        except TypeError:  # No sort method
            return

    def get_reverse(self):
        try:
            reverse = self.sort_method[1]
        except TypeError:  # No sort method
            return
        if self.sort_how != 'asc':
            return reverse
        return not reverse

    def get_nonetype(self):
        try:
            return self.sort_method[2]
        except TypeError:  # No sort method
            return


class ItemListSyncDataCollection(ItemListSyncData):
    """ Items in collection """

    def get_items(self):
        return self.make_list(self.syncdata.get_all_collected_getter)


class ItemListSyncDataWatchlist(ItemListSyncData):
    """ Items on watchlist """

    def get_items(self):
        return self.make_list(self.syncdata.get_all_watchlist_getter)


class ItemListSyncDataReleasedWatchlist(ItemListSyncData):
    """ Items on watchlist that have been released """

    def get_items(self):
        return self.make_list(self.syncdata.get_all_released_watchlist_getter)


class ItemListSyncDataAnticipatedWatchlist(ItemListSyncData):
    """ Items on watchlist that have been released """

    def get_items(self):
        return self.make_list(self.syncdata.get_all_anticipated_watchlist_getter)


class ItemListSyncDataWatched(ItemListSyncData):
    """ Items that have been watched """

    def get_items(self):
        return self.make_list(self.syncdata.get_all_watched_getter)


class ItemListSyncDataPlayback(ItemListSyncData):
    """ Episodes and movies partially watched with resume points """

    def get_items(self):
        return nikeflix_one_per_show(self.make_list(self.syncdata.get_all_playback_getter))


class ItemListSyncDataFavorites(ItemListSyncData):
    """ Items in favourites """

    def get_items(self):
        return self.make_list(self.syncdata.get_all_favorites_getter)


class ItemListSyncDataDropped(ItemListSyncData):
    """ Items in favourites """

    def get_items(self):
        return self.make_list(self.syncdata.get_all_dropped_shows_getter)


class ItemListSyncDataUnwatchedPlayback(ItemListSyncData):
    """ Episodes and movies partially watched with resume points """

    def get_items(self):
        return nikeflix_one_per_show(self.make_list(self.syncdata.get_all_unwatched_playback_getter))


class ItemListSyncDataToWatch(ItemListSyncData):
    """ Mix of watchlist and inprogress items """

    @cached_property
    def presorted_fallback_key(self):
        if self.item_type == 'movie':
            return 'playback_paused_at'
        return 'last_watched_at'

    @cached_property
    def syncdata_getter_func(self):
        if self.item_type == 'movie':
            return self.syncdata.get_all_unhidden_movies_towatch_getter
        return self.syncdata.get_all_unhidden_shows_towatch_getter

    def get_syncdata_getter(self):
        sd = self.syncdata_getter_func()
        sd.additional_keys = (self.presorted_fallback_key, *self.item_keys, )
        return sd

    def get_presorted_items(self):
        return sorted(self.syncdata_getter.items, key=lambda x: x['watchlist_listed_at'] or x[self.presorted_fallback_key], reverse=True)

    def get_items(self):
        data = [self.namedtuple_basic(i, self.item_type, ) for i in self.presorted_items]
        return [self.make_item(i) for i in self.sort_data(data) if i]


class ItemListSyncDataInProgress(ItemListSyncData):
    """ Partially watched shows that are inprogress """

    def get_syncdata_getter(self):
        sd = self.syncdata.get_all_unhidden_shows_inprogress_getter()
        sd.additional_keys = self.additional_keys
        return sd

    def get_presorted_items(self):
        return sorted(self.syncdata_getter.items, key=lambda x: x['last_watched_at'], reverse=True)

    def get_items(self):
        data = [self.namedtuple_basic(i, 'show', ) for i in self.presorted_items]
        return [self.make_item(i) for i in self.sort_data(data) if i]


class ItemListSyncDataNextUp(ItemListSyncData):
    """ Episodes next up to watch for all inprogress shows """
    sort_method = ('last_watched_at', True, '', )

    def get_syncdata_getter(self):
        sd = self.syncdata.get_all_unhidden_shows_nextepisode_getter()
        sd.additional_keys = ('next_episode_aired_at', *self.additional_keys)
        return sd

    def get_presorted_items(self):
        key_presorted = 'next_episode_aired_at' if self.sort_by == 'airdate' else 'last_watched_at'
        return sorted(self.syncdata_getter.items, key=lambda x: x[key_presorted] or '', reverse=True)

    @cached_property
    def sort_by_days(self):
        return -1 if self.sort_by == 'todays' else -7

    def get_special_sorted_item_tuple(self, item):
        from tmdbhelper.lib.addon.tmdate import is_future_timestamp
        if not item['next_episode_aired_at']:
            return (None, item)
        if not is_future_timestamp(
            item['next_episode_aired_at'],
            time_fmt="%Y-%m-%d",
            time_lim=10,
            use_today=True,
            days=self.sort_by_days
        ):
            return (None, item)
        return (item, None)

    @cached_property
    def airsorted_items(self):
        items_a, items_z = zip(*[
            self.get_special_sorted_item_tuple(i)
            for i in self.presorted_items
        ])
        items_a = [i for i in items_a if i]
        items_z = [i for i in items_z if i]
        items_a = sorted(items_a, key=lambda x: x['next_episode_aired_at'], reverse=True)
        return items_a + items_z

    def get_namedtupled_items(self, data):
        return [
            self.make_item(j)
            for j in (
                self.namedtuple_episode(
                    i,
                    'episode',
                    i['next_episode_id'].split('.')[2],
                    i['next_episode_id'].split('.')[3],
                ) for i in data
            ) if j
        ]

    def get_items(self):
        if self.sort_by in ('todays', 'lastweek'):
            return self.get_namedtupled_items(self.airsorted_items)
        if self.sort_by in ('airdate', 'recentlywatched'):
            return self.get_namedtupled_items(self.presorted_items)


class ItemListSyncDataUpNext(ItemListSyncData):
    """ Episodes Up Next for specific tmdb_id show """

    def get_syncdata_getter(self):
        sd = self.syncdata.get_unhidden_show_episodes_upnext(self.tmdb_id)
        sd.additional_keys = self.additional_keys
        return sd

    def get_presorted_items(self):
        items = [
            self.namedtuple_episode(i, 'episode', i['upnext_episode_id'].split('.')[2], i['upnext_episode_id'].split('.')[3], )
            for i in self.syncdata_getter.items]
        return sorted(items, key=lambda i: (int(i.season_number), int(i.episode_number)))  # NikeFlix: in airing order

    def get_items(self):
        from tmdbhelper.lib.sync.nikeflix_continue import paused_first
        items = [self.make_item(i) for i in self.sort_data(self.presorted_items) if i]
        return paused_first(items, self.nikeflix_paused, self.nikeflix_last_watched_at)

    @cached_property
    def nikeflix_paused(self):
        """ NikeFlix 4.1.5: this show's most recently paused episode (it goes first when pausing it was the
        show's latest activity, so the title page's Resume picks it) """
        sd = self.syncdata.get_all_playback_getter('episode')
        sd.additional_keys = ('playback_paused_at', )
        paused = [i for i in (sd.items or []) if str(i['tmdb_id']) == str(self.tmdb_id)]
        if not paused:
            return
        i = max(paused, key=lambda x: x['playback_paused_at'] or '')
        return {'id': i['tmdb_id'], 'title': i['title'], 'season': i['season_number'], 'episode': i['episode_number'],
                'paused_at': i['playback_paused_at']}

    @cached_property
    def nikeflix_last_watched_at(self):
        return self.syncdata.get_value('tv', self.tmdb_id, key='last_watched_at')


class NikeFlixHiddenShowsGetter:
    """ NikeFlix 4.1.5: shows removed from Continue Watching (Trakt dropped, or hidden from progress) """

    def __init__(self, syncdata):
        from tmdbhelper.lib.sync.datasync import SyncDataGetterAll

        class Getter(SyncDataGetterAll):
            query_values = ('show', )
            clause_keys = ('dropped_hidden_at', 'progress_watched_hidden_at', )

        self.getter = Getter(syncdata)

    @property
    def ids(self):
        return [i['tmdb_id'] for i in (self.getter.items or [])]


class ItemListSyncDataNikeFlixContinue(ItemListSyncData):
    """ NikeFlix 4.1.5 Continue Watching (trakt_ondeck with nikeflix=continue), Netflix-style: one card per show,
    the paused episode with its resume point when pausing it was the show's latest activity, otherwise the next
    episode after the last watched one; paused movies too when the list holds movies; newest activity first """

    def nikeflix_paused(self, item_type):
        sd = self.syncdata.get_all_playback_getter(item_type)
        sd.additional_keys = ('playback_paused_at', )
        out = []
        for i in (sd.items or []):
            row = {'id': i['tmdb_id'], 'title': i['title'], 'paused_at': i['playback_paused_at']}
            if item_type == 'episode':
                row.update(season=i['season_number'], episode=i['episode_number'])
            out.append(row)
        return out

    def nikeflix_next_up(self):
        sd = self.syncdata.get_all_unhidden_shows_nextepisode_getter()
        sd.additional_keys = ('last_watched_at', )
        out = []
        for i in (sd.items or []):
            try:
                _, _, season, episode = i['next_episode_id'].split('.')
            except (AttributeError, ValueError):
                continue
            out.append({'id': i['tmdb_id'], 'title': i['title'], 'season': season, 'episode': episode,
                        'last_watched_at': i['last_watched_at']})
        return out

    def nikeflix_last_watched(self):
        sd = self.syncdata.get_all_unhidden_shows_started_getter()
        sd.additional_keys = ()
        return {i['tmdb_id']: i['last_watched_at'] for i in (sd.items or [])}

    @property
    def nikeflix_local(self):
        """ NikeFlix 4.1.5: a profile without Trakt (Guest) uses its own watch history (sync/nikeflix_local.py) """
        try:
            return not self.trakt_api.authenticator.is_authorized
        except Exception:
            return True

    def get_items(self):
        from tmdbhelper.lib.sync.nikeflix_continue import continue_watching
        if self.nikeflix_local:
            from tmdbhelper.lib.sync.nikeflix_local import LocalHistory
            return LocalHistory(self.item_type).continue_items() or None
        shows = self.item_type in ('episode', 'show', 'both')
        movies = self.item_type in ('movie', 'both')
        return continue_watching(
            paused=self.nikeflix_paused('episode') if shows else (),
            next_up=self.nikeflix_next_up() if shows else (),
            movies=self.nikeflix_paused('movie') if movies else (),
            hidden=NikeFlixHiddenShowsGetter(self.syncdata).ids if shows else (),
            last_watched=self.nikeflix_last_watched() if shows else None) or None


class ItemListSyncDataNikeFlixRecent(ItemListSyncDataNikeFlixContinue):
    """ NikeFlix 4.1.5 Recently Watched on Search for a profile without Trakt (trakt_ondeck with nikeflix=recent): every
    show and film of its own watch history by its last activity; with Trakt, Continue Watching """

    def get_items(self):
        if self.nikeflix_local:
            from tmdbhelper.lib.sync.nikeflix_local import LocalHistory
            return LocalHistory(self.item_type).recent_items() or None
        return super().get_items()


def ItemListSyncDataFactory(sync_type, *args, **kwargs):

    routes = {
        'collection': ItemListSyncDataCollection,
        'watchlist': ItemListSyncDataWatchlist,
        'watchlistreleased': ItemListSyncDataReleasedWatchlist,
        'watchlistanticipated': ItemListSyncDataAnticipatedWatchlist,
        'watched': ItemListSyncDataWatched,
        'playback': ItemListSyncDataPlayback,
        'favorites': ItemListSyncDataFavorites,
        'dropped': ItemListSyncDataDropped,
        'nextup': ItemListSyncDataNextUp,
        'upnext': ItemListSyncDataUpNext,
        'inprogress': ItemListSyncDataInProgress,
        'towatch': ItemListSyncDataToWatch,
        'unwatchedplayback': ItemListSyncDataUnwatchedPlayback,
        'nikeflixcontinue': ItemListSyncDataNikeFlixContinue,
        'nikeflixrecent': ItemListSyncDataNikeFlixRecent,
    }

    return routes[sync_type](*args, **kwargs)
