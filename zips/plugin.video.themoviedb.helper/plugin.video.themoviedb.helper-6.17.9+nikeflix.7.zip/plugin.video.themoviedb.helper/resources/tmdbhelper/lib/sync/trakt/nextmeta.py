from jurialmunkey.ftools import cached_property
from tmdbhelper.lib.addon.tmdate import convert_timestamp
from tmdbhelper.lib.sync.nextmeta import (
    SyncNextEpisodeItem,
    SyncAllNextEpisodesMetaItem,
    SyncAllNextEpisodesMeta,
    SyncNextEpisodesMetaItem,
    SyncNextEpisodesMeta
)


class TraktSyncNextEpisodeItem(SyncNextEpisodeItem):

    def is_next_episode(self, season, episode):
        if not episode.get('completed'):
            return True
        if not self.reset_at_datetime_obj:
            return False
        if convert_timestamp(episode.get('last_watched_at')) < self.reset_at_datetime_obj:
            return True
        return False

    # NikeFlix 4.1.5: the show continues after the most recently watched episode (Trakt's next_episode), never at an
    # earlier unwatched one (a skipped E3/E4, or E1 of a show already started); Up Next starts there.
    @cached_property
    def nikeflix_next(self):
        from tmdbhelper.lib.sync.nikeflix_continue import next_after_last_watched
        return next_after_last_watched(self.response) if self.response else None

    @cached_property
    def next_episode_id(self):
        if not self.nikeflix_next:
            return
        return self.get_next_episode_id(*self.nikeflix_next)

    @cached_property
    def next_episode_aired_at(self):
        if not self.nikeflix_next or (self.next_episode_season, self.next_episode_number) != self.nikeflix_next:
            return
        try:
            return self.next_episode['first_aired']
        except (KeyError, TypeError, NameError):
            return

    @cached_property
    def all_next_episodes(self):
        from tmdbhelper.lib.sync.nikeflix_continue import episodes_from
        return (self.get_next_episode_id(s, n) for s, n in episodes_from(self.response, self.nikeflix_next))

    @cached_property
    def response(self):
        if not self.trakt_slug:
            return {}
        return self.get_response_sync(
            f'shows/{self.trakt_slug}/progress/watched',
            extended='full',
        ) or {}


class TraktSyncAllNextEpisodesMetaItem(SyncAllNextEpisodesMetaItem):
    sync_item_class = TraktSyncNextEpisodeItem


class TraktSyncAllNextEpisodesMeta(SyncAllNextEpisodesMeta):
    meta_item_getter = TraktSyncAllNextEpisodesMetaItem
    sd_additional_keys = ('trakt_slug', )


class TraktSyncNextEpisodesMetaItem(SyncNextEpisodesMetaItem):
    sync_item_class = TraktSyncNextEpisodeItem


class TraktSyncNextEpisodesMeta(SyncNextEpisodesMeta):
    meta_item_getter = TraktSyncNextEpisodesMetaItem
    sd_additional_keys = ('trakt_slug', )
