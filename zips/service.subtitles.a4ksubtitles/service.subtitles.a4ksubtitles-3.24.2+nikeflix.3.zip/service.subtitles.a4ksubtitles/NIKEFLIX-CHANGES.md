# NikeFlix changes to service.subtitles.a4ksubtitles

This add-on is redistributed by NikeFlix under its original licence (MIT).

- Upstream: https://github.com/newt-sc/a4kSubtitles 3.24.2
- Upstream ZIP: https://github.com/newt-sc/a4kSubtitles/archive/refs/tags/service.subtitles.a4ksubtitles/service.subtitles.a4ksubtitles-3.24.2.zip
- Upstream sha256: e3f3f158d99af5dc2c20729ba3bb8dba0793952fef21e80fb3593327138ef55f
- NikeFlix version: 3.24.2+nikeflix.3

## Patches

- `0001-h3-switch-quiescence.patch`: H3 Option C (DEC-H3-C-STAGING, staged, not released): the service loop (gate at the top of the pass) skips its pass and acknowledges while a NikeFlix profile switch is pending, so Kodi does not have to kill it during LogOff; the added nikeflix_quiesce.py reads one Home window property only (no global getCondVisibility replacement; every pause ends on its own). Evidence docs/evidence/H3-QUIESCE-V5.md.
- `0002-quiet-mode-opensubtitles-no-account.patch`: Quiet Mode step 2 (T34 site A4K-OPENSUBS-AUTH, build_auth_request): with no OpenSubtitles account on the profile and service.nikeflix quiet.enabled on, the search skips OpenSubtitles without the 'OpenSubtitles now requires authentication!' toast at every playback and logs 'NikeFlix Quiet Mode: hid ...' instead; Quiet Mode off, a missing service.nikeflix or an entered account that fails behave as upstream. Evidence docs/evidence/T34-QUIET-MODE-STEP2.md.
- `0003-netflix-style-subtitles.patch`: NikeFlix 4.1.5 Netflix-style subtitles (Tanner 2026-11-21: Netflix only has a certain amount of lines). Every SRT a4kSubtitles downloads (the subtitle search dialog and its auto-download) is rewritten by service.nikeflix before Kodi gets it (download() after __postprocess, through the added nikeflix_subtitles.py, which loads service.nikeflix resources/lib/subreflow.py): at most two lines of 42 characters with the bottom line the longer one, breaks after punctuation, two speakers one line each, a cue over 84 characters split into two cues timed by length, and an8-style position tags dropped while Kodi keeps subtitles at the bottom. NikeFlix Settings > Two lines at most (service.nikeflix subs.twolines) turns the rewrite off; without service.nikeflix or on any error the file is handed over unchanged. Evidence docs/evidence/NF415-PLAYER.md.
