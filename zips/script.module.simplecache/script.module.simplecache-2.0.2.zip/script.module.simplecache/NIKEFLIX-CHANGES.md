# NikeFlix changes to script.module.simplecache

This add-on is redistributed by NikeFlix under its original licence (Apache-2.0).

- Upstream: https://github.com/sualfred/script.module.simplecache 2.0.2
- Upstream ZIP: https://mirrors.kodi.tv/addons/omega/script.module.simplecache/script.module.simplecache-2.0.2.zip
- Upstream sha256: b818b42ac33cdaa9f16cd299264d1fb035bed7ea79ce2665185929d2f26b1ea0
- NikeFlix version: 2.0.2

No source changes: this is the unmodified upstream release, repackaged with this notice.
