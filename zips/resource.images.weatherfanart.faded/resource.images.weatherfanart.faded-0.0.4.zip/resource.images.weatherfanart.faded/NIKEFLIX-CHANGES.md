# NikeFlix changes to resource.images.weatherfanart.faded

This add-on is redistributed by NikeFlix under its original licence (CC-BY-SA-3.0).

- Upstream: https://mirrors.kodi.tv/addons/omega/addons.xml.gz 0.0.4
- Upstream ZIP: https://mirrors.kodi.tv/addons/omega/resource.images.weatherfanart.faded/resource.images.weatherfanart.faded-0.0.4.zip
- Upstream sha256: 79297c8eac5870d50b8a786ba3a9621bcbd94a51b5b794af0391ea07aa23d298
- NikeFlix version: 0.0.4

No source changes: this is the unmodified upstream release, repackaged with this notice.
