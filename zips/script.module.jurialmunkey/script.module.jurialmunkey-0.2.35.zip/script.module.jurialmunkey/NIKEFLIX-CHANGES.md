# NikeFlix changes to script.module.jurialmunkey

This add-on is redistributed by NikeFlix under its original licence (GPL-3.0-or-later).

- Upstream: https://github.com/jurialmunkey/script.module.jurialmunkey 0.2.35
- Upstream ZIP: https://raw.githubusercontent.com/jurialmunkey/repository.jurialmunkey/master/omega/zips/script.module.jurialmunkey/script.module.jurialmunkey-0.2.35.zip
- Upstream sha256: 80302314cdbc5a75611b0c2866eb1c7b4e93ccadaf20208ef7eb79b79c1fb749
- NikeFlix version: 0.2.35

No source changes: this is the unmodified upstream release, repackaged with this notice.
- Added `LICENSE.txt` (licence text from `managed/_licences/GPL-3.0.txt`).
