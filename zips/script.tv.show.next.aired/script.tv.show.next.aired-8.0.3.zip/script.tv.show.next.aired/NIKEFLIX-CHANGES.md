# NikeFlix changes to script.tv.show.next.aired

This add-on is redistributed by NikeFlix under its original licence (GPL-2.0-only).

- Upstream: https://github.com/marcelveldt/script.tv.show.next.aired.git 8.0.3
- Upstream ZIP: https://raw.githubusercontent.com/AchillesPunks/repository.titan.bingie.mod/master/omega/script.tv.show.next.aired/script.tv.show.next.aired-8.0.3.zip
- Upstream sha256: 3760ced32442a911751aadac96d7028b7eb026614ce68bffe77e4895fd8ffd5c
- NikeFlix version: 8.0.3

No source changes: this is the unmodified upstream release, repackaged with this notice.
