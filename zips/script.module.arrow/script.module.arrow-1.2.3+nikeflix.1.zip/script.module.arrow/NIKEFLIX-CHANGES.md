# NikeFlix changes to script.module.arrow

This add-on is redistributed by NikeFlix under its original licence (Apache-2.0).

- Upstream: https://github.com/arrow-py/arrow 1.2.3
- Upstream ZIP: https://mirrors.kodi.tv/addons/omega/script.module.arrow/script.module.arrow-1.2.3.zip
- Upstream sha256: 03d59458d1b4f7f313752fd070adf013e8d074ee43ec49a1b9bc46ccb00ceeec
- NikeFlix version: 1.2.3+nikeflix.1

## Patches

- `0001-no-shared-datetime-singletons.patch`: Build datetime max/min/resolution values from constructors instead of reading the shared class singletons at import. In the T54 lab, Kodi 21.3 sub-interpreters left those lookups pointing at freed objects, producing the T04 tzinfo/timestamp AttributeErrors and python3.8.dll+0x115f56 access violations while importing arrow. Avoids the trigger in arrow; the interpreter-level defect remains.
