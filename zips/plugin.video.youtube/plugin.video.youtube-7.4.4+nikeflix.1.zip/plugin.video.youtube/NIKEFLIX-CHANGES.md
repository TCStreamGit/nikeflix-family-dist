# NikeFlix changes to plugin.video.youtube

This add-on is redistributed by NikeFlix under its original licence (GPL-2.0-only).

- Upstream: https://github.com/anxdpanic/plugin.video.youtube 7.4.4
- Upstream ZIP: https://mirrors.kodi.tv/addons/omega/plugin.video.youtube/plugin.video.youtube-7.4.4.zip
- Upstream sha256: d744e5ba2d2b50924a9fa5624f4d209c2be95b97ef1ad1682cafbed160fb428f
- NikeFlix version: 7.4.4+nikeflix.1

## Patches

- `0001-h3-switch-quiescence.patch`: H3 Option C (DEC-H3-C-STAGING, staged, not released): the service loop (outer + inner) skips its pass and acknowledges while a NikeFlix profile switch is pending, so Kodi does not have to kill it during LogOff; the added nikeflix_quiesce.py reads one Home window property only (no global getCondVisibility replacement; every pause ends on its own). Evidence docs/evidence/H3-QUIESCE-V5.md.
