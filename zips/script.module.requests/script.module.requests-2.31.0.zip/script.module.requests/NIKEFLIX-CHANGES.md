# NikeFlix changes to script.module.requests

This add-on is redistributed by NikeFlix under its original licence (Apache-2.0).

- Upstream: https://github.com/psf/requests 2.31.0
- Upstream ZIP: https://mirrors.kodi.tv/addons/omega/script.module.requests/script.module.requests-2.31.0.zip
- Upstream sha256: a5704f0fd7afb4154e1beea9b5f05a002bcd75fa581a1e5fd15ece39bf2bd38a
- NikeFlix version: 2.31.0

No source changes: this is the unmodified upstream release, repackaged with this notice.
