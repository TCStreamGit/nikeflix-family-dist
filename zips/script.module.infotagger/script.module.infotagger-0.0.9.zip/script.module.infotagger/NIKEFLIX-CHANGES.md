# NikeFlix changes to script.module.infotagger

This add-on is redistributed by NikeFlix under its original licence (GPL-3.0-or-later).

- Upstream: https://github.com/jurialmunkey/script.module.infotagger 0.0.9
- Upstream ZIP: https://raw.githubusercontent.com/jurialmunkey/repository.jurialmunkey/master/omega/zips/script.module.infotagger/script.module.infotagger-0.0.9.zip
- Upstream sha256: 5fb83664bb732bca773d420f9f5b1383be594ed88836f59178032f36bc668336
- NikeFlix version: 0.0.9

No source changes: this is the unmodified upstream release, repackaged with this notice.
- Added `LICENSE.txt` (licence text from `managed/_licences/GPL-3.0.txt`).
