# NikeFlix changes to script.module.simplejson

This add-on is redistributed by NikeFlix under its original licence (MIT).

- Upstream: https://github.com/simplejson/simplejson 3.19.1+matrix.1
- Upstream ZIP: https://mirrors.kodi.tv/addons/omega/script.module.simplejson/script.module.simplejson-3.19.1+matrix.1.zip
- Upstream sha256: 7cf5d7000d9f07370f951a51e387b17ebcaf99d33341f376123dda1183858d19
- NikeFlix version: 3.19.1+matrix.1

No source changes: this is the unmodified upstream release, repackaged with this notice.
